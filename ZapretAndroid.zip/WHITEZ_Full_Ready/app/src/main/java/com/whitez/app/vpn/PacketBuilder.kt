package com.whitez.app.vpn

import java.net.InetAddress
import java.nio.ByteBuffer

object PacketBuilder {

    fun buildUdp(
        srcIp: InetAddress,
        srcPort: Int,
        dstIp: InetAddress,
        dstPort: Int,
        payload: ByteArray
    ): ByteArray {
        val udpLen = 8 + payload.size
        val totalLen = 20 + udpLen
        val buf = ByteBuffer.allocate(totalLen)
        buf.put(0x45.toByte())
        buf.put(0x00.toByte())
        buf.putShort(totalLen.toShort())
        buf.putShort(0)
        buf.putShort(0x4000.toShort())
        buf.put(64.toByte())
        buf.put(17.toByte())
        buf.putShort(0)
        buf.put(srcIp.address)
        buf.put(dstIp.address)
        buf.putShort(10, csum(buf.array(), 0, 20))

        buf.putShort(srcPort.toShort())
        buf.putShort(dstPort.toShort())
        buf.putShort(udpLen.toShort())
        buf.putShort(0)
        buf.put(payload)
        return buf.array()
    }

    fun buildTcp(
        srcIp: InetAddress,
        srcPort: Int,
        dstIp: InetAddress,
        dstPort: Int,
        seq: Long,
        ack: Long,
        flags: Int,
        payload: ByteArray
    ): ByteArray {
        val tcpLen = 20 + payload.size
        val totalLen = 20 + tcpLen
        val buf = ByteBuffer.allocate(totalLen)
        buf.put(0x45.toByte())
        buf.put(0x00.toByte())
        buf.putShort(totalLen.toShort())
        buf.putShort(0)
        buf.putShort(0x4000.toShort())
        buf.put(64.toByte())
        buf.put(6.toByte())
        buf.putShort(0)
        buf.put(srcIp.address)
        buf.put(dstIp.address)
        buf.putShort(10, csum(buf.array(), 0, 20))

        buf.putShort(srcPort.toShort())
        buf.putShort(dstPort.toShort())
        buf.putInt(seq.toInt())
        buf.putInt(ack.toInt())
        buf.put(0x50.toByte())
        buf.put(flags.toByte())
        buf.putShort(65535.toShort())
        buf.putShort(0)
        buf.putShort(0)
        buf.put(payload)
        buf.putShort(36, tcpCsum(srcIp.address, dstIp.address, buf.array(), 20, tcpLen))
        return buf.array()
    }

    private fun csum(arr: ByteArray, off: Int, len: Int): Short {
        var sum = 0L
        var i = off
        val limit = off + len
        while (i < limit - 1) {
            sum += ((arr[i].toInt() and 0xFF) shl 8) or (arr[i + 1].toInt() and 0xFF)
            i += 2
        }
        if (i < limit) sum += (arr[i].toInt() and 0xFF) shl 8
        while ((sum shr 16) != 0L) sum = (sum and 0xFFFF) + (sum shr 16)
        return (sum.inv() and 0xFFFF).toShort()
    }

    private fun tcpCsum(src: ByteArray, dst: ByteArray, pkt: ByteArray, off: Int, len: Int): Short {
        val pseudo = ByteBuffer.allocate(12 + len)
        pseudo.put(src); pseudo.put(dst)
        pseudo.put(0.toByte()); pseudo.put(6.toByte())
        pseudo.putShort(len.toShort())
        pseudo.put(pkt, off, len)
        return csum(pseudo.array(), 0, pseudo.capacity())
    }
}
