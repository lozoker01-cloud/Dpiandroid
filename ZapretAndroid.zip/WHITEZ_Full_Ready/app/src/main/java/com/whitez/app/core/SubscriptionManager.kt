package com.whitez.app.core

import android.content.Context
import android.net.Uri
import android.util.Base64
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.InetSocketAddress
import java.net.Socket
import java.net.URL
import java.net.URLDecoder

data class VpnNode(
    val id: String,
    val name: String,
    val protocol: String,
    val host: String,
    val port: Int,
    val rawUri: String,
    var pingMs: Long = -1L
)

object SubscriptionManager {
    private const val PREFS_NAME = "whitez_v5_prefs"
    private const val KEY_SUB_URL = "sub_url"
    private const val KEY_CACHED_RAW = "cached_raw"
    private const val KEY_SELECTED_ID = "selected_node_id"
    private const val KEY_MODE = "op_mode"

    const val DEFAULT_SUBSCRIPTION_URL =
        "http://31.59.207.13:2096/511gttxhtbu86vr5/8ojmix9ue0g2zd6y"

    enum class OperationMode(val title: String, val subtitle: String) {
        FULL_VPN(
            "Весь трафик через VPN",
            "Весь трафик через выбранный узел подписки + авто-DPI и блок QUIC"
        ),
        SMART_HYBRID(
            "Гибрид: VPN + Auto-DPI",
            "Заблокированные домены через VPN, остальной трафик через DPI"
        ),
        DPI_ONLY(
            "Только Auto-DPI",
            "Прямой обход DPI без VPN-сервера"
        )
    }

    fun getSubscriptionUrl(context: Context): String {
        val prefs = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
        return prefs.getString(KEY_SUB_URL, DEFAULT_SUBSCRIPTION_URL) ?: DEFAULT_SUBSCRIPTION_URL
    }

    fun saveSubscriptionUrl(context: Context, url: String) {
        context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
            .edit().putString(KEY_SUB_URL, url.trim()).apply()
    }

    fun getSelectedNodeId(context: Context): String? {
        return context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
            .getString(KEY_SELECTED_ID, null)
    }

    fun saveSelectedNodeId(context: Context, id: String) {
        context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
            .edit().putString(KEY_SELECTED_ID, id).apply()
    }

    fun getOperationMode(context: Context): OperationMode {
        val prefs = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
        val raw = prefs.getString(KEY_MODE, OperationMode.FULL_VPN.name)
        return try {
            OperationMode.valueOf(raw ?: OperationMode.FULL_VPN.name)
        } catch (_: Exception) {
            OperationMode.FULL_VPN
        }
    }

    fun saveOperationMode(context: Context, mode: OperationMode) {
        context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
            .edit().putString(KEY_MODE, mode.name).apply()
    }

    suspend fun syncAndMeasureNodes(
        context: Context,
        protectSocket: ((Socket) -> Unit)? = null
    ): List<VpnNode> = withContext(Dispatchers.IO) {
        val urlStr = getSubscriptionUrl(context)
        val prefs = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)

        val rawText = try {
            val conn = (URL(urlStr).openConnection() as HttpURLConnection).apply {
                connectTimeout = 5000
                readTimeout = 5000
                setRequestProperty("User-Agent", "v2rayTun/3.2.0")
            }
            val body = conn.inputStream.bufferedReader().use { it.readText() }.trim()
            if (body.isNotEmpty()) {
                prefs.edit().putString(KEY_CACHED_RAW, body).apply()
            }
            body
        } catch (_: Exception) {
            prefs.getString(KEY_CACHED_RAW, "") ?: ""
        }

        val nodes = parseSubscription(rawText)
        nodes.forEach { n ->
            n.pingMs = measureTcp(n.host, n.port, protectSocket)
        }

        val savedId = getSelectedNodeId(context)
        nodes.sortedWith { a, b ->
            if (a.id == savedId) -1
            else if (b.id == savedId) 1
            else {
                val pa = if (a.pingMs < 0) Long.MAX_VALUE else a.pingMs
                val pb = if (b.pingMs < 0) Long.MAX_VALUE else b.pingMs
                pa.compareTo(pb)
            }
        }
    }

    fun parseSubscription(raw: String): List<VpnNode> {
        if (raw.isBlank()) return emptyList()
        val decoded = if (
            raw.contains("://")
        ) {
            raw
        } else {
            try {
                val clean = raw.replace("\\s".toRegex(), "")
                String(Base64.decode(clean, Base64.DEFAULT), Charsets.UTF_8)
            } catch (_: Exception) {
                raw
            }
        }

        return decoded.lines()
            .map { it.trim() }
            .filter { it.contains("://") }
            .mapIndexedNotNull { idx, line -> parseUriLine(idx, line) }
    }

    private fun parseUriLine(index: Int, rawUri: String): VpnNode? {
        return try {
            val schemeIdx = rawUri.indexOf("://")
            if (schemeIdx <= 0) return null
            val proto = rawUri.substring(0, schemeIdx).lowercase()

            if (proto == "vmess") {
                val b64 = rawUri.removePrefix("vmess://").trim()
                val jsonStr = String(Base64.decode(b64, Base64.DEFAULT), Charsets.UTF_8)
                val obj = JSONObject(jsonStr)
                val host = obj.optString("add")
                val port = obj.optInt("port", 443)
                val ps = obj.optString("ps").ifBlank { "VMess #${index + 1}" }
                if (host.isBlank()) return null
                return VpnNode("vmess_$index", ps, "VMESS", host, port, rawUri)
            }

            val uri = Uri.parse(rawUri)
            val host = uri.host ?: return null
            val port = if (uri.port > 0) uri.port else 443
            val frag = uri.fragment?.let {
                try { URLDecoder.decode(it, "UTF-8") } catch (_: Exception) { it }
            }
            val title = frag?.takeIf { it.isNotBlank() } ?: "${proto.uppercase()} #${index + 1}"
            VpnNode(
                id = "${proto}_$index",
                name = title,
                protocol = proto.uppercase(),
                host = host,
                port = port,
                rawUri = rawUri
            )
        } catch (_: Exception) {
            null
        }
    }

    private fun measureTcp(host: String, port: Int, protectSocket: ((Socket) -> Unit)?): Long {
        val socket = Socket()
        return try {
            protectSocket?.invoke(socket)
            val t0 = System.currentTimeMillis()
            socket.connect(InetSocketAddress(host, port), 2200)
            System.currentTimeMillis() - t0
        } catch (_: Exception) {
            -1L
        } finally {
            try { socket.close() } catch (_: Exception) {}
        }
    }
}
