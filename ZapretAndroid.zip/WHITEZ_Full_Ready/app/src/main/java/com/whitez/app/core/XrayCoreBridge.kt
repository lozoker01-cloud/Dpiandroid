package com.whitez.app.core

import android.net.Uri
import android.util.Base64
import org.json.JSONArray
import org.json.JSONObject
import java.net.InetSocketAddress
import java.net.Socket

object XrayCoreBridge {
    const val SOCKS_HOST = "127.0.0.1"
    const val SOCKS_PORT = 10808

    @Volatile
    var coreRunning: Boolean = false
        private set

    private var coreController: Any? = null

    fun hasNativeCore(): Boolean {
        return try {
            Class.forName("libv2ray.Libv2ray")
            true
        } catch (_: Exception) {
            false
        }
    }

    fun buildConfig(node: VpnNode): String {
        val inbound = JSONObject().apply {
            put("tag", "socks-in")
            put("port", SOCKS_PORT)
            put("listen", SOCKS_HOST)
            put("protocol", "socks")
            put("settings", JSONObject().apply {
                put("auth", "noauth")
                put("udp", true)
            })
            put("sniffing", JSONObject().apply {
                put("enabled", true)
                put("destOverride", JSONArray().put("http").put("tls"))
            })
        }

        val outbound = buildOutbound(node)
        val freedomOut = JSONObject().apply {
            put("tag", "direct")
            put("protocol", "freedom")
        }

        return JSONObject().apply {
            put("log", JSONObject().put("loglevel", "warning"))
            put("inbounds", JSONArray().put(inbound))
            put("outbounds", JSONArray().put(outbound).put(freedomOut))
        }.toString(2)
    }

    private fun buildOutbound(node: VpnNode): JSONObject {
        val proto = node.protocol.lowercase()
        if (proto == "vmess") {
            val b64 = node.rawUri.removePrefix("vmess://").trim()
            val v = JSONObject(String(Base64.decode(b64, Base64.DEFAULT), Charsets.UTF_8))
            val user = JSONObject().apply {
                put("id", v.optString("id"))
                put("alterId", v.optInt("aid", 0))
                put("security", v.optString("scy", "auto").ifBlank { "auto" })
            }
            val vnext = JSONObject().apply {
                put("address", v.optString("add", node.host))
                put("port", v.optInt("port", node.port))
                put("users", JSONArray().put(user))
            }
            val stream = JSONObject().apply {
                val net = v.optString("net", "tcp")
                put("network", net)
                if (v.optString("tls") == "tls") {
                    put("security", "tls")
                    put("tlsSettings", JSONObject().apply {
                        val sni = v.optString("sni").ifBlank { v.optString("host") }
                        if (sni.isNotBlank()) put("serverName", sni)
                        put("allowInsecure", false)
                    })
                }
                if (net == "ws") {
                    put("wsSettings", JSONObject().apply {
                        val path = v.optString("path", "/")
                        val hostHdr = v.optString("host")
                        put("path", path)
                        if (hostHdr.isNotBlank()) put("headers", JSONObject().put("Host", hostHdr))
                    })
                }
            }
            return JSONObject().apply {
                put("tag", "proxy")
                put("protocol", "vmess")
                put("settings", JSONObject().put("vnext", JSONArray().put(vnext)))
                put("streamSettings", stream)
            }
        }

        val uri = Uri.parse(node.rawUri)
        val uuid = uri.userInfo ?: ""
        val security = uri.getQueryParameter("security") ?: "none"
        val network = uri.getQueryParameter("type") ?: "tcp"
        val sni = uri.getQueryParameter("sni") ?: node.host
        val fp = uri.getQueryParameter("fp") ?: "chrome"
        val pbk = uri.getQueryParameter("pbk") ?: ""
        val sid = uri.getQueryParameter("sid") ?: ""
        val spx = uri.getQueryParameter("spx") ?: "/"
        val flow = uri.getQueryParameter("flow") ?: ""
        val path = uri.getQueryParameter("path") ?: "/"
        val hostHdr = uri.getQueryParameter("host") ?: sni
        val alpn = uri.getQueryParameter("alpn")

        val stream = JSONObject().apply {
            put("network", network)
            put("security", security)
            if (security == "reality") {
                put("realitySettings", JSONObject().apply {
                    put("serverName", sni)
                    put("fingerprint", fp)
                    put("publicKey", pbk)
                    put("shortId", sid)
                    put("spiderX", spx)
                })
            } else if (security == "tls") {
                put("tlsSettings", JSONObject().apply {
                    put("serverName", sni)
                    put("fingerprint", fp)
                    if (!alpn.isNullOrBlank()) {
                        put("alpn", JSONArray(alpn.split(",")))
                    }
                })
            }
            if (network == "ws") {
                put("wsSettings", JSONObject().apply {
                    put("path", path)
                    put("headers", JSONObject().put("Host", hostHdr))
                })
            } else if (network == "grpc") {
                val serviceName = uri.getQueryParameter("serviceName") ?: ""
                put("grpcSettings", JSONObject().apply {
                    put("serviceName", serviceName)
                })
            }
        }

        return if (proto == "trojan") {
            val serverObj = JSONObject().apply {
                put("address", node.host)
                put("port", node.port)
                put("password", uuid)
            }
            JSONObject().apply {
                put("tag", "proxy")
                put("protocol", "trojan")
                put("settings", JSONObject().put("servers", JSONArray().put(serverObj)))
                put("streamSettings", stream)
            }
        } else {
            val userObj = JSONObject().apply {
                put("id", uuid)
                put("encryption", uri.getQueryParameter("encryption") ?: "none")
                if (flow.isNotBlank()) put("flow", flow)
            }
            val vnextObj = JSONObject().apply {
                put("address", node.host)
                put("port", node.port)
                put("users", JSONArray().put(userObj))
            }
            JSONObject().apply {
                put("tag", "proxy")
                put("protocol", if (proto == "vless") "vless" else "vmess")
                put("settings", JSONObject().put("vnext", JSONArray().put(vnextObj)))
                put("streamSettings", stream)
            }
        }
    }

    fun start(node: VpnNode): Boolean {
        stop()
        val cfg = buildConfig(node)
        coreRunning = try {
            val libCls = Class.forName("libv2ray.Libv2ray")
            val ctrl = libCls.getMethod("newCoreController", Any::class.java).invoke(null, null)
            ctrl.javaClass.getMethod("startLoop", String::class.java).invoke(ctrl, cfg)
            coreController = ctrl
            true
        } catch (_: Exception) {
            isSocksReady()
        }
        return coreRunning
    }

    fun stop() {
        try {
            coreController?.let { ctrl ->
                try { ctrl.javaClass.getMethod("stopLoop").invoke(ctrl) } catch (_: Exception) {}
            }
        } catch (_: Exception) {
        }
        coreController = null
        coreRunning = false
    }

    fun isSocksReady(): Boolean {
        return try {
            Socket().use { s ->
                s.connect(InetSocketAddress(SOCKS_HOST, SOCKS_PORT), 300)
                true
            }
        } catch (_: Exception) {
            false
        }
    }
}
