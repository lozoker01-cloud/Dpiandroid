package com.zapret.android.engine

import android.content.Context
import android.util.Log
import com.zapret.android.model.ZapretStrategy
import java.io.File

/**
 * Управляет запуском нативного ядра obхода DPI (libciadpi.so из jniLibs)
 * и локального TUN-to-SOCKS моста (libhev-socks5-tunnel.so).
 *
 * Важно: в Android без Root-прав бинарники из jniLibs/<abi>/lib*.so
 * автоматически распаковываются системой в applicationInfo.nativeLibraryDir
 * с правами на выполнение (rx), что обходит запрет W^X на Android 10+.
 */
class NativeDpiEngine(private val context: Context) {

    companion object {
        private const val TAG = "NativeDpiEngine"
        const val SOCKS_HOST = "127.0.0.1"
        const val SOCKS_PORT = 1080
        const val TEST_SOCKS_PORT = 1081
    }

    private var dpiProcess: Process? = null
    private var tunnelProcess: Process? = null

    fun getNativeBinary(libName: String): File {
        val nativeDir = context.applicationInfo.nativeLibraryDir
        return File(nativeDir, libName)
    }

    fun isBinaryAvailable(): Boolean {
        val ciadpi = getNativeBinary("libciadpi.so")
        return ciadpi.exists() && ciadpi.canExecute()
    }

    /**
     * Запускает локальный SOCKS5-прокси с выбранной стратегией модификации DPI-пакетов.
     */
    fun startDpiProxy(
        strategy: ZapretStrategy,
        port: Int = SOCKS_PORT,
        hostsFilePath: String? = null
    ): Boolean {
        stopDpiProxy()
        val binary = getNativeBinary("libciadpi.so")
        if (!binary.exists()) {
            Log.w(TAG, "libciadpi.so не найден в ${binary.absolutePath}. Включён встроенный fallback-режим.")
            return false
        }

        return try {
            val cmd = mutableListOf(
                binary.absolutePath,
                "-i", SOCKS_HOST,
                "-p", port.toString()
            )
            if (!hostsFilePath.isNullOrBlank()) {
                cmd.addAll(listOf("-H", hostsFilePath))
            }
            cmd.addAll(strategy.args)

            Log.i(TAG, "Запуск DPI ядра: ${cmd.joinToString(" ")}")
            dpiProcess = ProcessBuilder(cmd)
                .redirectErrorStream(true)
                .start()
            true
        } catch (e: Exception) {
            Log.e(TAG, "Ошибка запуска libciadpi.so", e)
            false
        }
    }

    /**
     * Связывает file descriptor VPN-интерфейса (TUN) с локальным SOCKS5-прокси.
     */
    fun startTun2Socks(tunFd: Int, mtu: Int = 1500): Boolean {
        stopTun2Socks()
        val tunBinary = getNativeBinary("libtun2socks.so")
        if (!tunBinary.exists()) {
            Log.w(TAG, "libtun2socks.so не найден — используется встроенный Kotlin PacketRouter.")
            return false
        }

        return try {
            val cmd = listOf(
                tunBinary.absolutePath,
                "--netif-ipaddr", "10.0.0.2",
                "--netif-netmask", "255.255.255.0",
                "--socks-server-addr", "$SOCKS_HOST:$SOCKS_PORT",
                "--tunfd", tunFd.toString(),
                "--tunmtu", mtu.toString(),
                "--loglevel", "warning"
            )
            tunnelProcess = ProcessBuilder(cmd)
                .redirectErrorStream(true)
                .start()
            true
        } catch (e: Exception) {
            Log.e(TAG, "Ошибка запуска libtun2socks.so", e)
            false
        }
    }

    fun stopDpiProxy() {
        try {
            dpiProcess?.destroy()
            dpiProcess = null
        } catch (_: Exception) {
        }
    }

    fun stopTun2Socks() {
        try {
            tunnelProcess?.destroy()
            tunnelProcess = null
        } catch (_: Exception) {
        }
    }

    fun stopAll() {
        stopTun2Socks()
        stopDpiProxy()
    }
}
