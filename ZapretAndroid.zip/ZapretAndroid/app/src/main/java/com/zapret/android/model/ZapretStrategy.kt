package com.zapret.android.model

data class ZapretStrategy(
    val id: String,
    val name: String,
    val badge: String,
    val description: String,
    val args: List<String>,
    val blockQuic: Boolean = true,
    val recommendedFor: String
)

object StrategyRepository {

    /**
     * Полный набор стратегий, адаптированных из сборок zapret (Flowseal / bol-van)
     * под нативный движок ciadpi (ByeDPI) для работы без Root.
     */
    val strategies: List<ZapretStrategy> = listOf(
        ZapretStrategy(
            id = "general_default",
            name = "General (Стандартная)",
            badge = "Рекомендуемая",
            description = "Базовая стратегия zapret: split TLS ClientHello + disorder + блокировка QUIC (UDP 443).",
            args = listOf("-s1", "-d1", "-o1", "-a1", "-r1+s"),
            blockQuic = true,
            recommendedFor = "Большинство провайдеров (Ростелеком, МГТС, Дом.ру)"
        ),
        ZapretStrategy(
            id = "general_alt1",
            name = "General ALT 1 (Fake TLS + Split)",
            badge = "YouTube / Discord",
            description = "Отправка поддельного TLS-пакета с модифицированным TTL + фрагментация SNI.",
            args = listOf("-f-1", "-t3", "-s1", "-o1", "-r1+s", "-n", "www.google.com"),
            blockQuic = true,
            recommendedFor = "ТСПУ со строгой проверкой SNI"
        ),
        ZapretStrategy(
            id = "general_alt2",
            name = "General ALT 2 (Disorder + OOB)",
            badge = "Агрессивная",
            description = "Инверсия порядка TCP-сегментов + Out-of-Band байт на первом пакете.",
            args = listOf("-d1", "-o1", "-s2", "-a2", "-f-1", "-t4"),
            blockQuic = true,
            recommendedFor = "Билайн, МегаФон, Т2 (Tele2)"
        ),
        ZapretStrategy(
            id = "general_alt3",
            name = "General ALT 3 (Fake + Disorder2)",
            badge = "Мобильный интернет",
            description = "Двойное разбиение ClientHello с подменой SNI на разрешённый домен.",
            args = listOf("-f-1", "-t5", "-d1", "-d3", "-s1", "-n", "ya.ru"),
            blockQuic = true,
            recommendedFor = "МТС, Yota, мобильные сети 4G/5G"
        ),
        ZapretStrategy(
            id = "general_alt4",
            name = "General ALT 4 (Split TLS Record)",
            badge = "Мягкая",
            description = "Нарезка на уровне TLS-записей (TLS record split) без отправки фейковых пакетов.",
            args = listOf("-r1+s", "-r3+s", "-s1", "-a1"),
            blockQuic = true,
            recommendedFor = "Сети, где режутся пакеты с низким TTL"
        ),
        ZapretStrategy(
            id = "general_alt5",
            name = "General ALT 5 (Fake MD5 / BadSum)",
            badge = "Аналог badseq/md5sig",
            description = "Отправка фейкового ClientHello с некорректной контрольной суммой и разбиением.",
            args = listOf("-f-1", "--md5sig", "-s1", "-o1", "-d1"),
            blockQuic = true,
            recommendedFor = "Региональные провайдеры и корпоративные Wi-Fi"
        ),
        ZapretStrategy(
            id = "general_alt6",
            name = "General ALT 6 (SNI Offset Split)",
            badge = "Точечная",
            description = "Разрыв строго посередине имени хоста (SNI) в первом TCP-пакете.",
            args = listOf("-s0+s", "-d0+s", "-o1", "-r1+s"),
            blockQuic = true,
            recommendedFor = "Высокая скорость загрузки 4K-видео на YouTube"
        ),
        ZapretStrategy(
            id = "general_alt7",
            name = "General ALT 7 (Максимальный обход)",
            badge = "Тяжёлый ТСПУ",
            description = "Комбинация Fake TLS, OOB, TLS Record Split и инверсии пакетов.",
            args = listOf("-f-1", "-t3", "-o1", "-d1", "-r1+s", "-s1", "-n", "vk.com"),
            blockQuic = true,
            recommendedFor = "Сложные блокировки, когда остальные режимы не сработали"
        ),
        ZapretStrategy(
            id = "quic_only",
            name = "Только блокировка QUIC (HTTP/3)",
            badge = "Минимальная",
            description = "Блокирует UDP-трафик на порт 443, принудительно переводя YouTube на TCP/TLS.",
            args = emptyList(),
            blockQuic = true,
            recommendedFor = "Сети, где достаточно отключить QUIC"
        )
    )

    val targetDomains: List<String> = listOf(
        "youtube.com",
        "www.youtube.com",
        "m.youtube.com",
        "youtu.be",
        "googlevideo.com",
        "ytimg.com",
        "ggpht.com",
        "youtubei.googleapis.com",
        "discord.com",
        "gateway.discord.gg",
        "cdn.discordapp.com",
        "media.discordapp.net",
        "rutracker.org",
        "ntc.party"
    )
}
