package com.zapret.android.engine

import android.content.Context
import android.net.VpnService
import com.zapret.android.model.StrategyRepository
import com.zapret.android.model.ZapretStrategy
import kotlinx.coroutines.*
import okhttp3.OkHttpClient
import okhttp3.Request
import java.net.InetSocketAddress
import java.net.Proxy
import java.util.concurrent.TimeUnit

data class StrategyTestResult(
    val strategy: ZapretStrategy,
    val isSuccess: Boolean,
    val latencyMs: Long,
    val details: String
)

/**
 * Автоподбор и тестирование стратегий:
 * поочерёдно поднимает локальный прокси с каждой стратегией
 * и замеряет реальный HTTPS-ответ от YouTube / GoogleVideo.
 */
class StrategyTester(
    private val context: Context,
    private val vpnService: VpnService? = null
) {

    private val testUrls = listOf(
        "https://www.youtube.com/generate_204",
        "https://rr1---sn-4g5e6nze.googlevideo.com/generate_204"
    )

    suspend fun testAllStrategies(
        onProgress: (index: Int, total: Int, current: ZapretStrategy) -> Unit,
        onResult: (StrategyTestResult) -> Unit
    ): List<StrategyTestResult> = withContext(Dispatchers.IO) {
        val results = mutableListOf<StrategyTestResult>()
        val all = StrategyRepository.strategies

        all.forEachIndexed { index, strategy ->
            ensureActive()
            onProgress(index + 1, all.size, strategy)
            val result = testSingleStrategy(strategy)
            results.add(result)
            onResult(result)
        }
        results
    }

    suspend fun testSingleStrategy(strategy: ZapretStrategy): StrategyTestResult =
        withContext(Dispatchers.IO) {
            val testPort = NativeDpiEngine.TEST_SOCKS_PORT
            val nativeEngine = NativeDpiEngine(context)
            var kotlinProxy: PureKotlinDpiProxy? = null

            val startedNative = nativeEngine.startDpiProxy(strategy, port = testPort)
            if (!startedNative) {
                kotlinProxy = PureKotlinDpiProxy(
                    vpnService = vpnService,
                    port = testPort,
                    strategy = strategy,
                    targetDomains = emptySet()
                )
                kotlinProxy.start(this)
            }

            delay(250) // Даём сокету подняться

            try {
                val client = OkHttpClient.Builder()
                    .proxy(Proxy(Proxy.Type.SOCKS, InetSocketAddress("127.0.0.1", testPort)))
                    .connectTimeout(4, TimeUnit.SECONDS)
                    .readTimeout(4, TimeUnit.SECONDS)
                    .build()

                val startNs = System.nanoTime()
                var successCount = 0
                var lastCode = 0

                for (url in testUrls) {
                    try {
                        val req = Request.Builder()
                            .url(url)
                            .header("User-Agent", "Mozilla/5.0 (Linux; Android 14)")
                            .build()
                        client.newCall(req).execute().use { resp ->
                            lastCode = resp.code
                            if (resp.code in 200..399) {
                                successCount++
                            }
                        }
                    } catch (_: Exception) {
                    }
                }

                val elapsedMs = (System.nanoTime() - startNs) / 1_000_000
                val isOk = successCount > 0

                StrategyTestResult(
                    strategy = strategy,
                    isSuccess = isOk,
                    latencyMs = if (isOk) elapsedMs else -1L,
                    details = if (isOk) {
                        "Доступен ($successCount/${testUrls.size} узлов, ${elapsedMs} мс)"
                    } else {
                        "Таймаут или сброс соединения DPI (код $lastCode)"
                    }
                )
            } catch (e: Exception) {
                StrategyTestResult(
                    strategy = strategy,
                    isSuccess = false,
                    latencyMs = -1L,
                    details = "Ошибка: ${e.localizedMessage ?: "сброс"}"
                )
            } finally {
                nativeEngine.stopDpiProxy()
                kotlinProxy?.stop()
            }
        }
}
