package com.zapret.android.engine

import android.content.Context
import android.net.VpnService
import com.zapret.android.model.StrategyRepository
import com.zapret.android.model.ZapretStrategy
import kotlinx.coroutines.*
import okhttp3.OkHttpClient
import okhttp3.Request
import java.net.InetSocketAddress
import java.net.Proxy
import java.util.concurrent.TimeUnit

data class StrategyTestResult(
    val strategy: ZapretStrategy,
    val isSuccess: Boolean,
    val latencyMs: Long,
    val details: String
)

class StrategyTester(
    private val context: Context,
    private val vpnService: VpnService? = null
) {

    private val testUrls = listOf(
        "https://www.youtube.com/generate_204",
        "https://rr1---sn-4g5e6nze.googlevideo.com/generate_204"
    )

    suspend fun testAllStrategies(
        onProgress: (index: Int, total: Int, current: ZapretStrategy) -> Unit,
        onResult: (StrategyTestResult) -> Unit
    ): List<StrategyTestResult> = withContext(Dispatchers.IO) {
        val results = mutableListOf<StrategyTestResult>()
        val all = StrategyRepository.strategies

        for ((index, strategy) in all.withIndex()) {
            if (!isActive) break
            withContext(Dispatchers.Main) {
                onProgress(index + 1, all.size, strategy)
            }
            val result = try {
                testSingleStrategy(strategy)
            } catch (e: CancellationException) {
                throw e
            } catch (e: Exception) {
                StrategyTestResult(
                    strategy = strategy,
                    isSuccess = false,
                    latencyMs = -1L,
                    details = "Ошибка теста: ${e.javaClass.simpleName}"
                )
            }
            results.add(result)
            withContext(Dispatchers.Main) {
                onResult(result)
            }
        }
        results
    }

    suspend fun testSingleStrategy(strategy: ZapretStrategy): StrategyTestResult =
        withContext(Dispatchers.IO) {
            val testPort = NativeDpiEngine.TEST_SOCKS_PORT
            val nativeEngine = NativeDpiEngine(context)
            var kotlinProxy: PureKotlinDpiProxy? = null

            try {
                val startedNative = try {
                    nativeEngine.startDpiProxy(strategy, port = testPort)
                } catch (_: Exception) {
                    false
                }

                if (!startedNative) {
                    kotlinProxy = PureKotlinDpiProxy(
                        vpnService = vpnService,
                        port = testPort,
                        strategy = strategy,
                        targetDomains = emptySet()
                    )
                    kotlinProxy.start(this)
                }

                delay(300)

                val client = OkHttpClient.Builder()
                    .proxy(Proxy(Proxy.Type.SOCKS, InetSocketAddress("127.0.0.1", testPort)))
                    .connectTimeout(3, TimeUnit.SECONDS)
                    .readTimeout(3, TimeUnit.SECONDS)
                    .retryOnConnectionFailure(false)
                    .build()

                val startNs = System.nanoTime()
                var successCount = 0
                var lastCode = 0

                for (url in testUrls) {
                    try {
                        val req = Request.Builder()
                            .url(url)
                            .header("User-Agent", "Mozilla/5.0 (Linux; Android 14)")
                            .build()
                        client.newCall(req).execute().use { resp ->
                            lastCode = resp.code
                            if (resp.code in 200..399) {
                                successCount++
                            }
                        }
                    } catch (_: Exception) {
                    }
                }

                val elapsedMs = (System.nanoTime() - startNs) / 1_000_000
                val isOk = successCount > 0

                StrategyTestResult(
                    strategy = strategy,
                    isSuccess = isOk,
                    latencyMs = if (isOk) elapsedMs else -1L,
                    details = if (isOk) {
                        "Доступен ($successCount/${testUrls.size} узлов, ${elapsedMs} мс)"
                    } else {
                        "Таймаут или сброс соединения DPI (код $lastCode)"
                    }
                )
            } catch (e: CancellationException) {
                throw e
            } catch (e: Exception) {
                StrategyTestResult(
                    strategy = strategy,
                    isSuccess = false,
                    latencyMs = -1L,
                    details = "Ошибка: ${e.localizedMessage ?: e.javaClass.simpleName}"
                )
            } finally {
                try {
                    kotlinProxy?.stop()
                } catch (_: Exception) {
                }
                try {
                    nativeEngine.stopDpiProxy()
                } catch (_: Exception) {
                }
                delay(100)
            }
        }
}
