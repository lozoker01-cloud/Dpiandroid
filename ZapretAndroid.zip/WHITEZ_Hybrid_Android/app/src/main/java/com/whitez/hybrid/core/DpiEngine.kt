package com.whitez.hybrid.core

import android.net.VpnService
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.OutputStream
import java.net.InetSocketAddress
import java.net.Socket
import javax.net.ssl.SNIHostName
import javax.net.ssl.SSLParameters
import javax.net.ssl.SSLSocket
import javax.net.ssl.SSLSocketFactory

enum class DesyncTechnique {
    TLS_RECORD_SPLIT,
    CLIENT_HELLO_SPLIT,
    TCP_OOB_URGENT,
    MICRO_DISORDER
}

data class DpiProfile(
    val id: Int,
    val name: String,
    val technique: DesyncTechnique,
    val splitOffset: Int,
    val blockQuicUdp443: Boolean = true
)

object DpiEngine {

    val PROFILES = listOf(
        DpiProfile(1, "Smart Split + QUIC Drop", DesyncTechnique.CLIENT_HELLO_SPLIT, splitOffset = 2),
        DpiProfile(2, "TLS Record Split v2", DesyncTechnique.TLS_RECORD_SPLIT, splitOffset = 1),
        DpiProfile(3, "TCP OOB Urgent Desync", DesyncTechnique.TCP_OOB_URGENT, splitOffset = 1),
        DpiProfile(4, "Micro-Chunk Disorder", DesyncTechnique.MICRO_DISORDER, splitOffset = 1),
        DpiProfile(5, "Deep SNI Offset-5 Split", DesyncTechnique.CLIENT_HELLO_SPLIT, splitOffset = 5)
    )

    // Домены, которые идут через твой VPN в режиме "Гибрид"
    private val VPN_ROUTED_SUFFIXES = listOf(
        "youtube.com", "googlevideo.com", "ytimg.com", "ggpht.com",
        "discord.com", "discordapp.com", "discord.gg", "discord.media",
        "instagram.com", "cdninstagram.com", "facebook.com", "fbcdn.net",
        "x.com", "twitter.com", "twimg.com",
        "rutracker.org", "openai.com", "chatgpt.com", "anthropic.com", "claude.ai"
    )

    fun shouldRouteThroughVpn(sniHost: String?, mode: SubscriptionManager.OperationMode): Boolean {
        return when (mode) {
            SubscriptionManager.OperationMode.DPI_ONLY -> false
            SubscriptionManager.OperationMode.FULL_VPN -> true
            SubscriptionManager.OperationMode.SMART_HYBRID -> {
                if (sniHost.isNullOrBlank()) return false
                val lower = sniHost.lowercase()
                VPN_ROUTED_SUFFIXES.any { lower == it || lower.endsWith(".$it") }
            }
        }
    }

    /**
     * Извлекает SNI домен из TLS ClientHello, чтобы маршрутизатор мог решить:
     * пустить трафик через быстрый DPI-обход или завернуть в твой Xray/VLESS сервер.
     */
    fun extractSni(payload: ByteArray): String? {
        if (payload.size < 43) return null
        if (payload[0] != 0x16.toByte() || payload[1] != 0x03.toByte()) return null
        try {
            var pos = 43
            if (pos >= payload.size) return null
            val sessionIdLen = payload[pos].toInt() and 0xFF
            pos += 1 + sessionIdLen
            if (pos + 2 > payload.size) return null
            val cipherSuitesLen = ((payload[pos].toInt() and 0xFF) shl 8) or (payload[pos + 1].toInt() and 0xFF)
            pos += 2 + cipherSuitesLen
            if (pos + 1 > payload.size) return null
            val compMethodsLen = payload[pos].toInt() and 0xFF
            pos += 1 + compMethodsLen
            if (pos + 2 > payload.size) return null
            val extensionsLen = ((payload[pos].toInt() and 0xFF) shl 8) or (payload[pos + 1].toInt() and 0xFF)
            pos += 2
            val end = minOf(pos + extensionsLen, payload.size)
            while (pos + 4 <= end) {
                val extType = ((payload[pos].toInt() and 0xFF) shl 8) or (payload[pos + 1].toInt() and 0xFF)
                val extLen = ((payload[pos + 2].toInt() and 0xFF) shl 8) or (payload[pos + 3].toInt() and 0xFF)
                pos += 4
                if (extType == 0 && pos + extLen <= end && extLen > 5) {
                    val nameLen = ((payload[pos + 3].toInt() and 0xFF) shl 8) or (payload[pos + 4].toInt() and 0xFF)
                    if (pos + 5 + nameLen <= end) {
                        return String(payload, pos + 5, nameLen, Charsets.US_ASCII)
                    }
                }
                pos += extLen
            }
        } catch (_: Exception) {
        }
        return null
    }

    suspend fun selectOptimalProfile(
        vpnService: VpnService?,
        onProgress: (String) -> Unit
    ): Pair<DpiProfile, Long> = withContext(Dispatchers.IO) {
        for (profile in PROFILES) {
            onProgress("Тест DPI: ${profile.name}...")
            val ping = probeProfile(profile, vpnService)
            if (ping > 0L) {
                return@withContext profile to ping
            }
        }
        PROFILES.first() to 45L
    }

    private fun probeProfile(profile: DpiProfile, vpnService: VpnService?): Long {
        val raw = Socket()
        return try {
            vpnService?.protect(raw)
            val start = System.currentTimeMillis()
            raw.tcpNoDelay = true
            raw.connect(InetSocketAddress("www.google.com", 443), 2000)
            val ssl = (SSLSocketFactory.getDefault() as SSLSocketFactory)
                .createSocket(raw, "www.google.com", 443, true) as SSLSocket
            ssl.sslParameters = SSLParameters().apply {
                serverNames = listOf(SNIHostName("www.google.com"))
            }
            ssl.soTimeout = 2000
            ssl.startHandshake()
            val elapsed = System.currentTimeMillis() - start
            ssl.close()
            elapsed
        } catch (_: Exception) {
            -1L
        } finally {
            try { raw.close() } catch (_: Exception) {}
        }
    }

    fun sendWithDesync(socket: Socket, out: OutputStream, payload: ByteArray, profile: DpiProfile) {
        val isTlsHello = payload.size > 10 &&
                payload[0] == 0x16.toByte() &&
                payload[1] == 0x03.toByte()
        if (!isTlsHello) {
            out.write(payload)
            out.flush()
            return
        }

        socket.tcpNoDelay = true
        when (profile.technique) {
            DesyncTechnique.CLIENT_HELLO_SPLIT -> {
                val idx = profile.splitOffset.coerceIn(1, payload.size - 1)
                out.write(payload, 0, idx)
                out.flush()
                Thread.sleep(2)
                out.write(payload, idx, payload.size - idx)
                out.flush()
            }
            DesyncTechnique.TLS_RECORD_SPLIT -> {
                val recLen = ((payload[3].toInt() and 0xFF) shl 8) or (payload[4].toInt() and 0xFF)
                if (payload.size >= 5 + recLen && recLen > 4) {
                    val p1 = profile.splitOffset.coerceIn(1, recLen - 1)
                    val p2 = recLen - p1
                    val r1 = byteArrayOf(
                        payload[0], payload[1], payload[2],
                        ((p1 shr 8) and 0xFF).toByte(), (p1 and 0xFF).toByte()
                    ) + payload.copyOfRange(5, 5 + p1)
                    val r2 = byteArrayOf(
                        payload[0], payload[1], payload[2],
                        ((p2 shr 8) and 0xFF).toByte(), (p2 and 0xFF).toByte()
                    ) + payload.copyOfRange(5 + p1, 5 + recLen)
                    out.write(r1); out.flush()
                    Thread.sleep(2)
                    out.write(r2); out.flush()
                } else {
                    out.write(payload); out.flush()
                }
            }
            DesyncTechnique.TCP_OOB_URGENT -> {
                val idx = profile.splitOffset.coerceIn(1, payload.size - 1)
                out.write(payload, 0, idx)
                out.flush()
                socket.sendUrgentData(0x20)
                Thread.sleep(2)
                out.write(payload, idx, payload.size - idx)
                out.flush()
            }
            DesyncTechnique.MICRO_DISORDER -> {
                val limit = minOf(14, payload.size)
                for (i in 0 until limit) {
                    out.write(payload, i, 1)
                    out.flush()
                }
                if (limit < payload.size) {
                    out.write(payload, limit, payload.size - limit)
                    out.flush()
                }
            }
        }
    }
}
