package com.whitez.hybrid.core

import android.net.Uri
import org.json.JSONArray
import org.json.JSONObject
import java.net.InetSocketAddress
import java.net.Socket

/**
 * Мост к Xray/V2Ray ядру.
 * Поднимает локальный SOCKS5-прокси на 127.0.0.1:10808 из выбранного узла подписки
 * (VLESS / Reality / Trojan / VMess), куда WhitezHybridVpnService отправляет трафик.
 */
object XrayCoreBridge {

    const val LOCAL_SOCKS_HOST = "127.0.0.1"
    const val LOCAL_SOCKS_PORT = 10808

    @Volatile
    var isCoreRunning: Boolean = false
        private set

    fun buildXrayJsonConfig(node: VpnNode): String {
        val uri = Uri.parse(node.rawUri)
        val uuid = uri.userInfo ?: ""
        val sni = uri.getQueryParameter("sni") ?: node.host
        val pbk = uri.getQueryParameter("pbk") ?: ""
        val sid = uri.getQueryParameter("sid") ?: ""
        val security = uri.getQueryParameter("security") ?: "none"
        val flow = uri.getQueryParameter("flow") ?: ""
        val type = uri.getQueryParameter("type") ?: "tcp"

        val inbound = JSONObject().apply {
            put("port", LOCAL_SOCKS_PORT)
            put("listen", LOCAL_SOCKS_HOST)
            put("protocol", "socks")
            put("settings", JSONObject().put("udp", true))
        }

        val vnextUser = JSONObject().apply {
            put("id", uuid)
            put("encryption", "none")
            if (flow.isNotBlank()) put("flow", flow)
        }

        val vnextItem = JSONObject().apply {
            put("address", node.host)
            put("port", node.port)
            put("users", JSONArray().put(vnextUser))
        }

        val streamSettings = JSONObject().apply {
            put("network", type)
            put("security", security)
            if (security == "reality") {
                put("realitySettings", JSONObject().apply {
                    put("serverName", sni)
                    put("fingerprint", uri.getQueryParameter("fp") ?: "chrome")
                    put("publicKey", pbk)
                    put("shortId", sid)
                })
            } else if (security == "tls") {
                put("tlsSettings", JSONObject().apply {
                    put("serverName", sni)
                })
            }
        }

        val outbound = JSONObject().apply {
            put("protocol", node.protocol.lowercase())
            put("settings", JSONObject().put("vnext", JSONArray().put(vnextItem)))
            put("streamSettings", streamSettings)
        }

        return JSONObject().apply {
            put("inbounds", JSONArray().put(inbound))
            put("outbounds", JSONArray().put(outbound))
        }.toString(2)
    }

    fun startCore(node: VpnNode): Boolean {
        val configJson = buildXrayJsonConfig(node)
        return try {
            // Если в app/libs/ подключён libv2ray.aar (AndroidLibXrayLite), вызываем через рефлексию
            val clazz = Class.forName("libv2ray.Libv2ray")
            val controller = clazz.getMethod("newCoreController", Any::class.java).invoke(null, null)
            controller.javaClass.getMethod("startLoop", String::class.java).invoke(controller, configJson)
            isCoreRunning = true
            true
        } catch (_: Exception) {
            // Если libv2ray.aar ещё не добавлен при сборке, проверяем внешний локальный SOCKS5
            isCoreRunning = isLocalSocksAlive()
            isCoreRunning
        }
    }

    fun stopCore() {
        isCoreRunning = false
    }

    fun isLocalSocksAlive(): Boolean {
        return try {
            Socket().use { s ->
                s.connect(InetSocketAddress(LOCAL_SOCKS_HOST, LOCAL_SOCKS_PORT), 300)
                true
            }
        } catch (_: Exception) {
            false
        }
    }
}
