package com.whitez.hybrid.ui

import android.app.Activity
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.net.VpnService
import android.os.Build
import android.os.Bundle
import android.view.View
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ProgressBar
import android.widget.TextView
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import androidx.lifecycle.lifecycleScope
import com.whitez.hybrid.R
import com.whitez.hybrid.core.SubscriptionManager
import com.whitez.hybrid.vpn.WhitezHybridVpnService
import kotlinx.coroutines.launch

class MainActivity : AppCompatActivity() {

    private lateinit var powerContainer: LinearLayout
    private lateinit var tvPowerLabel: TextView
    private lateinit var tvPowerSub: TextView
    private lateinit var progressConnect: ProgressBar
    private lateinit var tvStatusBadge: TextView
    private lateinit var tvServerName: TextView
    private lateinit var tvPingBadge: TextView
    private lateinit var tvDpiStrategy: TextView
    private lateinit var tvModeTitle: TextView
    private lateinit var tvModeDesc: TextView
    private lateinit var cardModeSelector: LinearLayout
    private lateinit var cardSubscription: LinearLayout

    private val vpnLauncher = registerForActivityResult(
        ActivityResultContracts.StartActivityForResult()
    ) { res ->
        if (res.resultCode == Activity.RESULT_OK) {
            startTunnel()
        } else {
            Toast.makeText(this, "Разрешите VPN-профиль для работы WHITEZ", Toast.LENGTH_SHORT).show()
        }
    }

    private val telemetryReceiver = object : BroadcastReceiver() {
        override fun onReceive(context: Context?, intent: Intent?) {
            val state = intent?.getStringExtra(WhitezHybridVpnService.EXTRA_STATE) ?: return
            val statusText = intent.getStringExtra(WhitezHybridVpnService.EXTRA_STATUS_TEXT) ?: ""
            val node = intent.getStringExtra(WhitezHybridVpnService.EXTRA_ACTIVE_NODE) ?: ""
            val dpi = intent.getStringExtra(WhitezHybridVpnService.EXTRA_ACTIVE_DPI) ?: ""
            val ping = intent.getLongExtra(WhitezHybridVpnService.EXTRA_PING_MS, 0L)
            renderUi(state, statusText, node, dpi, ping)
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        powerContainer = findViewById(R.id.powerContainer)
        tvPowerLabel = findViewById(R.id.tvPowerLabel)
        tvPowerSub = findViewById(R.id.tvPowerSub)
        progressConnect = findViewById(R.id.progressConnect)
        tvStatusBadge = findViewById(R.id.tvStatusBadge)
        tvServerName = findViewById(R.id.tvServerName)
        tvPingBadge = findViewById(R.id.tvPingBadge)
        tvDpiStrategy = findViewById(R.id.tvDpiStrategy)
        tvModeTitle = findViewById(R.id.tvModeTitle)
        tvModeDesc = findViewById(R.id.tvModeDesc)
        cardModeSelector = findViewById(R.id.cardModeSelector)
        cardSubscription = findViewById(R.id.cardSubscription)

        powerContainer.setOnClickListener {
            if (WhitezHybridVpnService.currentState == WhitezHybridVpnService.STATE_IDLE) {
                requestPermissionAndStart()
            } else {
                stopTunnel()
            }
        }

        cardModeSelector.setOnClickListener {
            cycleOperationMode()
        }

        cardSubscription.setOnClickListener {
            showSubscriptionDialog()
        }

        refreshModeCard()
        preloadServerInfo()

        renderUi(
            WhitezHybridVpnService.currentState,
            if (WhitezHybridVpnService.currentState == WhitezHybridVpnService.STATE_CONNECTED)
                SubscriptionManager.getOperationMode(this).title
            else
                "Готов к подключению",
            WhitezHybridVpnService.activeNodeTitle,
            WhitezHybridVpnService.activeDpiTitle,
            WhitezHybridVpnService.currentPingMs
        )
    }

    override fun onStart() {
        super.onStart()
        val filter = IntentFilter(WhitezHybridVpnService.BROADCAST_TELEMETRY)
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            registerReceiver(telemetryReceiver, filter, RECEIVER_NOT_EXPORTED)
        } else {
            registerReceiver(telemetryReceiver, filter)
        }
    }

    override fun onStop() {
        super.onStop()
        unregisterReceiver(telemetryReceiver)
    }

    private fun preloadServerInfo() {
        lifecycleScope.launch {
            val nodes = SubscriptionManager.syncAndMeasureNodes(this@MainActivity)
            val best = nodes.firstOrNull()
            if (best != null) {
                tvServerName.text = "${best.name} (${best.protocol})"
                tvPingBadge.text = if (best.pingMs > 0) "${best.pingMs} мс" else "ONLINE"
            } else {
                tvServerName.text = "31.59.207.13 (Подписка подключена)"
                tvPingBadge.text = "READY"
            }
        }
    }

    private fun cycleOperationMode() {
        val modes = SubscriptionManager.OperationMode.values()
        val current = SubscriptionManager.getOperationMode(this)
        val next = modes[(current.ordinal + 1) % modes.size]
        SubscriptionManager.saveOperationMode(this, next)
        refreshModeCard()

        if (WhitezHybridVpnService.currentState == WhitezHybridVpnService.STATE_CONNECTED) {
            Toast.makeText(this, "Режим изменён: ${next.title}. Перезапуск...", Toast.LENGTH_SHORT).show()
            stopTunnel()
            powerContainer.postDelayed({ startTunnel() }, 350)
        }
    }

    private fun refreshModeCard() {
        val mode = SubscriptionManager.getOperationMode(this)
        tvModeTitle.text = mode.title
        tvModeDesc.text = mode.subtitle
    }

    private fun showSubscriptionDialog() {
        val input = EditText(this).apply {
            setText(SubscriptionManager.getSubscriptionUrl(this@MainActivity))
            setTextColor(0xFFFFFFFF.toInt())
            setHintTextColor(0xFF6B7280.toInt())
            setPadding(40, 32, 40, 32)
        }
        AlertDialog.Builder(this)
            .setTitle("Ссылка подписки VPN")
            .setMessage("Вшита твоя подписка. При необходимости можно заменить ссылку и нажать «Обновить».")
            .setView(input)
            .setPositiveButton("Обновить") { _, _ ->
                SubscriptionManager.saveSubscriptionUrl(this, input.text.toString())
                preloadServerInfo()
                Toast.makeText(this, "Подписка обновлена", Toast.LENGTH_SHORT).show()
            }
            .setNegativeButton("Отмена", null)
            .show()
    }

    private fun requestPermissionAndStart() {
        val intent = VpnService.prepare(this)
        if (intent != null) {
            vpnLauncher.launch(intent)
        } else {
            startTunnel()
        }
    }

    private fun startTunnel() {
        val intent = Intent(this, WhitezHybridVpnService::class.java).apply {
            action = WhitezHybridVpnService.ACTION_START
        }
        ContextCompat.startForegroundService(this, intent)
    }

    private fun stopTunnel() {
        val intent = Intent(this, WhitezHybridVpnService::class.java).apply {
            action = WhitezHybridVpnService.ACTION_STOP
        }
        startService(intent)
    }

    private fun renderUi(
        state: String,
        statusText: String,
        node: String,
        dpi: String,
        ping: Long
    ) {
        if (node.isNotBlank()) tvServerName.text = node
        if (dpi.isNotBlank()) tvDpiStrategy.text = "DPI: $dpi"
        if (ping > 0L) tvPingBadge.text = "$ping мс"

        when (state) {
            WhitezHybridVpnService.STATE_IDLE -> {
                progressConnect.visibility = View.GONE
                powerContainer.setBackgroundResource(R.drawable.bg_power_ring_idle)
                tvPowerLabel.text = "ПОДКЛЮЧИТЬ"
                tvPowerSub.text = "1 нажатие"
                tvStatusBadge.text = "● ОТКЛЮЧЕНО"
                tvStatusBadge.setTextColor(0xFF8A94A6.toInt())
            }
            WhitezHybridVpnService.STATE_CONNECTING -> {
                progressConnect.visibility = View.VISIBLE
                powerContainer.setBackgroundResource(R.drawable.bg_power_ring_idle)
                tvPowerLabel.text = "НАСТРОЙКА"
                tvPowerSub.text = "Автоподбор..."
                tvStatusBadge.text = "● $statusText"
                tvStatusBadge.setTextColor(0xFFF59E0B.toInt())
            }
            WhitezHybridVpnService.STATE_CONNECTED -> {
                progressConnect.visibility = View.GONE
                powerContainer.setBackgroundResource(R.drawable.bg_power_ring_active)
                tvPowerLabel.text = "АКТИВНО"
                tvPowerSub.text = "Нажмите для стопа"
                tvStatusBadge.text = "● ЗАЩИЩЕНО • $statusText"
                tvStatusBadge.setTextColor(0xFF10B981.toInt())
            }
        }
    }
}
