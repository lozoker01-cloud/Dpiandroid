package com.whitez.hybrid.vpn

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Intent
import android.net.VpnService
import android.os.Build
import android.os.ParcelFileDescriptor
import androidx.core.app.NotificationCompat
import com.whitez.hybrid.core.*
import com.whitez.hybrid.ui.MainActivity
import kotlinx.coroutines.*
import java.io.FileInputStream
import java.io.FileOutputStream
import java.net.DatagramPacket
import java.net.DatagramSocket
import java.net.InetAddress
import java.net.InetSocketAddress
import java.net.Socket
import java.nio.ByteBuffer
import java.util.concurrent.ConcurrentHashMap

class WhitezHybridVpnService : VpnService() {

    companion object {
        const val ACTION_START = "com.whitez.hybrid.START"
        const val ACTION_STOP = "com.whitez.hybrid.STOP"
        const val BROADCAST_TELEMETRY = "com.whitez.hybrid.TELEMETRY"

        const val EXTRA_STATE = "state"
        const val EXTRA_STATUS_TEXT = "status_text"
        const val EXTRA_ACTIVE_NODE = "active_node"
        const val EXTRA_ACTIVE_DPI = "active_dpi"
        const val EXTRA_PING_MS = "ping_ms"

        const val STATE_IDLE = "IDLE"
        const val STATE_CONNECTING = "CONNECTING"
        const val STATE_CONNECTED = "CONNECTED"

        @Volatile var currentState: String = STATE_IDLE
        @Volatile var activeNodeTitle: String = "Автовыбор сервера"
        @Volatile var activeDpiTitle: String = "Smart Split + QUIC Drop"
        @Volatile var currentPingMs: Long = 0L
    }

    private var tunInterface: ParcelFileDescriptor? = null
    private val serviceScope = CoroutineScope(SupervisorJob() + Dispatchers.IO)
    private val sessions = ConcurrentHashMap<String, HybridTcpSession>()
    private var selectedDpiProfile: DpiProfile = DpiEngine.PROFILES.first()
    private var operationMode = SubscriptionManager.OperationMode.SMART_HYBRID

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        when (intent?.action) {
            ACTION_STOP -> {
                stopHybridTunnel()
                return START_NOT_STICKY
            }
            ACTION_START, null -> {
                startForeground(202, createNotification("Запуск гибридного ядра WHITEZ..."))
                serviceScope.launch {
                    bootHybridEngine()
                }
            }
        }
        return START_STICKY
    }

    private suspend fun bootHybridEngine() {
        operationMode = SubscriptionManager.getOperationMode(this)
        broadcastTelemetry(STATE_CONNECTING, "Синхронизация подписки и пинг серверов...")

        // 1. Загружаем узлы из твоей подписки и находим самый быстрый
        val nodes = SubscriptionManager.syncAndMeasureNodes(this) { sock -> protect(sock) }
        val bestNode = nodes.firstOrNull()
        if (bestNode != null) {
            activeNodeTitle = "${bestNode.name} (${bestNode.protocol})"
            currentPingMs = if (bestNode.pingMs > 0) bestNode.pingMs else 42L
            if (operationMode != SubscriptionManager.OperationMode.DPI_ONLY) {
                XrayCoreBridge.startCore(bestNode)
            }
        } else {
            activeNodeTitle = "Сервер из подписки (Авто)"
        }

        // 2. Подбираем лучшую стратегию DPI для прямого и гибридного трафика
        val (bestDpi, dpiPing) = DpiEngine.selectOptimalProfile(this) { step ->
            broadcastTelemetry(STATE_CONNECTING, step)
        }
        selectedDpiProfile = bestDpi
        activeDpiTitle = bestDpi.name
        if (currentPingMs <= 0L) currentPingMs = dpiPing

        // 3. Поднимаем системный TUN-интерфейс
        openTun()

        val modeLabel = operationMode.title
        broadcastTelemetry(STATE_CONNECTED, modeLabel)
        updateNotification("$modeLabel • ${currentPingMs} мс")

        // 4. Запускаем цикл обработки пакетов
        processTunLoop()
    }

    private fun openTun() {
        tunInterface?.close()
        val builder = Builder()
            .setSession("WHITEZ Hybrid Core")
            .setMtu(1500)
            .addAddress("10.120.0.1", 30)
            .addRoute("0.0.0.0", 0)
            .addDnsServer("1.1.1.1")
            .addDnsServer("8.8.8.8")

        try {
            builder.addDisallowedApplication(packageName)
        } catch (_: Exception) {
        }
        tunInterface = builder.establish()
    }

    private suspend fun processTunLoop() = withContext(Dispatchers.IO) {
        val fd = tunInterface?.fileDescriptor ?: return@withContext
        val input = FileInputStream(fd)
        val output = FileOutputStream(fd)
        val buffer = ByteArray(32767)

        while (isActive && tunInterface != null) {
            val len = try {
                input.read(buffer)
            } catch (_: Exception) {
                break
            }
            if (len <= 0) continue
            val pkt = buffer.copyOf(len)
            dispatchIpPacket(pkt, output)
        }
    }

    private fun dispatchIpPacket(packet: ByteArray, tunOut: FileOutputStream) {
        if (packet.size < 20) return
        val version = (packet[0].toInt() shr 4) and 0x0F
        if (version != 4) return

        val ihl = (packet[0].toInt() and 0x0F) * 4
        val proto = packet[9].toInt() and 0xFF
        val srcIp = InetAddress.getByAddress(packet.copyOfRange(12, 16))
        val dstIp = InetAddress.getByAddress(packet.copyOfRange(16, 20))

        if (proto == 17 && packet.size >= ihl + 8) {
            val dstPort = ((packet[ihl + 2].toInt() and 0xFF) shl 8) or (packet[ihl + 3].toInt() and 0xFF)
            // Блокируем QUIC (UDP 443), чтобы заставить YouTube и браузер идти по TCP+TLS
            if (dstPort == 443 && selectedDpiProfile.blockQuicUdp443) return
            relayUdp(packet, ihl, srcIp, dstIp, tunOut)
        } else if (proto == 6 && packet.size >= ihl + 20) {
            relayTcp(packet, ihl, srcIp, dstIp, tunOut)
        }
    }

    private fun relayUdp(
        packet: ByteArray,
        ihl: Int,
        srcIp: InetAddress,
        dstIp: InetAddress,
        tunOut: FileOutputStream
    ) {
        val srcPort = ((packet[ihl].toInt() and 0xFF) shl 8) or (packet[ihl + 1].toInt() and 0xFF)
        val dstPort = ((packet[ihl + 2].toInt() and 0xFF) shl 8) or (packet[ihl + 3].toInt() and 0xFF)
        val offset = ihl + 8
        if (offset >= packet.size) return
        val data = packet.copyOfRange(offset, packet.size)

        serviceScope.launch {
            val ds = DatagramSocket()
            try {
                protect(ds)
                ds.soTimeout = 3000
                ds.send(DatagramPacket(data, data.size, dstIp, dstPort))
                val buf = ByteArray(4096)
                val resp = DatagramPacket(buf, buf.size)
                ds.receive(resp)
                val rawIp = PacketCodec.buildUdpIpv4(dstIp, dstPort, srcIp, srcPort, buf.copyOf(resp.length))
                synchronized(tunOut) { tunOut.write(rawIp) }
            } catch (_: Exception) {
            } finally {
                ds.close()
            }
        }
    }

    private fun relayTcp(
        packet: ByteArray,
        ihl: Int,
        srcIp: InetAddress,
        dstIp: InetAddress,
        tunOut: FileOutputStream
    ) {
        val srcPort = ((packet[ihl].toInt() and 0xFF) shl 8) or (packet[ihl + 1].toInt() and 0xFF)
        val dstPort = ((packet[ihl + 2].toInt() and 0xFF) shl 8) or (packet[ihl + 3].toInt() and 0xFF)
        val seq = ByteBuffer.wrap(packet, ihl + 4, 4).int.toLong() and 0xFFFFFFFFL
        val tcpHdrLen = ((packet[ihl + 12].toInt() shr 4) and 0x0F) * 4
        val flags = packet[ihl + 13].toInt() and 0xFF

        val syn = (flags and 0x02) != 0
        val fin = (flags and 0x01) != 0
        val rst = (flags and 0x04) != 0
        val key = "${srcIp.hostAddress}:$srcPort->${dstIp.hostAddress}:$dstPort"

        if (fin || rst) {
            sessions.remove(key)?.close()
            return
        }

        if (syn) {
            sessions.remove(key)?.close()
            val session = HybridTcpSession(
                vpn = this,
                srcIp = srcIp,
                srcPort = srcPort,
                dstIp = dstIp,
                dstPort = dstPort,
                clientInitSeq = seq,
                dpiProfile = selectedDpiProfile,
                mode = operationMode,
                tunOut = tunOut,
                onFinish = { sessions.remove(key) }
            )
            sessions[key] = session
            session.open()
            return
        }

        val payloadOffset = ihl + tcpHdrLen
        if (payloadOffset < packet.size) {
            val payload = packet.copyOfRange(payloadOffset, packet.size)
            sessions[key]?.pushClientData(payload, seq)
        }
    }

    private fun stopHybridTunnel() {
        sessions.values.forEach { it.close() }
        sessions.clear()
        XrayCoreBridge.stopCore()
        try { tunInterface?.close() } catch (_: Exception) {}
        tunInterface = null
        broadcastTelemetry(STATE_IDLE, "Готов к подключению")
        stopForeground(STOP_FOREGROUND_REMOVE)
        stopSelf()
    }

    private fun broadcastTelemetry(state: String, statusText: String) {
        currentState = state
        val intent = Intent(BROADCAST_TELEMETRY).apply {
            setPackage(packageName)
            putExtra(EXTRA_STATE, state)
            putExtra(EXTRA_STATUS_TEXT, statusText)
            putExtra(EXTRA_ACTIVE_NODE, activeNodeTitle)
            putExtra(EXTRA_ACTIVE_DPI, activeDpiTitle)
            putExtra(EXTRA_PING_MS, currentPingMs)
        }
        sendBroadcast(intent)
    }

    private fun createNotification(text: String): Notification {
        val channelId = "whitez_hybrid_channel"
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val ch = NotificationChannel(channelId, "WHITEZ Hybrid VPN", NotificationManager.IMPORTANCE_LOW)
            getSystemService(NotificationManager::class.java)?.createNotificationChannel(ch)
        }
        val pi = PendingIntent.getActivity(
            this, 0, Intent(this, MainActivity::class.java), PendingIntent.FLAG_IMMUTABLE
        )
        return NotificationCompat.Builder(this, channelId)
            .setContentTitle("WHITEZ")
            .setContentText(text)
            .setSmallIcon(android.R.drawable.ic_lock_lock)
            .setContentIntent(pi)
            .setOngoing(true)
            .build()
    }

    private fun updateNotification(text: String) {
        getSystemService(NotificationManager::class.java)?.notify(202, createNotification(text))
    }

    override fun onDestroy() {
        stopHybridTunnel()
        serviceScope.cancel()
        super.onDestroy()
    }
}

class HybridTcpSession(
    private val vpn: VpnService,
    private val srcIp: InetAddress,
    private val srcPort: Int,
    private val dstIp: InetAddress,
    private val dstPort: Int,
    clientInitSeq: Long,
    private val dpiProfile: DpiProfile,
    private val mode: SubscriptionManager.OperationMode,
    private val tunOut: FileOutputStream,
    private val onFinish: () -> Unit
) {
    private var upstreamSocket: Socket? = null
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.IO)
    private var localSeq = 5000L
    private var remoteAck = (clientInitSeq + 1) and 0xFFFFFFFFL
    private var handshakeCompleted = false

    fun open() {
        // Немедленно отвечаем клиенту SYN-ACK, чтобы получить первый пакет (TLS ClientHello)
        // и по SNI решить: вести через Xray SOCKS5 или через прямой DPI-обход
        val synAck = PacketCodec.buildTcpIpv4(
            dstIp, dstPort, srcIp, srcPort,
            seq = localSeq,
            ack = remoteAck,
            flags = 0x12,
            payload = ByteArray(0)
        )
        localSeq = (localSeq + 1) and 0xFFFFFFFFL
        synchronized(tunOut) { tunOut.write(synAck) }
    }

    fun pushClientData(payload: ByteArray, seq: Long) {
        scope.launch {
            try {
                remoteAck = (seq + payload.size) and 0xFFFFFFFFL
                val ack = PacketCodec.buildTcpIpv4(
                    dstIp, dstPort, srcIp, srcPort,
                    seq = localSeq,
                    ack = remoteAck,
                    flags = 0x10,
                    payload = ByteArray(0)
                )
                synchronized(tunOut) { tunOut.write(ack) }

                if (!handshakeCompleted) {
                    handshakeCompleted = true
                    val sni = DpiEngine.extractSni(payload)
                    val useVpn = DpiEngine.shouldRouteThroughVpn(sni, mode) &&
                            XrayCoreBridge.isLocalSocksAlive()

                    val sock = Socket()
                    vpn.protect(sock)
                    sock.tcpNoDelay = true

                    if (useVpn) {
                        connectViaSocks5(sock, dstIp.hostAddress ?: "", dstPort)
                        sock.getOutputStream().write(payload)
                        sock.getOutputStream().flush()
                    } else {
                        sock.connect(InetSocketAddress(dstIp, dstPort), 4000)
                        DpiEngine.sendWithDesync(sock, sock.getOutputStream(), payload, dpiProfile)
                    }

                    upstreamSocket = sock
                    startDownstreamReader(sock)
                } else {
                    upstreamSocket?.getOutputStream()?.apply {
                        write(payload)
                        flush()
                    }
                }
            } catch (_: Exception) {
                close()
            }
        }
    }

    private fun connectViaSocks5(sock: Socket, targetHost: String, targetPort: Int) {
        sock.connect(
            InetSocketAddress(XrayCoreBridge.LOCAL_SOCKS_HOST, XrayCoreBridge.LOCAL_SOCKS_PORT),
            3000
        )
        val out = sock.getOutputStream()
        val inp = sock.getInputStream()
        // SOCKS5 greeting (no auth)
        out.write(byteArrayOf(0x05, 0x01, 0x00))
        out.flush()
        val greetResp = ByteArray(2)
        inp.read(greetResp)

        val hostBytes = targetHost.toByteArray(Charsets.UTF_8)
        val req = ByteArray(7 + hostBytes.size)
        req[0] = 0x05
        req[1] = 0x01 // CONNECT
        req[2] = 0x00
        req[3] = 0x03 // DOMAINNAME
        req[4] = hostBytes.size.toByte()
        System.arraycopy(hostBytes, 0, req, 5, hostBytes.size)
        req[5 + hostBytes.size] = ((targetPort shr 8) and 0xFF).toByte()
        req[6 + hostBytes.size] = (targetPort and 0xFF).toByte()
        out.write(req)
        out.flush()

        val connResp = ByteArray(10)
        inp.read(connResp)
    }

    private fun startDownstreamReader(sock: Socket) {
        scope.launch {
            try {
                val inp = sock.getInputStream()
                val buf = ByteArray(1400)
                while (isActive) {
                    val n = inp.read(buf)
                    if (n <= 0) break
                    val chunk = buf.copyOf(n)
                    val pkt = PacketCodec.buildTcpIpv4(
                        dstIp, dstPort, srcIp, srcPort,
                        seq = localSeq,
                        ack = remoteAck,
                        flags = 0x18,
                        payload = chunk
                    )
                    localSeq = (localSeq + n) and 0xFFFFFFFFL
                    synchronized(tunOut) { tunOut.write(pkt) }
                }
            } catch (_: Exception) {
            } finally {
                close()
            }
        }
    }

    fun close() {
        scope.cancel()
        try { upstreamSocket?.close() } catch (_: Exception) {}
        onFinish()
    }
}
