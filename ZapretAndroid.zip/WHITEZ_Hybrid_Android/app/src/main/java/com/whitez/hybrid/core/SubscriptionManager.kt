package com.whitez.hybrid.core

import android.content.Context
import android.net.Uri
import android.util.Base64
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.net.HttpURLConnection
import java.net.InetSocketAddress
import java.net.Socket
import java.net.URL
import java.net.URLDecoder

data class VpnNode(
    val id: String,
    val name: String,
    val protocol: String, // vless, vmess, trojan, ss
    val host: String,
    val port: Int,
    val rawUri: String,
    var pingMs: Long = -1L
)

object SubscriptionManager {
    private const val PREFS_NAME = "whitez_hybrid_prefs"
    private const val KEY_SUB_URL = "subscription_url"
    private const val KEY_CACHED_RAW = "cached_subscription_raw"
    private const val KEY_OPERATION_MODE = "operation_mode"

    // Вшитая по умолчанию твоя рабочая подписка из v2rayTun
    const val DEFAULT_SUBSCRIPTION_URL =
        "http://31.59.207.13:2096/511gttxhtbu86vr5/8ojmix9ue0g2zd6y"

    enum class OperationMode(val title: String, val subtitle: String) {
        SMART_HYBRID(
            "Гибрид: DPI + Свой VPN",
            "Авто-DPI для РФ-сервисов + твой VLESS/Xray для заблокированного"
        ),
        DPI_ONLY(
            "Только Auto-DPI (Без VPN)",
            "Мгновенный обход ТСПУ напрямую без смены IP и потери скорости"
        ),
        FULL_VPN(
            "Весь трафик через Свой VPN",
            "100% трафика через твой сервер (с DPI-фрагментацией поверх)"
        )
    }

    fun getSubscriptionUrl(context: Context): String {
        val prefs = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
        return prefs.getString(KEY_SUB_URL, DEFAULT_SUBSCRIPTION_URL) ?: DEFAULT_SUBSCRIPTION_URL
    }

    fun saveSubscriptionUrl(context: Context, url: String) {
        context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
            .edit()
            .putString(KEY_SUB_URL, url.trim())
            .apply()
    }

    fun getOperationMode(context: Context): OperationMode {
        val prefs = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
        val name = prefs.getString(KEY_OPERATION_MODE, OperationMode.SMART_HYBRID.name)
        return try {
            OperationMode.valueOf(name ?: OperationMode.SMART_HYBRID.name)
        } catch (_: Exception) {
            OperationMode.SMART_HYBRID
        }
    }

    fun saveOperationMode(context: Context, mode: OperationMode) {
        context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
            .edit()
            .putString(KEY_OPERATION_MODE, mode.name)
            .apply()
    }

    /**
     * Загружает подписку по ссылке, декодирует Base64 / plain список узлов (VLESS/VMess/Trojan)
     * и измеряет реальный TCP-пинг до каждого сервера.
     */
    suspend fun syncAndMeasureNodes(
        context: Context,
        protectSocket: ((Socket) -> Unit)? = null
    ): List<VpnNode> = withContext(Dispatchers.IO) {
        val subUrl = getSubscriptionUrl(context)
        val prefs = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)

        val rawPayload = try {
            val conn = (URL(subUrl).openConnection() as HttpURLConnection).apply {
                connectTimeout = 5000
                readTimeout = 5000
                setRequestProperty("User-Agent", "v2rayTun/3.0 WHITEZ/3.0")
            }
            val text = conn.inputStream.bufferedReader().use { it.readText() }.trim()
            prefs.edit().putString(KEY_CACHED_RAW, text).apply()
            text
        } catch (_: Exception) {
            prefs.getString(KEY_CACHED_RAW, "") ?: ""
        }

        val nodes = parseSubscriptionContent(rawPayload)
        nodes.forEach { node ->
            node.pingMs = measureTcpPing(node.host, node.port, protectSocket)
        }
        nodes.sortedBy { if (it.pingMs < 0) Long.MAX_VALUE else it.pingMs }
    }

    fun parseSubscriptionContent(raw: String): List<VpnNode> {
        if (raw.isBlank()) return emptyList()
        val decoded = if (
            raw.startsWith("vless://") ||
            raw.startsWith("vmess://") ||
            raw.startsWith("trojan://") ||
            raw.startsWith("ss://")
        ) {
            raw
        } else {
            try {
                String(Base64.decode(raw, Base64.DEFAULT), Charsets.UTF_8)
            } catch (_: Exception) {
                raw
            }
        }

        return decoded.lines()
            .map { it.trim() }
            .filter { it.contains("://") }
            .mapIndexedNotNull { idx, line -> parseSingleUri(idx, line) }
    }

    private fun parseSingleUri(index: Int, rawUri: String): VpnNode? {
        return try {
            val schemeEnd = rawUri.indexOf("://")
            if (schemeEnd <= 0) return null
            val protocol = rawUri.substring(0, schemeEnd).lowercase()
            val uri = Uri.parse(rawUri)
            val host = uri.host ?: return null
            val port = if (uri.port > 0) uri.port else 443
            val fragment = uri.fragment?.let {
                try { URLDecoder.decode(it, "UTF-8") } catch (_: Exception) { it }
            }
            val displayName = fragment?.takeIf { it.isNotBlank() } ?: "WHITEZ Server #${index + 1}"
            VpnNode(
                id = "node_$index",
                name = displayName,
                protocol = protocol.uppercase(),
                host = host,
                port = port,
                rawUri = rawUri
            )
        } catch (_: Exception) {
            null
        }
    }

    private fun measureTcpPing(
        host: String,
        port: Int,
        protectSocket: ((Socket) -> Unit)?
    ): Long {
        val socket = Socket()
        return try {
            protectSocket?.invoke(socket)
            val start = System.currentTimeMillis()
            socket.connect(InetSocketAddress(host, port), 2500)
            System.currentTimeMillis() - start
        } catch (_: Exception) {
            -1L
        } finally {
            try { socket.close() } catch (_: Exception) {}
        }
    }
}
