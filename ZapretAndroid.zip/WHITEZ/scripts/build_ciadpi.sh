#!/usr/bin/env bash
# Собирает движок обхода DPI (ciadpi из hufrea/byedpi) под Android и кладёт в app/src/main/jniLibs/<abi>/libciadpi.so
set -euo pipefail
ROOT="$(cd "$(dirname "$0")/.." && pwd)"
NDK="${ANDROID_NDK_LATEST_HOME:-${ANDROID_NDK_HOME:-${ANDROID_NDK_ROOT:-}}}"
[ -n "$NDK" ] || { echo "NDK не найден"; exit 1; }
TC="$NDK/toolchains/llvm/prebuilt/linux-x86_64/bin"
rm -rf /tmp/byedpi
git clone --depth 1 https://github.com/hufrea/byedpi /tmp/byedpi
cd /tmp/byedpi
SRC=$(ls *.c | grep -v win_service.c | tr '\n' ' ')
echo "Sources: $SRC"
for pair in "arm64-v8a:aarch64-linux-android29" "armeabi-v7a:armv7a-linux-androideabi29" "x86_64:x86_64-linux-android29"; do
  abi="${pair%%:*}"; tgt="${pair##*:}"
  out="$ROOT/app/src/main/jniLibs/$abi"
  mkdir -p "$out"
  "$TC/${tgt}-clang" -O2 -std=gnu99 -D_DEFAULT_SOURCE -D_GNU_SOURCE -fPIE -pie -I. $SRC -o "$out/libciadpi.so"
  "$TC/llvm-strip" "$out/libciadpi.so" || true
  ls -la "$out/libciadpi.so"
done
