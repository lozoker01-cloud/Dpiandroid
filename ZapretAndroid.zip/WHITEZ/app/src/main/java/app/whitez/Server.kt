package app.whitez
import android.util.Base64
import java.net.URI
import java.net.URLDecoder

data class Server(val name: String, val host: String, val port: Int, val link: String,
                  val params: Map<String, String>, val uuid: String, var pingMs: Long = -1)

object SubscriptionParser {
    fun decode(body: String): List<String> {
        val t = body.trim()
        val text = if (t.contains("://")) t else try {
            String(Base64.decode(t, Base64.DEFAULT or Base64.URL_SAFE))
        } catch (e: Exception) { t }
        return text.lines().map { it.trim() }.filter { it.startsWith("vless://") }
    }
    fun parse(link: String): Server? = try {
        val u = URI(link.substringBefore("#"))
        val q = (u.rawQuery ?: "").split("&").filter { it.contains("=") }.associate {
            it.substringBefore("=") to URLDecoder.decode(it.substringAfter("="), "UTF-8") }
        val name = URLDecoder.decode(link.substringAfter("#", "server"), "UTF-8")
        Server(name, u.host, u.port, link, q, u.userInfo)
    } catch (e: Exception) { null }
}
