package app.whitez
import org.json.JSONArray
import org.json.JSONObject

object XrayConfig {
    fun build(s: Server): String {
        val p = s.params
        val stream = JSONObject().put("network", p["type"] ?: "tcp").put("security", p["security"] ?: "none")
        when (p["security"]) {
            "reality" -> stream.put("realitySettings", JSONObject()
                .put("serverName", p["sni"] ?: "").put("fingerprint", p["fp"] ?: "chrome")
                .put("publicKey", p["pbk"] ?: "").put("shortId", p["sid"] ?: "")
                .put("spiderX", p["spx"] ?: ""))
            "tls" -> stream.put("tlsSettings", JSONObject()
                .put("serverName", p["sni"] ?: s.host).put("fingerprint", p["fp"] ?: "chrome"))
        }
        val user = JSONObject().put("id", s.uuid).put("encryption", p["encryption"] ?: "none")
        p["flow"]?.let { if (it.isNotEmpty()) user.put("flow", it) }
        val out = JSONObject().put("tag", "proxy").put("protocol", "vless").put("settings",
            JSONObject().put("vnext", JSONArray().put(JSONObject().put("address", s.host)
                .put("port", s.port).put("users", JSONArray().put(user)))))
            .put("streamSettings", stream)
        val direct = JSONObject().put("tag", "direct").put("protocol", "freedom")
        return JSONObject()
            .put("log", JSONObject().put("loglevel", "warning"))
            .put("inbounds", JSONArray().put(JSONObject().put("tag", "socks").put("port", 10808)
                .put("listen", "127.0.0.1").put("protocol", "socks")
                .put("settings", JSONObject().put("udp", true))
                .put("sniffing", JSONObject().put("enabled", true)
                    .put("destOverride", JSONArray().put("http").put("tls")))))
            .put("outbounds", JSONArray().put(out).put(direct))
            .toString()
    }
}
