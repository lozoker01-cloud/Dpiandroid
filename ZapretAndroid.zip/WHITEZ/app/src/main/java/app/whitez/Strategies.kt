package app.whitez

data class Strategy(val id: Int, val name: String, val args: List<String>) {
    val cmd get() = if (args.isEmpty()) "без параметров (контроль)" else args.joinToString(" ")
}

data class Svc(val id: String, val short: String, val name: String, val urls: List<String>)

object Services {
    val all = listOf(
        Svc("yt", "YT", "YouTube", listOf("www.youtube.com", "redirector.googlevideo.com", "i.ytimg.com")),
        Svc("ds", "DS", "Discord", listOf("discord.com", "cdn.discordapp.com", "gateway.discord.gg")),
        Svc("tg", "TG", "Telegram", listOf("web.telegram.org", "telegram.org")),
        Svc("ig", "IG", "Instagram", listOf("www.instagram.com")),
        Svc("x", "X", "X / Twitter", listOf("x.com"))
    )
}

/** Приложения, трафик которых идёт через обход (режим "только выбранные"). */
object Apps {
    val list = listOf(
        "com.google.android.youtube", "com.google.android.apps.youtube.music", "app.revanced.android.youtube",
        "com.discord", "org.telegram.messenger", "org.telegram.messenger.web", "org.thunderdog.challegram",
        "com.instagram.android", "com.twitter.android", "com.whatsapp",
        "com.android.chrome", "org.mozilla.firefox", "org.mozilla.fenix", "com.yandex.browser",
        "com.opera.browser", "com.microsoft.emmx", "com.brave.browser", "com.sec.android.app.sbrowser",
        "com.mi.globalbrowser", "com.android.browser"
    ).toTypedArray()
}

object Strategies {
    private fun s(id: Int, name: String, cmd: String) = Strategy(id, name, cmd.trim().split(Regex("\\s+")))

    val baseline = Strategy(0, "Без обхода", emptyList())

    // Источники: byebyedpi.org (v1.8.2), hufrea/byedpi issue 393 (2026), сообщество ByeDPIAndroid (2024-2025)
    val all = listOf(
        s(1,  "Disorder + TLS-rec",        "--disorder 1 --tlsrec 1+s --udp-fake 1"),
        s(2,  "Адаптивная SSL",            "--fake -1 --ttl 8 --auto=ssl_err --fake -1 --ttl 5 --udp-fake 1"),
        s(3,  "Fake TTL 8",                "--fake -1 --ttl 8 --udp-fake 1"),
        s(4,  "Split + Disorder + OOB",    "--split 1+s --disorder 3+s --oob 1+s --udp-fake 1"),
        s(5,  "Цепочка split (v1.6)",      "-Kt,h -d1 -s0+s -d3+s -s6+s -d9+s -s12+s -d15+s -s20+s -d25+s -s30+s -d35+s -An -Ku -a1 -An"),
        s(6,  "Цепочка + auto (2025)",     "-Ku -a1 -An -d1 -s0+s -d3+s -s6+s -d9+s -s12+s -d15+s -s20+s -d25+s -s30+s -d35+s -At,r,s -s1 -q1 -At,r,s -s5 -o25000+s -At,r,s -o1 -d1 -r1+s -t10 -b1500 -s0+s -d3+s -At,r,s -f-1 -r1+s -At,r,s -s1 -o1+s -s-1"),
        s(7,  "OOB + TLS-rec (2026)",      "-o1 -d3 -s8 -s8+s -o30+s -r26+s -T5 -At -X -b 65536"),
        s(8,  "Fake + SNI google (2026)",  "-o1 -r-5+se -a1 -At,r,s -d1 -n google.com -Qr -f-1 -a1"),
        s(9,  "Длинная цепочка (2026)",    "-d1 -d3+s -s6+s -d9+s -s12+s -d15+s -s20+s -d25+s -s30+s -d35+s -r1+s -S -a1 -As -d1 -d3+s -s6+s -d9+s -s12+s -d15+s -s20+s -d25+s -s30+s -d35+s -S -a1"),
        s(10, "Цепочка 443/80/53",         "-d1+s -O1 -s29+s -t 5 -An -Ku -a5 -s443+s -d80+s -d443+s -s80+s -s443+s -d53+s -s53+s -d443+s -An"),
        s(11, "Auto torst / ssl",          "-s1 -d1 -o1 -Ar -o3 -At -f-1 -r1+s -As"),
        s(12, "OOB для googlevideo",       "-H:googlevideo.com -o1 -An"),
        s(13, "Цепочка split/disorder",    "-d1 -s0+s -d3+s -s6+s -d9+s -s12+s -d15+s -s20+s -d25+s -s30+s -d35+s"),
        s(14, "Split SNI",                 "--split 1+s"),
        s(15, "Disorder",                  "--disorder 1"),
        s(16, "Split + TLS-rec",           "--split 1+s --tlsrec 1+s"),
        s(17, "OOB",                       "--oob 3+s"),
        s(18, "Fake TTL 5",                "--fake -1 --ttl 5"),
        s(19, "Fake TTL 10",               "--fake -1 --ttl 10"),
        s(20, "TLS-rec глубокий",          "--tlsrec 3+s"),
        s(21, "Disorder + TLS-rec + Fake", "--disorder 1 --tlsrec 1+s --fake -1 --ttl 8")
    )
    fun byId(id: Int) = if (id == 0) baseline else all.firstOrNull { it.id == id } ?: all[0]
}

data class StrategyResult(
    val strategy: Strategy,
    val passed: Set<String> = emptySet(),
    val avgMs: Long = -1,
    val speedKb: Long = -1,
    val error: String? = null,
    val tested: Boolean = false
) { val score get() = passed.size }
