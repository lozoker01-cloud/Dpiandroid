package app.whitez

data class Strategy(val id: Int, val name: String, val args: List<String>) {
    val cmd get() = args.joinToString(" ")
}

data class Svc(val id: String, val short: String, val name: String, val urls: List<String>)

object Services {
    val all = listOf(
        Svc("yt", "YT", "YouTube", listOf("https://www.youtube.com/", "https://redirector.googlevideo.com/", "https://i.ytimg.com/")),
        Svc("ds", "DS", "Discord", listOf("https://discord.com/", "https://cdn.discordapp.com/", "https://gateway.discord.gg/")),
        Svc("tg", "TG", "Telegram", listOf("https://web.telegram.org/", "https://telegram.org/")),
        Svc("ig", "IG", "Instagram", listOf("https://www.instagram.com/")),
        Svc("x", "X", "X / Twitter", listOf("https://x.com/"))
    )
}

object Strategies {
    private fun s(id: Int, name: String, cmd: String) = Strategy(id, name, cmd.trim().split(Regex("\\s+")))

    val all = listOf(
        s(1,  "Split SNI",              "--split 1+s"),
        s(2,  "Disorder SNI",           "--disorder 1+s"),
        s(3,  "Split + TLS-rec",        "--split 1+s --tlsrec 1+s"),
        s(4,  "Disorder + TLS-rec",     "--disorder 1 --tlsrec 1+s --udp-fake 1"),
        s(5,  "Disorder глубокий",      "--disorder 3+s"),
        s(6,  "OOB",                    "--oob 1+s"),
        s(7,  "OOB + Disorder",         "--oob 1+s --disorder 3+s --udp-fake 2"),
        s(8,  "Disoob",                 "--disoob 1+s"),
        s(9,  "Fake TTL 8",             "--fake -1 --ttl 8"),
        s(10, "Fake TTL 5",             "--fake -1 --ttl 5"),
        s(11, "Fake TTL 10 + Disorder", "--fake -1 --ttl 10 --disorder 3+s"),
        s(12, "Fake MD5",               "--fake -1 --md5sig"),
        s(13, "Split + Fake",           "--split 1+s --fake -1 --ttl 8"),
        s(14, "Адаптивная SSL",         "--fake -1 --ttl 8 --auto=ssl_err --fake -1 --ttl 5 --udp-fake 1"),
        s(15, "Auto torst + TLS-rec",   "--auto=torst --timeout 3 --tlsrec 3+s"),
        s(16, "Auto torst + Disorder",  "--disorder 1 --auto=torst --tlsrec 1+s"),
        s(17, "Auto alert/sid",         "--fake -1 --ttl 10 --auto=alert,sid_inv --fake -1 --ttl 5"),
        s(18, "Split + Disorder",       "--split 1+s --disorder 3+s"),
        s(19, "Дробление 2/5",          "--split 2 --disorder 5+s"),
        s(20, "TLS-rec + Split",        "--tlsrec 2+s --split 1+s"),
        s(21, "Disorder + Split + UDP", "--disorder 1 --split 5+s --udp-fake 2")
    )
    fun byId(id: Int) = all.firstOrNull { it.id == id } ?: all[3]
}

data class StrategyResult(
    val strategy: Strategy,
    val passed: Set<String> = emptySet(),
    val avgMs: Long = -1,
    val error: String? = null,
    val tested: Boolean = false
) { val score get() = passed.size }
