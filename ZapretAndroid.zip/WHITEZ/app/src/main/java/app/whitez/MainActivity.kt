package app.whitez
import android.app.Activity
import android.net.VpnService
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.activity.viewModels
import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.core.*
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

object W {
    val Bg = Color(0xFF0C0D10)
    val Bg2 = Color(0xFF12141A)
    val Card = Color(0xFF15171D)
    val Card2 = Color(0xFF1C1F27)
    val Line = Color(0x16FFFFFF)
    val Fg = Color(0xFFECEEF2)
    val Sub = Color(0xFF8A90A0)
    val Accent = Color(0xFFB4C2FF)
    val Ok = Color(0xFF9ADBB8)
    val Warn = Color(0xFFE8C48A)
}

class MainActivity : ComponentActivity() {
    private val vm: MainViewModel by viewModels()
    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        window.statusBarColor = 0xFF0C0D10.toInt()
        window.navigationBarColor = 0xFF12141A.toInt()
        if (android.os.Build.VERSION.SDK_INT >= 33)
            requestPermissions(arrayOf(android.Manifest.permission.POST_NOTIFICATIONS), 1)
        setContent {
            MaterialTheme(colorScheme = darkColorScheme(primary = W.Accent, background = W.Bg, surface = W.Card)) { Screen(vm) }
        }
    }
}

@Composable
fun Panel(modifier: Modifier = Modifier, border: Color = W.Line, bg: Color = W.Card,
          content: @Composable ColumnScope.() -> Unit) {
    val shape = RoundedCornerShape(22.dp)
    Column(modifier.fillMaxWidth().clip(shape).background(bg).border(1.dp, border, shape).padding(16.dp),
        content = content)
}

@Composable
fun SoftButton(text: String, enabled: Boolean = true, onClick: () -> Unit) {
    val shape = RoundedCornerShape(16.dp)
    val c = if (enabled) W.Accent else W.Sub
    Box(Modifier.fillMaxWidth().clip(shape).background(c.copy(alpha = 0.10f))
        .border(1.dp, c.copy(alpha = 0.35f), shape)
        .clickable(enabled = enabled, onClick = onClick).padding(vertical = 15.dp),
        contentAlignment = Alignment.Center) {
        Text(text, color = c, fontSize = 14.sp, fontWeight = FontWeight.Medium, letterSpacing = 0.5.sp)
    }
}

@Composable
fun Segmented(mode: String, onSelect: (String) -> Unit) {
    val shape = RoundedCornerShape(16.dp)
    Row(Modifier.fillMaxWidth().clip(shape).background(W.Card).border(1.dp, W.Line, shape).padding(4.dp)) {
        listOf("dpi" to "Обход", "vpn" to "VPN").forEach { (id, label) ->
            val sel = mode == id
            val bg by animateColorAsState(if (sel) W.Card2 else Color.Transparent, label = "seg")
            Box(Modifier.weight(1f).clip(RoundedCornerShape(12.dp)).background(bg)
                .clickable { onSelect(id) }.padding(vertical = 11.dp), contentAlignment = Alignment.Center) {
                Text(label, color = if (sel) W.Fg else W.Sub, fontSize = 14.sp,
                    fontWeight = if (sel) FontWeight.Medium else FontWeight.Normal)
            }
        }
    }
}

@Composable
fun PowerRing(on: Boolean, enabled: Boolean, title: String, subtitle: String, onClick: () -> Unit) {
    val accent by animateColorAsState(if (on) W.Ok else W.Accent, animationSpec = tween(600), label = "acc")
    val sweep by animateFloatAsState(if (on) 360f else 80f, animationSpec = tween(900), label = "sweep")
    val pulse by rememberInfiniteTransition(label = "p").animateFloat(
        0.55f, 1f, infiniteRepeatable(tween(2600, easing = FastOutSlowInEasing), RepeatMode.Reverse), label = "pulse")
    Column(horizontalAlignment = Alignment.CenterHorizontally) {
        Box(Modifier.size(210.dp).clip(CircleShape).clickable(
            interactionSource = remember { MutableInteractionSource() }, indication = null,
            enabled = enabled, onClick = onClick), contentAlignment = Alignment.Center) {
            Canvas(Modifier.fillMaxSize()) {
                val glow = if (on) 0.26f * pulse else 0.12f * pulse
                drawCircle(Brush.radialGradient(listOf(accent.copy(alpha = glow), Color.Transparent),
                    radius = size.minDimension / 2))
                val stroke = 5.dp.toPx(); val inset = 30.dp.toPx()
                val d = size.minDimension - inset * 2
                drawCircle(Color.White.copy(alpha = 0.06f), radius = d / 2, style = Stroke(stroke))
                drawArc(Brush.sweepGradient(listOf(accent.copy(alpha = 0.15f), accent)),
                    startAngle = -90f, sweepAngle = sweep, useCenter = false,
                    topLeft = Offset(inset, inset), size = Size(d, d), style = Stroke(stroke, cap = StrokeCap.Round))
                drawCircle(Brush.verticalGradient(listOf(W.Card2, W.Card)), radius = d / 2 - 14.dp.toPx())
            }
            Text(if (on) "ВКЛ" else "ВЫКЛ", color = if (enabled) W.Fg else W.Sub,
                fontSize = 20.sp, fontWeight = FontWeight.Light, letterSpacing = 4.sp)
        }
        Spacer(Modifier.height(6.dp))
        Text(title, color = W.Fg, fontSize = 17.sp, fontWeight = FontWeight.Medium, textAlign = TextAlign.Center)
        Spacer(Modifier.height(3.dp))
        Text(subtitle, color = W.Sub, fontSize = 13.sp, textAlign = TextAlign.Center)
    }
}

@Composable
fun Screen(vm: MainViewModel) {
    val mode by vm.mode.collectAsState()
    val running by State.running.collectAsState()
    val active by State.activeMode.collectAsState()
    val err by State.error.collectAsState()
    val results by vm.results.collectAsState()
    val testing by vm.testing.collectAsState()
    val progress by vm.progress.collectAsState()
    val strategy by vm.strategy.collectAsState()
    val onlyApps by vm.onlyApps.collectAsState()
    val dpiStatus by vm.dpiStatus.collectAsState()
    val url by vm.url.collectAsState()
    val servers by vm.servers.collectAsState()
    val status by vm.status.collectAsState()
    val busy by vm.busy.collectAsState()
    val sel by vm.selected.collectAsState()
    val ctx = LocalContext.current
    val perm = rememberLauncherForActivityResult(ActivityResultContracts.StartActivityForResult()) {
        if (it.resultCode == Activity.RESULT_OK) vm.start()
    }
    val on = running && active == mode
    val canStart = if (mode == "dpi") vm.engineOk else sel != null
    val bestResult = results.firstOrNull { it.strategy.id == strategy.id }

    LazyColumn(
        Modifier.fillMaxSize().background(Brush.verticalGradient(listOf(W.Bg, W.Bg2)))
            .statusBarsPadding().navigationBarsPadding(),
        contentPadding = PaddingValues(horizontal = 20.dp, vertical = 18.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        item {
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically) {
                Text("WHITEZ", color = W.Fg, fontSize = 20.sp, fontWeight = FontWeight.Medium, letterSpacing = 7.sp)
                Text(if (on) "защищено" else "не активно", color = if (on) W.Ok else W.Sub, fontSize = 12.sp)
            }
        }
        item { Segmented(mode) { vm.setMode(it) } }
        item {
            Box(Modifier.fillMaxWidth(), contentAlignment = Alignment.Center) {
                PowerRing(
                    on = on, enabled = canStart && !testing,
                    title = if (mode == "dpi") strategy.name else (sel?.label ?: "Сервер не выбран"),
                    subtitle = when {
                        err != null -> "Ошибка: $err"
                        mode == "dpi" -> if (vm.engineOk) "Стратегия №${strategy.id} из ${Strategies.all.size}" else "Движок не найден в APK"
                        else -> status
                    }
                ) {
                    if (on) vm.stop() else {
                        val i = VpnService.prepare(ctx)
                        if (i != null) perm.launch(i) else vm.start()
                    }
                }
            }
        }

        if (mode == "dpi") {
            item {
                Panel {
                    Text("Сервисы", color = W.Sub, fontSize = 12.sp, letterSpacing = 1.sp)
                    Spacer(Modifier.height(12.dp))
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                        Services.all.forEach { svc ->
                            val tested = bestResult?.tested == true
                            val ok = bestResult?.passed?.contains(svc.id) == true
                            val c = when { !tested -> W.Sub.copy(alpha = 0.5f); ok -> W.Ok; else -> W.Warn }
                            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                                Box(Modifier.size(8.dp).background(c, CircleShape))
                                Spacer(Modifier.height(6.dp))
                                Text(svc.name, color = if (tested) W.Fg else W.Sub, fontSize = 11.sp)
                            }
                        }
                    }
                }
            }
            item {
                Panel {
                    Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                        Column(Modifier.weight(1f)) {
                            Text("Только нужные приложения", color = W.Fg, fontSize = 14.sp, fontWeight = FontWeight.Medium)
                            Spacer(Modifier.height(2.dp))
                            Text("YouTube, Discord, Telegram, Instagram, X и браузеры. Остальной трафик идёт напрямую — быстрее и меньше задержек.",
                                color = W.Sub, fontSize = 11.sp)
                        }
                        Spacer(Modifier.width(12.dp))
                        Switch(checked = onlyApps, onCheckedChange = { vm.setOnlyApps(it) }, enabled = !running,
                            colors = SwitchDefaults.colors(checkedThumbColor = W.Bg, checkedTrackColor = W.Ok,
                                uncheckedThumbColor = W.Sub, uncheckedTrackColor = W.Card2, uncheckedBorderColor = W.Line))
                    }
                }
            }
            item {
                Column {
                    SoftButton(if (testing) "Проверка…  $progress/${Strategies.all.size}" else "Тест всех стратегий (${Strategies.all.size})",
                        enabled = !testing && vm.engineOk && !running) { vm.testAll() }
                    if (testing) {
                        Spacer(Modifier.height(10.dp))
                        LinearProgressIndicator(progress = { progress / Strategies.all.size.toFloat() },
                            modifier = Modifier.fillMaxWidth().height(3.dp).clip(CircleShape),
                            color = W.Accent, trackColor = W.Line)
                    }
                    Spacer(Modifier.height(8.dp))
                    Text(dpiStatus, color = W.Sub, fontSize = 12.sp, modifier = Modifier.fillMaxWidth(), textAlign = TextAlign.Center)
                    if (running) Text("Остановите обход, чтобы запустить тест", color = W.Sub.copy(alpha = 0.7f),
                        fontSize = 11.sp, modifier = Modifier.fillMaxWidth(), textAlign = TextAlign.Center)
                }
            }
            items(results, key = { it.strategy.id }) { r ->
                val chosen = r.strategy.id == strategy.id
                Panel(
                    Modifier.clickable(enabled = !running) { vm.selectStrategy(r.strategy) },
                    border = if (chosen) W.Accent.copy(alpha = 0.55f) else W.Line,
                    bg = if (chosen) W.Card2 else W.Card
                ) {
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically) {
                        Text("${r.strategy.id}. ${r.strategy.name}", color = W.Fg, fontSize = 15.sp,
                            fontWeight = FontWeight.Medium, modifier = Modifier.weight(1f))
                        Text(
                            when {
                                !r.tested -> "—"
                                r.error != null -> r.error
                                r.score == 0 -> "не работает"
                                r.speedKb > 0 -> "${r.avgMs} мс · ${r.speedKb} КБ/с"
                                else -> "${r.avgMs} мс"
                            },
                            color = when { !r.tested -> W.Sub; r.score == 0 || r.error != null -> W.Warn; else -> W.Ok }, fontSize = 12.sp)
                    }
                    Spacer(Modifier.height(4.dp))
                    Text(r.strategy.cmd, color = W.Sub, fontSize = 11.sp, fontFamily = FontFamily.Monospace)
                    Spacer(Modifier.height(10.dp))
                    Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                        Services.all.forEach { svc ->
                            val c = when { !r.tested -> W.Sub.copy(alpha = 0.4f); r.passed.contains(svc.id) -> W.Ok; else -> W.Sub.copy(alpha = 0.35f) }
                            Text(svc.short, color = c, fontSize = 11.sp, fontWeight = FontWeight.Medium)
                        }
                    }
                }
            }
        } else {
            item {
                Panel {
                    Text("Подписка", color = W.Sub, fontSize = 12.sp, letterSpacing = 1.sp)
                    Spacer(Modifier.height(10.dp))
                    OutlinedTextField(url, vm::setUrl, placeholder = { Text("Ссылка подписки") },
                        singleLine = true, shape = RoundedCornerShape(14.dp), modifier = Modifier.fillMaxWidth(),
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedBorderColor = W.Accent.copy(alpha = 0.6f), unfocusedBorderColor = W.Line))
                }
            }
            item { SoftButton(if (busy) "Подождите…" else "Обновить и выбрать лучший", enabled = !busy && url.isNotBlank()) { vm.refresh() } }
            items(servers) { s ->
                val ms = if (s.realMs >= 0) s.realMs else s.pingMs
                val chosen = s == sel
                Panel(Modifier.clickable { vm.selected.value = s },
                    border = if (chosen) W.Accent.copy(alpha = 0.55f) else W.Line,
                    bg = if (chosen) W.Card2 else W.Card) {
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically) {
                        Text(s.label, color = W.Fg, fontSize = 14.sp, modifier = Modifier.weight(1f))
                        Text(if (ms < 0) "—" else "$ms мс", color = if (ms in 0..300) W.Ok else W.Warn, fontSize = 12.sp)
                    }
                }
            }
        }
    }
}
