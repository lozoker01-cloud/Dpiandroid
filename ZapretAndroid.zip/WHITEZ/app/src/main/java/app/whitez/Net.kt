package app.whitez
import kotlinx.coroutines.*
import java.net.HttpURLConnection
import java.net.InetSocketAddress
import java.net.Socket
import java.net.URL

object Net {
    suspend fun fetchSubscription(url: String): List<Server> = withContext(Dispatchers.IO) {
        val c = URL(url).openConnection() as HttpURLConnection
        c.connectTimeout = 8000; c.readTimeout = 8000
        c.setRequestProperty("User-Agent", "v2rayTun/WHITEZ")
        val body = c.inputStream.bufferedReader().readText()
        SubscriptionParser.decode(body).mapNotNull { SubscriptionParser.parse(it) }
    }
    // TCP-пинг: среднее из 3 замеров, -1 если недоступен
    suspend fun ping(s: Server): Long = withContext(Dispatchers.IO) {
        val r = (1..3).map {
            try {
                val t = System.nanoTime()
                Socket().use { it.connect(InetSocketAddress(s.host, s.port), 2500) }
                (System.nanoTime() - t) / 1_000_000
            } catch (e: Exception) { -1L }
        }.filter { it >= 0 }
        if (r.isEmpty()) -1 else r.average().toLong()
    }
    suspend fun pingAll(list: List<Server>): List<Server> = coroutineScope {
        list.map { s -> async { s.apply { pingMs = ping(s) } } }.awaitAll()
            .sortedBy { if (it.pingMs < 0) Long.MAX_VALUE else it.pingMs }
    }
}
