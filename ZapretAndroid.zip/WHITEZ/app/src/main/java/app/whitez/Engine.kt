package app.whitez
import android.content.Context
import kotlinx.coroutines.*
import java.io.File
import java.net.HttpURLConnection
import java.net.InetSocketAddress
import java.net.Proxy
import java.net.URL

/** Движок обхода DPI: нативный ciadpi (ByeDPI) запускается как локальный SOCKS5-прокси. */
object Engine {
    fun binary(ctx: Context) = File(ctx.applicationInfo.nativeLibraryDir, "libciadpi.so")
    fun available(ctx: Context) = binary(ctx).exists()

    fun spawn(ctx: Context, port: Int, args: List<String>): Process {
        val cmd = listOf(binary(ctx).absolutePath, "-i", "127.0.0.1", "-p", port.toString()) + args
        val p = ProcessBuilder(cmd).redirectErrorStream(true).start()
        Thread {
            try { val buf = ByteArray(2048); while (p.inputStream.read(buf) >= 0) { } } catch (_: Exception) {}
        }.start()
        return p
    }

    private fun probe(url: String, proxy: Proxy): Long {
        return try {
            val t = System.nanoTime()
            val c = URL(url).openConnection(proxy) as HttpURLConnection
            c.connectTimeout = 4000; c.readTimeout = 4000
            c.instanceFollowRedirects = false
            c.setRequestProperty("Connection", "close")
            c.setRequestProperty("User-Agent", "Mozilla/5.0 (Linux; Android 14) Chrome/124 Mobile")
            c.responseCode
            c.disconnect()
            (System.nanoTime() - t) / 1_000_000
        } catch (e: Exception) { -1L }
    }

    suspend fun test(ctx: Context, st: Strategy, port: Int): StrategyResult = withContext(Dispatchers.IO) {
        val p = try { spawn(ctx, port, st.args) } catch (e: Exception) {
            return@withContext StrategyResult(st, error = "нет движка", tested = true)
        }
        try {
            delay(400)
            if (!p.isAlive) return@withContext StrategyResult(st, error = "не запустилась", tested = true)
            val proxy = Proxy(Proxy.Type.SOCKS, InetSocketAddress("127.0.0.1", port))
            val res = coroutineScope {
                Services.all.map { svc ->
                    async { svc to svc.urls.map { u -> async { probe(u, proxy) } }.awaitAll() }
                }.awaitAll()
            }
            val passed = res.filter { (_, r) -> r.all { it >= 0 } }.map { it.first.id }.toSet()
            val times = res.flatMap { it.second }.filter { it >= 0 }
            StrategyResult(st, passed, if (times.isEmpty()) -1 else times.average().toLong(), null, true)
        } finally { p.destroy() }
    }
}
