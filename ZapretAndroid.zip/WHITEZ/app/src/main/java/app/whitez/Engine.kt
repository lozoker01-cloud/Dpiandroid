package app.whitez
import android.content.Context
import android.os.Build
import kotlinx.coroutines.*
import kotlinx.coroutines.sync.Semaphore
import kotlinx.coroutines.sync.withPermit
import org.json.JSONObject
import java.io.File
import java.net.HttpURLConnection
import java.net.InetAddress
import java.net.InetSocketAddress
import java.net.Proxy
import java.net.Socket
import java.net.URL
import java.util.concurrent.ConcurrentHashMap
import javax.net.ssl.SSLSocket
import javax.net.ssl.SSLSocketFactory

object Engine {
    @Volatile var ispDns = true
    @Volatile var lastRr: String? = null

    fun binary(ctx: Context) = File(ctx.applicationInfo.nativeLibraryDir, "libciadpi.so")
    fun available(ctx: Context) = binary(ctx).exists()

    fun diag(ctx: Context): String {
        val dir = File(ctx.applicationInfo.nativeLibraryDir)
        val files = dir.list()?.joinToString(", ") ?: "папка не найдена"
        return "Движок не найден. ABI: ${Build.SUPPORTED_ABIS.joinToString("/")}; в ${dir.name}: $files"
    }

    class Proc(val p: Process, val out: StringBuilder)

    fun spawnProc(ctx: Context, port: Int, args: List<String>, onLine: ((String) -> Unit)? = null): Proc {
        val bin = binary(ctx)
        bin.setExecutable(true, false)
        val cmd = listOf(bin.absolutePath, "-i", "127.0.0.1", "-p", port.toString()) + args
        val p = ProcessBuilder(cmd).redirectErrorStream(true).start()
        val sb = StringBuilder()
        Thread {
            try {
                p.inputStream.bufferedReader().forEachLine { l ->
                    if (sb.length < 400) sb.append(l).append('\n')
                    onLine?.invoke(l)
                }
            } catch (_: Exception) {}
        }.start()
        return Proc(p, sb)
    }

    fun spawn(ctx: Context, port: Int, args: List<String>, onLine: ((String) -> Unit)? = null): Process =
        spawnProc(ctx, port, args, onLine).p

    private val dohCache = ConcurrentHashMap<String, List<String>>()

    fun resolveDoh(host: String): List<String> {
        dohCache[host]?.let { return it }
        val res = try {
            val c = URL("https://1.1.1.1/dns-query?name=$host&type=A").openConnection() as HttpURLConnection
            c.connectTimeout = 3000; c.readTimeout = 3000
            c.setRequestProperty("accept", "application/dns-json")
            val j = JSONObject(c.inputStream.bufferedReader().readText())
            val arr = j.optJSONArray("Answer")
            val l = mutableListOf<String>()
            if (arr != null) for (i in 0 until arr.length()) {
                val a = arr.getJSONObject(i); if (a.optInt("type") == 1) l.add(a.getString("data"))
            }
            l
        } catch (e: Exception) { emptyList() }
        if (res.isNotEmpty()) dohCache[host] = res
        return res
    }

    private fun resolveSys(host: String): List<String> = try {
        InetAddress.getAllByName(host).filter { it.address.size == 4 }.mapNotNull { it.hostAddress }
    } catch (e: Exception) { emptyList() }

    fun resolve(host: String): List<String> {
        if (ispDns) { val s = resolveSys(host); if (s.isNotEmpty()) return s }
        val d = resolveDoh(host)
        return if (d.isNotEmpty()) d else resolveSys(host)
    }

    suspend fun dnsReport(): String? = withContext(Dispatchers.IO) {
        val bad = mutableListOf<String>()
        for (h in listOf("www.youtube.com", "discord.com", "www.instagram.com")) {
            val sys = resolveSys(h)
            val doh = resolveDoh(h)
            val fake = sys.any { it.startsWith("0.") || it.startsWith("127.") || it.startsWith("10.") || it.startsWith("192.168.") }
            if (sys.isEmpty() || fake || (doh.isNotEmpty() && sys.intersect(doh.toSet()).isEmpty())) bad.add(h.removePrefix("www."))
        }
        if (bad.isEmpty()) null else "DNS провайдера, возможно, подменяется (${bad.joinToString()}). Выберите DNS Google в настройках"
    }

    private val rrFull = Regex("r{1,2}\\d+---sn-[a-z0-9-]+\\.googlevideo\\.com")
    private val rrShort = Regex("r{1,2}\\d+---sn-[a-z0-9-]+")
    @Volatile private var rrCache: Pair<String?, Long> = Pair(null, 0L)

    fun noteLine(s: String) { rrFull.find(s)?.value?.let { lastRr = it } }

    private fun fetchRr(port: Int?): String? = try {
        val ip = resolve("redirector.googlevideo.com").firstOrNull() ?: return null
        val raw = if (port != null) Socket(Proxy(Proxy.Type.SOCKS, InetSocketAddress("127.0.0.1", port))) else Socket()
        raw.connect(InetSocketAddress(InetAddress.getByAddress(ip.split(".").map { it.toInt().toByte() }.toByteArray()), 443), 3500)
        val ssl = (SSLSocketFactory.getDefault() as SSLSocketFactory).createSocket(raw, "redirector.googlevideo.com", 443, true) as SSLSocket
        try {
            ssl.soTimeout = 4000
            ssl.startHandshake()
            ssl.outputStream.write("GET /report_mapping?di=no HTTP/1.1\r\nHost: redirector.googlevideo.com\r\nUser-Agent: Mozilla/5.0\r\nAccept-Encoding: identity\r\nConnection: close\r\n\r\n".toByteArray())
            ssl.outputStream.flush()
            val sb = StringBuilder(); val buf = ByteArray(4096)
            while (sb.length < 32768) { val n = ssl.inputStream.read(buf); if (n < 0) break; sb.append(String(buf, 0, n)) }
            rrShort.find(sb.toString())?.value?.let { "$it.googlevideo.com" }
        } finally { try { ssl.close() } catch (_: Exception) {}; try { raw.close() } catch (_: Exception) {} }
    } catch (e: Exception) { null }

    fun rrHost(port: Int? = null): String? {
        val now = System.currentTimeMillis()
        if (now - rrCache.second < 10 * 60_000 && rrCache.first != null) return rrCache.first
        val h = fetchRr(null) ?: (if (port != null) fetchRr(port) else null)
        if (h != null) { rrCache = Pair(h, now); lastRr = h; return h }
        return lastRr
    }

    private fun tcpMs(ip: String): Long = try {
        val t = System.nanoTime()
        Socket().use { it.connect(InetSocketAddress(ip, 443), 2500) }
        (System.nanoTime() - t) / 1_000_000
    } catch (e: Exception) { -1L }

    suspend fun ipReport(): String = withContext(Dispatchers.IO) {
        val rr = rrHost()
        val hosts = listOfNotNull("www.youtube.com", "youtubei.googleapis.com", rr, "i.ytimg.com")
        class Row(val host: String, val label: String, val ip: String, val ms: Long)
        val rows = coroutineScope {
            hosts.flatMap { h ->
                val sys = resolveSys(h).take(2)
                val doh = resolveDoh(h).take(2)
                sys.map { ip -> async { Row(h, "провайдер", ip, tcpMs(ip)) } } + doh.map { ip -> async { Row(h, "Google", ip, tcpMs(ip)) } }
            }.awaitAll()
        }
        val sb = StringBuilder()
        sb.append(if (rr != null) "Узел видео: $rr\n" else "Узел видео не найден (redirector не ответил)\n")
        for (h in hosts) {
            sb.append(h).append('\n')
            rows.filter { it.host == h }.forEach { sb.append("  ${it.label}: ${it.ip} ${if (it.ms >= 0) "ок ${it.ms} мс" else "недоступен"}\n") }
        }
        fun ratio(l: List<Row>) = if (l.isEmpty()) -1.0 else l.count { it.ms >= 0 }.toDouble() / l.size
        val ri = ratio(rows.filter { it.label == "провайдер" }); val rg = ratio(rows.filter { it.label == "Google" })
        sb.append(when {
            ri <= 0.0 && rg <= 0.0 -> "Адреса Google недоступны напрямую: блокировка по IP, обход DPI не поможет."
            ri > rg + 0.01 -> "DNS провайдера даёт больше доступных адресов — выберите «Провайдера»."
            rg > ri + 0.01 -> "DNS Google даёт больше доступных адресов — выберите «Google»."
            else -> "TCP до адресов доходит при обоих DNS. Если видео не идёт, блокировка по имени сервера (SNI)."
        })
        sb.toString()
    }

    private class Probe(val ok: Boolean, val hsMs: Long, val kbps: Long)

    private const val MIN_BYTES = 64 * 1024

    private fun probe(host: String, port: Int, transfer: Boolean): Probe {
        val bad = Probe(false, -1, -1)
        return try {
            val ip = resolve(host).firstOrNull() ?: return bad
            val t = System.nanoTime()
            val proxy = Proxy(Proxy.Type.SOCKS, InetSocketAddress("127.0.0.1", port))
            val raw = Socket(proxy)
            raw.connect(InetSocketAddress(InetAddress.getByAddress(ip.split(".").map { it.toInt().toByte() }.toByteArray()), 443), 3500)
            val ssl = (SSLSocketFactory.getDefault() as SSLSocketFactory).createSocket(raw, host, 443, true) as SSLSocket
            try {
                ssl.soTimeout = 4000
                ssl.startHandshake()
                val hs = (System.nanoTime() - t) / 1_000_000
                val req = "GET / HTTP/1.1\r\nHost: $host\r\nUser-Agent: Mozilla/5.0 (Linux; Android 14) AppleWebKit/537.36 Chrome/124 Mobile Safari/537.36\r\nAccept-Encoding: identity\r\nConnection: close\r\n\r\n"
                ssl.outputStream.write(req.toByteArray()); ssl.outputStream.flush()
                val buf = ByteArray(16 * 1024)
                val need = if (transfer) MIN_BYTES else 1
                var total = 0; var eof = false
                var t1 = 0L
                val deadline = System.nanoTime() + 8_000_000_000L
                while (total < need && System.nanoTime() < deadline) {
                    val n = ssl.inputStream.read(buf)
                    if (n < 0) { eof = true; break }
                    if (total == 0) t1 = System.nanoTime()
                    total += n
                }
                val ok = total >= need || (eof && total > 0)
                val secs = (System.nanoTime() - t1) / 1e9
                val kb = if (transfer && total >= 32 * 1024 && secs > 0.05) (total / 1024.0 / secs).toLong() else -1L
                Probe(ok, hs, kb)
            } finally { try { ssl.close() } catch (_: Exception) {}; try { raw.close() } catch (_: Exception) {} }
        } catch (e: Exception) { bad }
    }

    private val gate = Semaphore(2)

    suspend fun test(ctx: Context, st: Strategy, port: Int): StrategyResult = gate.withPermit {
        withContext(Dispatchers.IO) {
            val pr = try { spawnProc(ctx, port, st.args) } catch (e: Exception) {
                return@withContext StrategyResult(st, error = "нет движка", tested = true)
            }
            val p = pr.p
            try {
                delay(500)
                if (!p.isAlive) {
                    delay(100)
                    val msg = pr.out.toString().trim().lines().firstOrNull { it.isNotBlank() }?.take(34) ?: "код ${p.exitValue()}"
                    return@withContext StrategyResult(st, error = msg, tested = true)
                }
                val rr = rrHost(port)
                val svcs = Services.all.map { svc ->
                    if (svc.id == "yt") svc.copy(urls = listOfNotNull("www.youtube.com", "youtubei.googleapis.com", rr, "i.ytimg.com")) else svc
                }
                fun keyN(svc: Svc) = if (svc.id == "yt") (if (rr != null) 3 else 2) else minOf(2, svc.urls.size)
                val auto = st.args.any { it.startsWith("-A") || it.startsWith("--auto") }
                val res = coroutineScope {
                    svcs.map { svc ->
                        async {
                            svc to svc.urls.mapIndexed { i, u ->
                                async {
                                    val first = probe(u, port, i == 0)
                                    if (auto) probe(u, port, i == 0) else first
                                }
                            }.awaitAll()
                        }
                    }.awaitAll()
                }
                val passed = res.filter { (svc, r) -> r.take(keyN(svc)).all { it.ok } }.map { it.first.id }.toSet()
                val hs = res.flatMap { it.second }.filter { it.ok }.map { it.hsMs }
                val sp = res.map { it.second.first() }.filter { it.ok && it.kbps > 0 }.map { it.kbps }
                StrategyResult(st, passed,
                    if (hs.isEmpty()) -1 else hs.average().toLong(),
                    if (sp.isEmpty()) -1 else sp.average().toLong(), null, true)
            } finally { p.destroy() }
        }
    }
}
