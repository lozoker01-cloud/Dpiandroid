package app.whitez
import android.app.Application
import android.content.Context
import android.content.Intent
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import kotlinx.coroutines.async
import kotlinx.coroutines.awaitAll
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.launch
import libv2ray.Libv2ray

object State {
    val running = MutableStateFlow(false)
    val activeMode = MutableStateFlow("")
    val error = MutableStateFlow<String?>(null)
}

class MainViewModel(app: Application) : AndroidViewModel(app) {
    private val prefs = app.getSharedPreferences("w", Context.MODE_PRIVATE)

    val mode = MutableStateFlow(prefs.getString("mode", "dpi") ?: "dpi")
    fun setMode(m: String) { mode.value = m; prefs.edit().putString("mode", m).apply() }

    // ---- DPI-режим
    val results = MutableStateFlow(Strategies.all.map { StrategyResult(it) })
    val testing = MutableStateFlow(false)
    val progress = MutableStateFlow(0)
    val strategy = MutableStateFlow(Strategies.byId(prefs.getInt("strategy", 4)))
    val dpiStatus = MutableStateFlow("Выберите стратегию или запустите тест")
    val engineOk = Engine.available(app)

    fun selectStrategy(s: Strategy) { strategy.value = s; prefs.edit().putInt("strategy", s.id).apply() }

    fun testAll() = viewModelScope.launch {
        if (!engineOk) { dpiStatus.value = "Движок обхода не найден в APK"; return@launch }
        testing.value = true; progress.value = 0
        results.value = Strategies.all.map { StrategyResult(it) }
        val ctx = getApplication<Application>()
        for (chunk in Strategies.all.chunked(4)) {
            dpiStatus.value = "Проверка… ${progress.value}/${Strategies.all.size}"
            val res = chunk.mapIndexed { i, s -> async { Engine.test(ctx, s, 21080 + i) } }.awaitAll()
            results.value = results.value.map { old -> res.firstOrNull { it.strategy.id == old.strategy.id } ?: old }
            progress.value += chunk.size
        }
        val sorted = results.value.sortedWith(
            compareByDescending<StrategyResult> { it.score }.thenBy { if (it.avgMs < 0) Long.MAX_VALUE else it.avgMs })
        results.value = sorted
        val best = sorted.first()
        if (best.score > 0) {
            selectStrategy(best.strategy)
            dpiStatus.value = "Лучшая: ${best.strategy.name} — ${best.score}/${Services.all.size} сервисов"
        } else dpiStatus.value = "Ни одна стратегия не сработала. Попробуйте режим VPN"
        testing.value = false
    }

    // ---- VPN-режим
    val url = MutableStateFlow(prefs.getString("url", "") ?: "")
    val servers = MutableStateFlow<List<Server>>(emptyList())
    val status = MutableStateFlow("Вставьте ссылку подписки")
    val busy = MutableStateFlow(false)
    val selected = MutableStateFlow<Server?>(null)

    init { try { Libv2ray.initCoreEnv(app.filesDir.path, "") } catch (_: Throwable) {} }

    fun setUrl(v: String) { url.value = v; prefs.edit().putString("url", v).apply() }

    fun refresh() = viewModelScope.launch {
        busy.value = true; status.value = "Загрузка подписки…"
        try {
            val list = Net.fetchSubscription(url.value)
            val ranked = Net.rank(list) { status.value = it }
            servers.value = ranked
            val best = ranked.firstOrNull { it.realMs >= 0 } ?: ranked.firstOrNull { it.pingMs >= 0 }
            selected.value = best
            status.value = best?.let {
                if (it.realMs >= 0) "Лучший: ${it.label} (${it.realMs} мс)" else "Лучший: ${it.label} (TCP ${it.pingMs} мс)"
            } ?: "Нет доступных узлов"
        } catch (e: Exception) { status.value = "Ошибка: ${e.message}" }
        busy.value = false
    }

    fun canStart(): Boolean = if (mode.value == "dpi") engineOk else selected.value != null

    fun start() {
        State.error.value = null
        val ctx = getApplication<Application>()
        val i = Intent(ctx, WhitezVpnService::class.java)
        if (mode.value == "dpi") {
            if (!engineOk) { State.error.value = "Движок обхода не найден"; return }
            i.putExtra("mode", "dpi").putExtra("args", strategy.value.args.toTypedArray())
        } else {
            val s = selected.value ?: return
            i.putExtra("mode", "vpn").putExtra("config", XrayConfig.build(s))
        }
        ctx.startForegroundService(i)
    }
    fun stop() {
        getApplication<Application>().startService(
            Intent(getApplication(), WhitezVpnService::class.java).setAction("STOP"))
    }
}
