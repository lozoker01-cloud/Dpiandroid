package app.whitez
import android.app.Application
import android.content.Context
import android.content.Intent
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import kotlinx.coroutines.async
import kotlinx.coroutines.awaitAll
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.launch
import libv2ray.Libv2ray
import java.io.File

object State {
    val running = MutableStateFlow(false)
    val activeMode = MutableStateFlow("")
    val error = MutableStateFlow<String?>(null)
    val log = MutableStateFlow("")
    fun addLog(s: String) { log.value = (log.value + s + "\n").takeLast(3000) }
}

class MainViewModel(app: Application) : AndroidViewModel(app) {
    private val prefs = app.getSharedPreferences("w", Context.MODE_PRIVATE)

    val mode = MutableStateFlow(prefs.getString("mode", "dpi") ?: "dpi")
    fun setMode(m: String) { mode.value = m; prefs.edit().putString("mode", m).apply() }

    val engineOk = Engine.available(app)
    val customCmd = MutableStateFlow(prefs.getString("custom", "") ?: "")
    val onlyApps = MutableStateFlow(prefs.getBoolean("onlyApps", true))
    val hostsOnly = MutableStateFlow(prefs.getBoolean("hostsOnly", false))
    val extraDomains = MutableStateFlow(prefs.getString("domains", "") ?: "")
    val dnsMode = MutableStateFlow(prefs.getString("dns", "isp") ?: "isp")

    private fun strategies(): List<Strategy> = Strategies.all + listOfNotNull(Strategies.custom(customCmd.value))

    val results = MutableStateFlow((listOf(Strategies.baseline) + strategies()).map { StrategyResult(it) })
    val testing = MutableStateFlow(false)
    val progress = MutableStateFlow(0)
    val strategy = MutableStateFlow(Strategies.byId(prefs.getInt("strategy", Strategies.RECOMMENDED), customCmd.value))
    val dpiStatus = MutableStateFlow(
        if (engineOk) "Выберите стратегию или запустите тест" else Engine.diag(app))

    fun selectStrategy(s: Strategy) { strategy.value = s; prefs.edit().putInt("strategy", s.id).apply() }
    fun setOnlyApps(v: Boolean) { onlyApps.value = v; prefs.edit().putBoolean("onlyApps", v).apply() }
    fun setHostsOnly(v: Boolean) { hostsOnly.value = v; prefs.edit().putBoolean("hostsOnly", v).apply() }
    fun setDomains(v: String) { extraDomains.value = v; prefs.edit().putString("domains", v).apply() }
    fun setDns(v: String) { dnsMode.value = v; prefs.edit().putString("dns", v).apply() }

    fun setCustom(v: String) {
        customCmd.value = v; prefs.edit().putString("custom", v).apply()
        if (testing.value) return
        val old = results.value
        results.value = (listOf(Strategies.baseline) + strategies()).map { s -> old.firstOrNull { it.strategy.id == s.id && s.id != Strategies.CUSTOM_ID } ?: StrategyResult(s) }
        if (strategy.value.id == Strategies.CUSTOM_ID) Strategies.custom(v)?.let { strategy.value = it }
    }

    fun checkIp() = viewModelScope.launch {
        dpiStatus.value = "Проверка адресов Google…"
        dpiStatus.value = Engine.ipReport()
    }

    fun testAll() = viewModelScope.launch {
        if (!engineOk) { dpiStatus.value = Engine.diag(getApplication()); return@launch }
        val list = strategies()
        testing.value = true; progress.value = 0
        results.value = (listOf(Strategies.baseline) + list).map { StrategyResult(it) }
        val ctx = getApplication<Application>()
        dpiStatus.value = "Проверка DNS…"
        val dns = Engine.dnsReport()
        dpiStatus.value = "Контрольный тест без обхода…"
        val base = Engine.test(ctx, Strategies.baseline, 21080)
        results.value = results.value.map { if (it.strategy.id == 0) base else it }
        for (chunk in list.chunked(4)) {
            dpiStatus.value = "Проверка… ${progress.value}/${list.size}"
            val res = chunk.mapIndexed { i, s -> async { Engine.test(ctx, s, 21081 + i) } }.awaitAll()
            results.value = results.value.map { old -> res.firstOrNull { it.strategy.id == old.strategy.id } ?: old }
            progress.value += chunk.size
        }
        val sorted = results.value.sortedWith(
            compareByDescending<StrategyResult> { it.score }
                .thenByDescending { it.speedKb }
                .thenBy { if (it.avgMs < 0) Long.MAX_VALUE else it.avgMs })
        results.value = sorted
        val total = Services.all.size
        val best = sorted.firstOrNull { it.strategy.id != 0 && it.score > 0 }
        val sb = StringBuilder()
        if (base.score == total) {
            selectStrategy(Strategies.byId(Strategies.RECOMMENDED))
            sb.append("Без обхода открывается $total/$total: тест не может отличить стратегии. Выбрана №${Strategies.RECOMMENDED}. Решает реальная проверка: включите обход и смотрите журнал.")
        } else if (best != null && best.score > base.score) {
            selectStrategy(best.strategy)
            sb.append("Лучшая: ${best.strategy.name} — ${best.score}/$total сервисов (без обхода: ${base.score})")
        } else sb.append("Ни одна стратегия не улучшила результат (без обхода: ${base.score}/$total)")
        if (dns != null) sb.append("\n").append(dns)
        dpiStatus.value = sb.toString()
        testing.value = false
    }

    val url = MutableStateFlow(prefs.getString("url", "") ?: "")
    val servers = MutableStateFlow<List<Server>>(emptyList())
    val status = MutableStateFlow("Вставьте ссылку подписки")
    val busy = MutableStateFlow(false)
    val selected = MutableStateFlow<Server?>(null)

    init { try { Libv2ray.initCoreEnv(app.filesDir.path, "") } catch (_: Throwable) {} }

    fun setUrl(v: String) { url.value = v; prefs.edit().putString("url", v).apply() }

    fun refresh() = viewModelScope.launch {
        busy.value = true; status.value = "Загрузка подписки…"
        try {
            val list = Net.fetchSubscription(url.value)
            val ranked = Net.rank(list) { status.value = it }
            servers.value = ranked
            val best = ranked.firstOrNull { it.realMs >= 0 } ?: ranked.firstOrNull { it.pingMs >= 0 }
            selected.value = best
            status.value = best?.let {
                if (it.realMs >= 0) "Лучший: ${it.label} (${it.realMs} мс)" else "Лучший: ${it.label} (TCP ${it.pingMs} мс)"
            } ?: "Нет доступных узлов"
        } catch (e: Exception) { status.value = "Ошибка: ${e.message}" }
        busy.value = false
    }

    fun canStart(): Boolean = if (mode.value == "dpi") engineOk else selected.value != null

    private fun writeHosts(): String {
        val f = File(getApplication<Application>().filesDir, "hosts.txt")
        val extra = extraDomains.value.split(Regex("[\\s,;]+")).filter { it.contains('.') }
        f.writeText((Hosts.builtin + extra).distinct().joinToString("\n"))
        return f.absolutePath
    }

    fun start() {
        State.error.value = null
        State.log.value = ""
        val ctx = getApplication<Application>()
        val i = Intent(ctx, WhitezVpnService::class.java)
        if (mode.value == "dpi") {
            if (!engineOk) { State.error.value = "Движок обхода не найден"; return }
            var args = strategy.value.args
            if (hostsOnly.value && args.isNotEmpty()) args = Strategies.withHosts(args, writeHosts())
            i.putExtra("mode", "dpi").putExtra("args", args.toTypedArray()).putExtra("dns", dnsMode.value)
            if (onlyApps.value) i.putExtra("apps", Apps.list)
        } else {
            val s = selected.value ?: return
            i.putExtra("mode", "vpn").putExtra("config", XrayConfig.build(s))
        }
        ctx.startForegroundService(i)
    }
    fun stop() {
        getApplication<Application>().startService(
            Intent(getApplication(), WhitezVpnService::class.java).setAction("STOP"))
    }
}
