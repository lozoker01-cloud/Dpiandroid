package app.whitez
import android.app.Application
import android.content.Context
import android.content.Intent
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.launch

object State { val running = MutableStateFlow(false) }

class MainViewModel(app: Application) : AndroidViewModel(app) {
    private val prefs = app.getSharedPreferences("w", Context.MODE_PRIVATE)
    val url = MutableStateFlow(prefs.getString("url", "") ?: "")
    val servers = MutableStateFlow<List<Server>>(emptyList())
    val status = MutableStateFlow("Вставьте ссылку подписки")
    val busy = MutableStateFlow(false)
    val selected = MutableStateFlow<Server?>(null)

    fun setUrl(v: String) { url.value = v; prefs.edit().putString("url", v).apply() }

    fun refresh() = viewModelScope.launch {
        busy.value = true; status.value = "Загрузка подписки…"
        try {
            val list = Net.fetchSubscription(url.value)
            status.value = "Проверка ${list.size} узлов…"
            val sorted = Net.pingAll(list)
            servers.value = sorted
            selected.value = sorted.firstOrNull { it.pingMs >= 0 }
            status.value = selected.value?.let { "Лучший: ${it.name} (${it.pingMs} мс)" } ?: "Нет доступных узлов"
        } catch (e: Exception) { status.value = "Ошибка: ${e.message}" }
        busy.value = false
    }

    fun start() {
        val s = selected.value ?: return
        val i = Intent(getApplication(), WhitezVpnService::class.java).putExtra("config", XrayConfig.build(s))
        getApplication<Application>().startForegroundService(i)
    }
    fun stop() {
        getApplication<Application>().startService(
            Intent(getApplication(), WhitezVpnService::class.java).setAction("STOP"))
    }
}
