package app.whitez
import android.app.*
import android.content.Intent
import android.net.VpnService
import android.os.ParcelFileDescriptor
import hev.htproxy.TProxyService
import libv2ray.CoreCallbackHandler
import libv2ray.CoreController
import libv2ray.Libv2ray
import java.io.File

/**
 * Режим "dpi": приложения -> TUN -> tun2socks -> ciadpi (SOCKS 127.0.0.1:1080) -> интернет напрямую (с обходом DPI).
 * Режим "vpn": приложения -> TUN -> tun2socks -> Xray (SOCKS 127.0.0.1:10808) -> ваш VPN-сервер.
 * Само приложение исключено из VPN, поэтому ciadpi и Xray выходят в сеть мимо туннеля.
 */
class WhitezVpnService : VpnService() {
    private var tun: ParcelFileDescriptor? = null
    private var core: CoreController? = null
    private var proc: Process? = null

    private val handler = object : CoreCallbackHandler {
        override fun startup(): Long = 0
        override fun shutdown(): Long = 0
        override fun onEmitStatus(code: Long, msg: String?): Long = 0
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action == "STOP") { stopVpn(); return START_NOT_STICKY }
        val mode = intent?.getStringExtra("mode") ?: "vpn"
        val config = intent?.getStringExtra("config")
        val args = intent?.getStringArrayExtra("args")
        if (mode == "vpn" && config == null) return START_NOT_STICKY
        if (mode == "dpi" && args == null) return START_NOT_STICKY
        startForeground(1, notification(mode))
        Thread { startVpn(mode, config, args) }.start()
        return START_NOT_STICKY
    }

    private fun startVpn(mode: String, config: String?, args: Array<String>?) {
        try {
            stopQuiet()
            val port: Int
            if (mode == "dpi") {
                port = 1080
                val p = Engine.spawn(this, port, args!!.toList())
                proc = p
                Thread.sleep(500)
                if (!p.isAlive) throw IllegalStateException("Движок обхода не запустился")
            } else {
                port = XrayConfig.SOCKS_PORT
                Libv2ray.initCoreEnv(filesDir.path, "")
                core = CoreController(handler).also { it.startLoop(config!!, 0) }
            }
            tun = Builder().setSession("WHITEZ").setMtu(1500)
                .addAddress("10.10.14.1", 30).addRoute("0.0.0.0", 0)
                .addAddress("fd00::1", 126).addRoute("::", 0)
                .addDnsServer("1.1.1.1").addDnsServer("8.8.8.8")
                .addDisallowedApplication(packageName)
                .establish() ?: throw IllegalStateException("VPN не разрешён")
            val yml = File(filesDir, "tun.yml")
            yml.writeText("""
                tunnel:
                  mtu: 1500
                  ipv4: 10.10.14.1
                  ipv6: 'fd00::1'
                socks5:
                  port: $port
                  address: 127.0.0.1
                  udp: 'udp'
                misc:
                  log-level: warn
            """.trimIndent())
            TProxyService.TProxyStartService(yml.absolutePath, tun!!.fd)
            State.activeMode.value = mode
            State.running.value = true
        } catch (e: Throwable) {
            State.error.value = e.message ?: e.javaClass.simpleName
            stopVpn()
        }
    }

    private fun stopQuiet() {
        try { TProxyService.TProxyStopService() } catch (_: Throwable) {}
        try { core?.stopLoop() } catch (_: Throwable) {}
        core = null
        try { proc?.destroy() } catch (_: Throwable) {}
        proc = null
        try { tun?.close() } catch (_: Throwable) {}
        tun = null
    }

    private fun stopVpn() {
        stopQuiet()
        State.running.value = false
        State.activeMode.value = ""
        stopForeground(STOP_FOREGROUND_REMOVE); stopSelf()
    }
    override fun onRevoke() { stopVpn() }
    override fun onDestroy() { stopQuiet(); State.running.value = false; super.onDestroy() }

    private fun notification(mode: String): Notification {
        val nm = getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(NotificationChannel("w", "WHITEZ", NotificationManager.IMPORTANCE_LOW))
        return Notification.Builder(this, "w").setContentTitle("WHITEZ")
            .setContentText(if (mode == "dpi") "Обход блокировок активен" else "VPN активен")
            .setSmallIcon(android.R.drawable.ic_lock_lock).build()
    }
}
