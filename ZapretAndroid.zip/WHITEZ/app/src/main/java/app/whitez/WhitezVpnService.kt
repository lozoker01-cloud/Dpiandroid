package app.whitez
import android.app.*
import android.content.Intent
import android.net.VpnService
import android.os.ParcelFileDescriptor

/**
 * VPN-сервис. Поднимает TUN-интерфейс и запускает ядро Xray (libv2ray.aar) с SOCKS-входом 127.0.0.1:10808.
 * ВАЖНО: пересылка пакетов TUN -> SOCKS требует tun2socks (например hev-socks5-tunnel, как в v2rayNG).
 * Точки подключения помечены TODO(CORE).
 */
class WhitezVpnService : VpnService() {
    private var tun: ParcelFileDescriptor? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action == "STOP") { stopVpn(); return START_NOT_STICKY }
        val config = intent?.getStringExtra("config") ?: return START_NOT_STICKY
        startForeground(1, notification())
        tun = Builder().setSession("WHITEZ").setMtu(1500)
            .addAddress("10.10.14.1", 30).addRoute("0.0.0.0", 0)
            .addAddress("fd00::1", 126).addRoute("::", 0)
            .addDnsServer("1.1.1.1").addDnsServer("8.8.8.8")
            .addDisallowedApplication(packageName)
            .establish()
        // TODO(CORE): Libv2ray.initCoreEnv(filesDir.path, "")
        // TODO(CORE): val point = Libv2ray.newV2RayPoint(callbacks, false); point.configureFileContent = config; point.runLoop(false)
        // TODO(CORE): запустить tun2socks: tun.fd -> socks5://127.0.0.1:10808
        State.running.value = true
        return START_STICKY
    }

    private fun stopVpn() {
        // TODO(CORE): point.stopLoop(); остановить tun2socks
        tun?.close(); tun = null
        State.running.value = false
        stopForeground(STOP_FOREGROUND_REMOVE); stopSelf()
    }
    override fun onDestroy() { stopVpn(); super.onDestroy() }

    private fun notification(): Notification {
        val nm = getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(NotificationChannel("w", "WHITEZ", NotificationManager.IMPORTANCE_LOW))
        return Notification.Builder(this, "w").setContentTitle("WHITEZ").setContentText("Защита активна")
            .setSmallIcon(android.R.drawable.ic_lock_lock).build()
    }
}
