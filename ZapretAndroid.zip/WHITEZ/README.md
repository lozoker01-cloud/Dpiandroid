# WHITEZ
1. Положите libv2ray.aar в app/libs/ (см. файл-подсказку).
2. Откройте проект в Android Studio -> Build -> Build APK(s).
3. В приложении вставьте ссылку подписки и нажмите "Обновить и выбрать лучший".
4. Допишите места TODO(CORE) в WhitezVpnService.kt (запуск ядра и tun2socks).
Ссылку подписки в код не вшивайте.
