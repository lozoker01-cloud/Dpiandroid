# WHITEZ 2.0
Два режима:
- Обход (основной): локальный DPI-обход (движок ciadpi/ByeDPI) + 21 стратегия, тест всех и автоподбор лучшей.
- VPN (запасной): ваша подписка VLESS через Xray.

Сборка: GitHub Actions -> Build WHITEZ APK. Шаг scripts/build_ciadpi.sh собирает нативный движок (нужен NDK, он есть на runner'е).
Лицензии: byedpi (hufrea) и hev-socks5-tunnel — проверьте условия перед распространением приложения.
