# WHITEZ 3.3
Режимы: Обход (ciadpi/ByeDPI, 21 стратегия, тест с загрузкой 64 КБ, фильтр приложений) и VPN (VLESS через Xray, запасной).
Сборка: scripts/build_ciadpi.sh, затем gradle assembleDebug. Workflow для репозитория с ZapretAndroid.zip: docs/workflow-for-zip-repo.yml.
