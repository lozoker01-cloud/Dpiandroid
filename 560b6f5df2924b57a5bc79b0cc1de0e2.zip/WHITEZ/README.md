# WHITEZ

## Как получить APK
### Вариант A: без Android Studio (GitHub Actions)
1. Создайте приватный репозиторий на GitHub, загрузите содержимое папки WHITEZ.
2. Вкладка Actions -> "Build WHITEZ APK" -> Run workflow.
3. Через ~5 минут скачайте артефакт WHITEZ-apk.

### Вариант B: Android Studio
Откройте папку, Build -> Build APK(s). Ядра (libv2ray.aar и hev-socks5-tunnel.aar)
скачаются в app/libs автоматически при сборке (нужен интернет).

## Схема
TUN -> hev-socks5-tunnel -> SOCKS 127.0.0.1:10808 -> Xray (VLESS) -> ваш сервер.
Стратегии: обычная и fragment ClientHello; для топ-5 узлов проверяются реальным запросом через ядро.
Ссылку подписки вводите в приложении (в код не вшита).
