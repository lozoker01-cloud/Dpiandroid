package app.whitez
import kotlinx.coroutines.*
import libv2ray.Libv2ray
import java.net.HttpURLConnection
import java.net.InetSocketAddress
import java.net.Socket
import java.net.URL

object Net {
    private const val TEST_URL = "https://www.gstatic.com/generate_204"

    suspend fun fetchSubscription(url: String): List<Server> = withContext(Dispatchers.IO) {
        val c = URL(url).openConnection() as HttpURLConnection
        c.connectTimeout = 8000; c.readTimeout = 8000
        c.setRequestProperty("User-Agent", "v2rayTun/WHITEZ")
        val body = c.inputStream.bufferedReader().readText()
        SubscriptionParser.decode(body).mapNotNull { SubscriptionParser.parse(it) }
    }

    private suspend fun tcpPing(s: Server): Long = withContext(Dispatchers.IO) {
        val r = (1..3).map {
            try {
                val t = System.nanoTime()
                Socket().use { it.connect(InetSocketAddress(s.host, s.port), 2500) }
                (System.nanoTime() - t) / 1_000_000
            } catch (e: Exception) { -1L }
        }.filter { it >= 0 }
        if (r.isEmpty()) -1 else r.average().toLong()
    }

    /** Этап 1: TCP-пинг всех узлов. Этап 2: реальная проверка через ядро Xray
     *  (узел x стратегия: обычная / fragment ClientHello). Возвращает отсортированный список. */
    suspend fun rank(list: List<Server>, onStage: (String) -> Unit): List<Server> = coroutineScope {
        onStage("TCP-пинг ${list.size} узлов…")
        list.map { s -> async { s.pingMs = tcpPing(s) } }.awaitAll()
        val alive = list.filter { it.pingMs >= 0 }.sortedBy { it.pingMs }
        if (alive.isEmpty()) return@coroutineScope emptyList()
        onStage("Тест стратегий через ядро…")
        val variants = alive.take(5).flatMap { listOf(it.copy(fragment = false), it.copy(fragment = true)) }
        variants.map { v -> async(Dispatchers.IO) {
            v.realMs = try { Libv2ray.measureOutboundDelay(XrayConfig.build(v), TEST_URL) } catch (e: Throwable) { -1L }
        } }.awaitAll()
        val ok = variants.filter { it.realMs >= 0 }.sortedBy { it.realMs }
        val rest = variants.filter { it.realMs < 0 }
        ok + rest
    }
}
