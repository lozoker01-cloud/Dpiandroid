package app.whitez
import android.app.Activity
import android.net.VpnService
import android.os.Bundle
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.activity.viewModels
import androidx.compose.animation.Crossfade
import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.animateContentSize
import androidx.compose.animation.core.*
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.selection.SelectionContainer
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.StrokeJoin
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import kotlinx.coroutines.delay
import kotlin.math.cos
import kotlin.math.sin

object W {
    val Bg = Color(0xFF0B0C0F)
    val Bg2 = Color(0xFF101217)
    val Card = Color(0xFF15171D)
    val Card2 = Color(0xFF1C1F27)
    val Line = Color(0x16FFFFFF)
    val Fg = Color(0xFFECEEF2)
    val Sub = Color(0xFF8A90A0)
    val Accent = Color(0xFFB4C2FF)
    val Ok = Color(0xFF9ADBB8)
    val Warn = Color(0xFFE8C48A)
}

class MainActivity : ComponentActivity() {
    private val vm: MainViewModel by viewModels()
    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        window.statusBarColor = 0xFF0B0C0F.toInt()
        window.navigationBarColor = 0xFF101217.toInt()
        if (android.os.Build.VERSION.SDK_INT >= 33)
            requestPermissions(arrayOf(android.Manifest.permission.POST_NOTIFICATIONS), 1)
        setContent {
            MaterialTheme(colorScheme = darkColorScheme(primary = W.Accent, background = W.Bg, surface = W.Card)) { Screen(vm) }
        }
    }
}

// ---------- Базовые элементы

@Composable
fun Label(text: String) {
    Text(text.uppercase(), color = W.Sub, fontSize = 11.sp, letterSpacing = 1.4.sp, fontWeight = FontWeight.Medium)
}

@Composable
fun Panel(modifier: Modifier = Modifier, border: Color = W.Line, bg: Color = W.Card,
          content: @Composable ColumnScope.() -> Unit) {
    val shape = RoundedCornerShape(22.dp)
    Column(modifier.fillMaxWidth().clip(shape).background(bg).border(1.dp, border, shape).padding(16.dp),
        content = content)
}

@Composable
fun SoftButton(text: String, enabled: Boolean = true, onClick: () -> Unit) {
    val shape = RoundedCornerShape(16.dp)
    val c = if (enabled) W.Accent else W.Sub
    Box(Modifier.fillMaxWidth().clip(shape).background(c.copy(alpha = 0.10f))
        .border(1.dp, c.copy(alpha = 0.35f), shape)
        .clickable(enabled = enabled, onClick = onClick).padding(vertical = 15.dp),
        contentAlignment = Alignment.Center) {
        Text(text, color = c, fontSize = 14.sp, fontWeight = FontWeight.Medium, letterSpacing = 0.5.sp)
    }
}

@Composable
fun Pill(text: String, onClick: () -> Unit) {
    val shape = RoundedCornerShape(12.dp)
    Box(Modifier.clip(shape).background(W.Card).border(1.dp, W.Line, shape)
        .clickable(onClick = onClick).padding(horizontal = 12.dp, vertical = 7.dp)) {
        Text(text, color = W.Fg, fontSize = 12.sp, fontWeight = FontWeight.Medium)
    }
}

@Composable
fun InfoPill(text: String, onClick: () -> Unit) {
    val shape = RoundedCornerShape(50)
    Box(Modifier.clip(shape).background(W.Card).border(1.dp, W.Line, shape)
        .clickable(onClick = onClick).padding(horizontal = 14.dp, vertical = 8.dp)) {
        Text(text, color = W.Sub, fontSize = 12.sp, maxLines = 1)
    }
}

@Composable
fun Chip(text: String, selected: Boolean, enabled: Boolean = true, onClick: () -> Unit) {
    val shape = RoundedCornerShape(12.dp)
    val c = if (selected) W.Accent else W.Sub
    Box(Modifier.clip(shape).background(if (selected) W.Accent.copy(alpha = 0.12f) else Color.Transparent)
        .border(1.dp, if (selected) W.Accent.copy(alpha = 0.5f) else W.Line, shape)
        .clickable(enabled = enabled, onClick = onClick).padding(horizontal = 14.dp, vertical = 8.dp)) {
        Text(text, color = c, fontSize = 12.sp, fontWeight = FontWeight.Medium)
    }
}

@Composable
fun Toggle(title: String, hint: String, checked: Boolean, enabled: Boolean, onChange: (Boolean) -> Unit) {
    Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
        Column(Modifier.weight(1f)) {
            Text(title, color = W.Fg, fontSize = 14.sp, fontWeight = FontWeight.Medium)
            Spacer(Modifier.height(2.dp))
            Text(hint, color = W.Sub, fontSize = 11.sp)
        }
        Spacer(Modifier.width(12.dp))
        Switch(checked = checked, onCheckedChange = onChange, enabled = enabled,
            colors = SwitchDefaults.colors(checkedThumbColor = W.Bg, checkedTrackColor = W.Ok,
                uncheckedThumbColor = W.Sub, uncheckedTrackColor = W.Card2, uncheckedBorderColor = W.Line))
    }
}

@Composable
fun Field(value: String, onChange: (String) -> Unit, placeholder: String, enabled: Boolean = true,
          singleLine: Boolean = false, minLines: Int = 1, maxLines: Int = 5) {
    OutlinedTextField(value, onChange, enabled = enabled, placeholder = { Text(placeholder, color = W.Sub) },
        singleLine = singleLine, minLines = if (singleLine) 1 else minLines, maxLines = if (singleLine) 1 else maxLines,
        shape = RoundedCornerShape(14.dp), modifier = Modifier.fillMaxWidth(),
        colors = OutlinedTextFieldDefaults.colors(
            focusedBorderColor = W.Accent.copy(alpha = 0.6f), unfocusedBorderColor = W.Line))
}

@Composable
fun NavIcon(kind: Int, color: Color) {
    Canvas(Modifier.size(24.dp)) {
        val u = size.width / 24f
        val w = 1.9f * u
        val sw = Stroke(width = w, cap = StrokeCap.Round, join = StrokeJoin.Round)
        when (kind) {
            0 -> {
                drawArc(color = color, startAngle = -55f, sweepAngle = 290f, useCenter = false,
                    topLeft = Offset(5f * u, 6f * u), size = Size(14f * u, 14f * u), style = sw)
                drawLine(color = color, start = Offset(12f * u, 3f * u), end = Offset(12f * u, 12f * u), strokeWidth = w, cap = StrokeCap.Round)
            }
            1 -> {
                drawLine(color = color, start = Offset(4f * u, 7f * u), end = Offset(20f * u, 7f * u), strokeWidth = w, cap = StrokeCap.Round)
                drawLine(color = color, start = Offset(4f * u, 12f * u), end = Offset(15f * u, 12f * u), strokeWidth = w, cap = StrokeCap.Round)
                drawLine(color = color, start = Offset(4f * u, 17f * u), end = Offset(10f * u, 17f * u), strokeWidth = w, cap = StrokeCap.Round)
            }
            2 -> {
                val p = Path().apply {
                    moveTo(12f * u, 3f * u); lineTo(19f * u, 6f * u); lineTo(19f * u, 12f * u)
                    lineTo(12f * u, 21f * u); lineTo(5f * u, 12f * u); lineTo(5f * u, 6f * u); close()
                }
                drawPath(path = p, color = color, style = sw)
            }
            else -> {
                drawLine(color = color, start = Offset(4f * u, 8f * u), end = Offset(20f * u, 8f * u), strokeWidth = w, cap = StrokeCap.Round)
                drawLine(color = color, start = Offset(4f * u, 16f * u), end = Offset(20f * u, 16f * u), strokeWidth = w, cap = StrokeCap.Round)
                drawCircle(color = color, radius = 2.6f * u, center = Offset(9f * u, 8f * u), style = sw)
                drawCircle(color = color, radius = 2.6f * u, center = Offset(15f * u, 16f * u), style = sw)
            }
        }
    }
}

@Composable
fun Header(on: Boolean, onLog: () -> Unit, onCopy: () -> Unit) {
    Row(Modifier.fillMaxWidth().statusBarsPadding().padding(horizontal = 20.dp, vertical = 12.dp),
        horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Box(Modifier.size(8.dp).clip(CircleShape).background(if (on) W.Ok else W.Sub.copy(alpha = 0.5f)))
            Spacer(Modifier.width(10.dp))
            Text("WHITEZ", color = W.Fg, fontSize = 18.sp, fontWeight = FontWeight.Medium, letterSpacing = 6.sp)
        }
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            Pill("Журнал", onLog)
            Pill("Копировать", onCopy)
        }
    }
}

@Composable
fun BottomBar(tab: String, onTab: (String) -> Unit) {
    val items = listOf(Triple("home", "Обход", 0), Triple("strategies", "Стратегии", 1),
        Triple("vpn", "VPN", 2), Triple("settings", "Настройки", 3))
    Row(Modifier.fillMaxWidth().background(W.Bg2)
        .drawBehind { drawLine(color = W.Line, start = Offset(0f, 0f), end = Offset(size.width, 0f), strokeWidth = 1.dp.toPx()) }
        .navigationBarsPadding().padding(top = 6.dp, bottom = 4.dp)) {
        items.forEach { (id, label, kind) ->
            val sel = tab == id
            val c by animateColorAsState(if (sel) W.Accent else W.Sub, label = "nav")
            Column(Modifier.weight(1f).clickable(interactionSource = remember { MutableInteractionSource() }, indication = null) { onTab(id) }
                .padding(vertical = 6.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                Box(Modifier.width(18.dp).height(3.dp).clip(CircleShape).background(if (sel) W.Accent else Color.Transparent))
                Spacer(Modifier.height(6.dp))
                NavIcon(kind, c)
                Spacer(Modifier.height(2.dp))
                Text(label, color = c, fontSize = 10.5.sp, fontWeight = FontWeight.Medium)
            }
        }
    }
}

@Composable
fun PowerHero(on: Boolean, enabled: Boolean, title: String, subtitle: String, startedAt: Long, onClick: () -> Unit) {
    val accent by animateColorAsState(if (on) W.Ok else W.Accent, animationSpec = tween(700), label = "acc")
    val fill by animateFloatAsState(if (on) 1f else 0.12f, animationSpec = tween(1100), label = "fill")
    val pulse by rememberInfiniteTransition(label = "p").animateFloat(
        0.5f, 1f, infiniteRepeatable(tween(2800, easing = FastOutSlowInEasing), RepeatMode.Reverse), label = "pulse")
    val elapsed by produceState("", on, startedAt) {
        if (!on || startedAt == 0L) { value = ""; return@produceState }
        while (true) {
            val s = (System.currentTimeMillis() - startedAt) / 1000
            value = String.format("%02d:%02d:%02d", s / 3600, (s / 60) % 60, s % 60)
            delay(1000)
        }
    }
    Column(horizontalAlignment = Alignment.CenterHorizontally) {
        Box(Modifier.size(244.dp).clip(CircleShape).clickable(
            interactionSource = remember { MutableInteractionSource() }, indication = null,
            enabled = enabled, onClick = onClick), contentAlignment = Alignment.Center) {
            Canvas(Modifier.fillMaxSize()) {
                val c = center
                val r = size.minDimension / 2
                drawCircle(brush = Brush.radialGradient(
                    listOf(accent.copy(alpha = (if (on) 0.28f else 0.12f) * pulse), Color.Transparent), center = c, radius = r),
                    radius = r, center = c)
                val n = 72
                val r1 = r - 22.dp.toPx()
                val r2 = r - 32.dp.toPx()
                for (i in 0 until n) {
                    val a = Math.toRadians(i * 360.0 / n - 90.0)
                    val cs = cos(a).toFloat(); val sn = sin(a).toFloat()
                    val lit = i.toFloat() / n <= fill
                    drawLine(color = if (lit) accent.copy(alpha = 0.85f) else Color.White.copy(alpha = 0.09f),
                        start = Offset(c.x + cs * r2, c.y + sn * r2), end = Offset(c.x + cs * r1, c.y + sn * r1),
                        strokeWidth = 2.dp.toPx(), cap = StrokeCap.Round)
                }
                val disc = r - 52.dp.toPx()
                drawCircle(brush = Brush.verticalGradient(listOf(W.Card2, W.Card)), radius = disc, center = c)
                drawCircle(color = Color.White.copy(alpha = 0.07f), radius = disc, center = c, style = Stroke(1.dp.toPx()))
                val g = 16.dp.toPx(); val sw = 3.dp.toPx()
                drawArc(color = accent, startAngle = -55f, sweepAngle = 290f, useCenter = false,
                    topLeft = Offset(c.x - g, c.y - g + 3.dp.toPx()), size = Size(2 * g, 2 * g),
                    style = Stroke(sw, cap = StrokeCap.Round))
                drawLine(color = accent, start = Offset(c.x, c.y - g - 5.dp.toPx()), end = Offset(c.x, c.y - 1.dp.toPx()),
                    strokeWidth = sw, cap = StrokeCap.Round)
            }
        }
        Spacer(Modifier.height(10.dp))
        Text(title, color = W.Fg, fontSize = 20.sp, fontWeight = FontWeight.Medium, textAlign = TextAlign.Center)
        Spacer(Modifier.height(4.dp))
        Text(subtitle, color = W.Sub, fontSize = 13.sp, textAlign = TextAlign.Center)
        if (on && elapsed.isNotEmpty()) {
            Spacer(Modifier.height(10.dp))
            Row(verticalAlignment = Alignment.CenterVertically) {
                Box(Modifier.size(6.dp).clip(CircleShape).background(W.Ok))
                Spacer(Modifier.width(8.dp))
                Text("Активно · $elapsed", color = W.Ok, fontSize = 12.sp, fontWeight = FontWeight.Medium)
            }
        }
    }
}

@Composable
fun JournalDialog(text: String, onCopy: () -> Unit, onClear: () -> Unit, onClose: () -> Unit) {
    Dialog(onDismissRequest = onClose, properties = DialogProperties(usePlatformDefaultWidth = false)) {
        Column(Modifier.fillMaxSize().background(W.Bg).statusBarsPadding().navigationBarsPadding().padding(16.dp)) {
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                Text("Журнал", color = W.Fg, fontSize = 20.sp, fontWeight = FontWeight.Medium)
                Pill("Закрыть", onClose)
            }
            Spacer(Modifier.height(12.dp))
            val shape = RoundedCornerShape(18.dp)
            Box(Modifier.weight(1f).fillMaxWidth().clip(shape).background(W.Card).border(1.dp, W.Line, shape)
                .padding(14.dp).verticalScroll(rememberScrollState())) {
                SelectionContainer {
                    Text(text, color = W.Sub, fontSize = 11.sp, fontFamily = FontFamily.Monospace, lineHeight = 16.sp)
                }
            }
            Spacer(Modifier.height(12.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                Box(Modifier.weight(1f)) { SoftButton("Копировать всё", onClick = onCopy) }
                Box(Modifier.weight(1f)) { SoftButton("Очистить", onClick = onClear) }
            }
        }
    }
}

// ---------- Экран

@Composable
fun Screen(vm: MainViewModel) {
    val mode by vm.mode.collectAsState()
    val running by State.running.collectAsState()
    val active by State.activeMode.collectAsState()
    val ctx = LocalContext.current
    val clipboard = LocalClipboardManager.current
    var tab by rememberSaveable { mutableStateOf(if (mode == "vpn") "vpn" else "home") }
    var showLog by rememberSaveable { mutableStateOf(false) }

    val perm = rememberLauncherForActivityResult(ActivityResultContracts.StartActivityForResult()) {
        if (it.resultCode == Activity.RESULT_OK) vm.start()
    }
    val toggle: () -> Unit = {
        if (running && active == mode) vm.stop() else {
            val i = VpnService.prepare(ctx)
            if (i != null) perm.launch(i) else vm.start()
        }
    }
    val copyAll: () -> Unit = {
        clipboard.setText(AnnotatedString(vm.fullLog()))
        Toast.makeText(ctx, "Журнал скопирован", Toast.LENGTH_SHORT).show()
    }

    Column(Modifier.fillMaxSize().background(Brush.verticalGradient(listOf(W.Bg, W.Bg2)))) {
        Header(on = running && active == mode, onLog = { showLog = true }, onCopy = copyAll)
        Box(Modifier.weight(1f)) {
            Crossfade(targetState = tab, label = "tab") { t ->
                when (t) {
                    "home" -> HomeTab(vm, toggle, { tab = "strategies" }, { tab = "settings" })
                    "strategies" -> StrategiesTab(vm)
                    "vpn" -> VpnTab(vm, toggle)
                    else -> SettingsTab(vm)
                }
            }
        }
        BottomBar(tab) { t ->
            tab = t
            vm.setMode(if (t == "vpn") "vpn" else "dpi")
        }
    }

    if (showLog) {
        val logText by State.log.collectAsState()
        val reportText by State.report.collectAsState()
        val shown = remember(logText, reportText) { vm.fullLog() }
        JournalDialog(shown, onCopy = copyAll, onClear = { vm.clearLog() }, onClose = { showLog = false })
    }
}

@Composable
fun HomeTab(vm: MainViewModel, toggle: () -> Unit, goStrategies: () -> Unit, goSettings: () -> Unit) {
    val mode by vm.mode.collectAsState()
    val running by State.running.collectAsState()
    val active by State.activeMode.collectAsState()
    val startedAt by State.startedAt.collectAsState()
    val err by State.error.collectAsState()
    val results by vm.results.collectAsState()
    val testing by vm.testing.collectAsState()
    val progress by vm.progress.collectAsState()
    val strategy by vm.strategy.collectAsState()
    val onlyApps by vm.onlyApps.collectAsState()
    val dnsMode by vm.dnsMode.collectAsState()
    val dpiStatus by vm.dpiStatus.collectAsState()
    val report by State.report.collectAsState()
    val on = running && active == "dpi" && mode == "dpi"
    val total = results.size - 1
    val cur = results.firstOrNull { it.strategy.id == strategy.id }
    val line = dpiStatus.lines().firstOrNull { it.isNotBlank() } ?: ""

    LazyColumn(Modifier.fillMaxSize(), contentPadding = PaddingValues(20.dp, 8.dp, 20.dp, 24.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)) {
        item {
            Box(Modifier.fillMaxWidth(), contentAlignment = Alignment.Center) {
                PowerHero(on = on, enabled = vm.engineOk && !testing, title = strategy.name,
                    subtitle = when {
                        err != null -> "Ошибка: $err"
                        !vm.engineOk -> "Движок не найден в APK"
                        on -> "Обход блокировок работает"
                        else -> "Нажмите, чтобы включить"
                    }, startedAt = startedAt, onClick = toggle)
            }
        }
        item {
            Row(Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                InfoPill("Стратегия №${strategy.id}", goStrategies)
                InfoPill("DNS · ${if (dnsMode == "isp") "провайдер" else "Google"}", goSettings)
                InfoPill("Приложения · ${if (onlyApps) "выбранные" else "все"}", goSettings)
            }
        }
        item {
            Panel {
                Label("Сервисы")
                Spacer(Modifier.height(14.dp))
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                    Services.all.forEach { svc ->
                        val tested = cur?.tested == true
                        val ok = cur?.passed?.contains(svc.id) == true
                        val c = when { !tested -> W.Sub.copy(alpha = 0.5f); ok -> W.Ok; else -> W.Warn }
                        Column(horizontalAlignment = Alignment.CenterHorizontally) {
                            Box(Modifier.size(10.dp).clip(CircleShape).background(c))
                            Spacer(Modifier.height(8.dp))
                            Text(svc.name.substringBefore(" "), color = W.Fg, fontSize = 11.sp)
                            Text(when { !tested -> "—"; ok -> "открыт"; else -> "закрыт" }, color = c, fontSize = 10.sp)
                        }
                    }
                }
            }
        }
        item {
            Panel {
                Label("Подбор стратегии")
                Spacer(Modifier.height(10.dp))
                Text(line, color = W.Fg, fontSize = 13.sp)
                if (testing) {
                    Spacer(Modifier.height(12.dp))
                    LinearProgressIndicator(progress = { progress / total.coerceAtLeast(1).toFloat() },
                        modifier = Modifier.fillMaxWidth().height(3.dp).clip(CircleShape), color = W.Accent, trackColor = W.Line)
                }
                Spacer(Modifier.height(14.dp))
                SoftButton(if (testing) "Проверка…  $progress/$total" else "Запустить тест ($total)",
                    enabled = !testing && vm.engineOk && !running) { vm.testAll() }
                Spacer(Modifier.height(8.dp))
                Text(when {
                    running -> "Остановите обход, чтобы запустить тест"
                    report.isNotEmpty() -> "Подробный отчёт — в журнале"
                    else -> "Тест проверяет YouTube, Discord, Telegram, Instagram и X"
                }, color = W.Sub, fontSize = 11.sp)
            }
        }
    }
}

@Composable
fun StrategyCard(r: StrategyResult, chosen: Boolean, enabled: Boolean, onSelect: () -> Unit) {
    var open by remember(r.strategy.id) { mutableStateOf(false) }
    Panel(Modifier.clickable(enabled = enabled, onClick = onSelect).animateContentSize(),
        border = if (chosen) W.Accent.copy(alpha = 0.55f) else W.Line, bg = if (chosen) W.Card2 else W.Card) {
        Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
            val bc = if (chosen) W.Accent else W.Sub
            Box(Modifier.size(30.dp).clip(CircleShape).border(1.dp, bc.copy(alpha = 0.6f), CircleShape), contentAlignment = Alignment.Center) {
                Text(if (r.strategy.id == Strategies.CUSTOM_ID) "★" else r.strategy.id.toString(), color = bc, fontSize = 12.sp, fontWeight = FontWeight.Medium)
            }
            Spacer(Modifier.width(12.dp))
            Column(Modifier.weight(1f)) {
                Text(r.strategy.name, color = W.Fg, fontSize = 15.sp, fontWeight = FontWeight.Medium)
                Spacer(Modifier.height(5.dp))
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    Services.all.forEach { svc ->
                        val c = when { !r.tested -> W.Sub.copy(alpha = 0.4f); r.passed.contains(svc.id) -> W.Ok; else -> W.Sub.copy(alpha = 0.3f) }
                        Text(svc.short, color = c, fontSize = 11.sp, fontWeight = FontWeight.Medium)
                    }
                }
            }
            Text(
                when {
                    !r.tested -> "—"
                    r.error != null -> r.error
                    r.score == 0 -> "не работает"
                    r.speedKb > 0 -> "${r.avgMs} мс\n${r.speedKb} КБ/с"
                    else -> "${r.avgMs} мс"
                },
                color = when { !r.tested -> W.Sub; r.score == 0 || r.error != null -> W.Warn; else -> W.Ok },
                fontSize = 12.sp, textAlign = TextAlign.End)
        }
        Spacer(Modifier.height(8.dp))
        Text(if (open) "скрыть команду" else "показать команду", color = W.Sub.copy(alpha = 0.8f), fontSize = 11.sp,
            modifier = Modifier.clickable { open = !open })
        if (open) {
            Spacer(Modifier.height(6.dp))
            Text(r.strategy.cmd, color = W.Sub, fontSize = 11.sp, fontFamily = FontFamily.Monospace)
        }
    }
}

@Composable
fun StrategiesTab(vm: MainViewModel) {
    val running by State.running.collectAsState()
    val results by vm.results.collectAsState()
    val testing by vm.testing.collectAsState()
    val progress by vm.progress.collectAsState()
    val strategy by vm.strategy.collectAsState()
    val dpiStatus by vm.dpiStatus.collectAsState()
    val total = results.size - 1
    val line = dpiStatus.lines().firstOrNull { it.isNotBlank() } ?: ""

    LazyColumn(Modifier.fillMaxSize(), contentPadding = PaddingValues(20.dp, 8.dp, 20.dp, 24.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)) {
        item {
            Panel {
                Label("Стратегии обхода")
                Spacer(Modifier.height(8.dp))
                Text(line, color = W.Fg, fontSize = 13.sp)
                if (testing) {
                    Spacer(Modifier.height(12.dp))
                    LinearProgressIndicator(progress = { progress / total.coerceAtLeast(1).toFloat() },
                        modifier = Modifier.fillMaxWidth().height(3.dp).clip(CircleShape), color = W.Accent, trackColor = W.Line)
                }
                Spacer(Modifier.height(14.dp))
                SoftButton(if (testing) "Проверка…  $progress/$total" else "Тест всех стратегий ($total)",
                    enabled = !testing && vm.engineOk && !running) { vm.testAll() }
            }
        }
        items(results, key = { it.strategy.id }) { r ->
            StrategyCard(r, r.strategy.id == strategy.id, !running) { vm.selectStrategy(r.strategy) }
        }
    }
}

@Composable
fun VpnTab(vm: MainViewModel, toggle: () -> Unit) {
    val mode by vm.mode.collectAsState()
    val running by State.running.collectAsState()
    val active by State.activeMode.collectAsState()
    val startedAt by State.startedAt.collectAsState()
    val err by State.error.collectAsState()
    val url by vm.url.collectAsState()
    val servers by vm.servers.collectAsState()
    val status by vm.status.collectAsState()
    val busy by vm.busy.collectAsState()
    val sel by vm.selected.collectAsState()
    val on = running && active == "vpn" && mode == "vpn"

    LazyColumn(Modifier.fillMaxSize(), contentPadding = PaddingValues(20.dp, 8.dp, 20.dp, 24.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)) {
        item {
            Box(Modifier.fillMaxWidth(), contentAlignment = Alignment.Center) {
                PowerHero(on = on, enabled = sel != null, title = sel?.label ?: "Сервер не выбран",
                    subtitle = if (err != null && mode == "vpn") "Ошибка: $err" else status,
                    startedAt = startedAt, onClick = toggle)
            }
        }
        item {
            Panel {
                Label("Подписка")
                Spacer(Modifier.height(10.dp))
                Field(url, vm::setUrl, "Ссылка подписки", singleLine = true)
            }
        }
        item { SoftButton(if (busy) "Подождите…" else "Обновить и выбрать лучший", enabled = !busy && url.isNotBlank()) { vm.refresh() } }
        items(servers) { s ->
            val ms = if (s.realMs >= 0) s.realMs else s.pingMs
            val chosen = s == sel
            Panel(Modifier.clickable { vm.selected.value = s },
                border = if (chosen) W.Accent.copy(alpha = 0.55f) else W.Line, bg = if (chosen) W.Card2 else W.Card) {
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                    Text(s.label, color = W.Fg, fontSize = 14.sp, modifier = Modifier.weight(1f))
                    Text(if (ms < 0) "—" else "$ms мс", color = if (ms in 0..300) W.Ok else W.Warn, fontSize = 12.sp)
                }
            }
        }
    }
}

@Composable
fun SettingsTab(vm: MainViewModel) {
    val running by State.running.collectAsState()
    val testing by vm.testing.collectAsState()
    val onlyApps by vm.onlyApps.collectAsState()
    val hostsOnly by vm.hostsOnly.collectAsState()
    val domains by vm.extraDomains.collectAsState()
    val custom by vm.customCmd.collectAsState()
    val dnsMode by vm.dnsMode.collectAsState()
    val dpiStatus by vm.dpiStatus.collectAsState()

    LazyColumn(Modifier.fillMaxSize(), contentPadding = PaddingValues(20.dp, 8.dp, 20.dp, 24.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)) {
        item {
            Panel {
                Label("Трафик")
                Spacer(Modifier.height(14.dp))
                Toggle("Только нужные приложения",
                    "YouTube, Discord, Telegram, Instagram, X и браузеры. Остальной трафик идёт напрямую.",
                    onlyApps, !running) { vm.setOnlyApps(it) }
                Spacer(Modifier.height(16.dp))
                Toggle("Только для списков доменов",
                    "Как листы в zaprett: обход применяется к доменам YouTube, Discord, Telegram, Meta, X и вашим. Экспериментально.",
                    hostsOnly, !running) { vm.setHostsOnly(it) }
                if (hostsOnly) {
                    Spacer(Modifier.height(10.dp))
                    Field(domains, vm::setDomains, "Свои домены через пробел", enabled = !running)
                }
            }
        }
        item {
            Panel {
                Label("DNS")
                Spacer(Modifier.height(12.dp))
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    Chip("Провайдера", dnsMode == "isp", !running) { vm.setDns("isp") }
                    Chip("Google 8.8.8.8", dnsMode == "google", !running) { vm.setDns("google") }
                }
                Spacer(Modifier.height(8.dp))
                Text("DNS провайдера отдаёт ближние серверы YouTube. Google — запасной вариант, если DNS провайдера подменяется.",
                    color = W.Sub, fontSize = 11.sp)
            }
        }
        item {
            Panel {
                Label("Своя стратегия")
                Spacer(Modifier.height(10.dp))
                Field(custom, vm::setCustom, "Параметры ciadpi, например: -d1 -s1+s -r1+s",
                    enabled = !running && !testing, minLines = 2)
                Spacer(Modifier.height(8.dp))
                Text("Строка из ByeByeDPI или репозитория стратегий. Появится в списке стратегий под значком ★ и участвует в тесте.",
                    color = W.Sub, fontSize = 11.sp)
            }
        }
        item {
            Panel {
                Label("Диагностика")
                Spacer(Modifier.height(12.dp))
                SoftButton("Проверить адреса YouTube", enabled = !testing && !running) { vm.checkIp() }
                Spacer(Modifier.height(8.dp))
                Text(dpiStatus.lines().firstOrNull { it.isNotBlank() } ?: "", color = W.Fg, fontSize = 12.sp)
                Spacer(Modifier.height(4.dp))
                Text("Подробности — в журнале (кнопка вверху).", color = W.Sub, fontSize = 11.sp)
            }
        }
    }
}
