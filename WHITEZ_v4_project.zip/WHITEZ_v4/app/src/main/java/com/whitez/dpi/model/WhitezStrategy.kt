package com.whitez.dpi.model

enum class DesyncMode {
    TLS_RECORD_1_BYTE,
    TLS_RECORD_MID_SNI,
    TLS_RECORD_EXT_OFFSET,
    SNI_MID_SPLIT,
    SNI_FIRST_DOT,
    SNI_LAST_DOT,
    OFFSET_1_BYTE,
    OFFSET_2_BYTE,
    OFFSET_3_BYTE,
    OFFSET_5_BYTE,
    MULTI_1_SNI_END,
    MULTI_2_5_MID_SNI,
    MULTI_1_6_MID_END,
    DISORDER_MID_SNI,
    DISORDER_2_BYTE,
    DISORDER_5_BYTE,
    FAKE_SNI_GOOGLE,
    FAKE_SNI_YA,
    FAKE_SNI_VK,
    FAKE_SNI_CLOUDFLARE,
    QUIC_DROP_ONLY
}

data class WhitezStrategy(
    val id: String,
    val name: String,
    val badge: String,
    val zapretPcEquivalent: String,
    val description: String,
    val mode: DesyncMode,
    val args: List<String>,
    val blockQuic: Boolean = true,
    val recommendedFor: String
)

object StrategyRepository {

    val strategies: List<WhitezStrategy> = listOf(
        WhitezStrategy(
            id = "s01_general_tls_split",
            name = "01. General (TLS Record + SNI)",
            badge = "Базовая",
            zapretPcEquivalent = "general.bat (multisplit 1, sniext+1)",
            description = "Разделяет TLS ClientHello на фрагменты с разрывом домена SNI.",
            mode = DesyncMode.TLS_RECORD_1_BYTE,
            args = listOf("-r", "1+s", "-s", "1", "-q", "1"),
            recommendedFor = "Универсальный старт для домашних провайдеров"
        ),
        WhitezStrategy(
            id = "s02_alt1_mid_sni",
            name = "02. General ALT 1 (Mid-SNI Split)",
            badge = "YouTube / CDN",
            zapretPcEquivalent = "general (ALT1).bat (midsld split)",
            description = "Разрывает TCP-поток строго посередине имени хоста (например, yout|ube.com).",
            mode = DesyncMode.SNI_MID_SPLIT,
            args = listOf("-s", "0+s", "-q", "1"),
            recommendedFor = "Ростелеком, МГТС, Дом.ру и видео-серверы"
        ),
        WhitezStrategy(
            id = "s03_alt2_tls_mid_sni",
            name = "03. General ALT 2 (TLS Record Mid-SNI)",
            badge = "TLS Split",
            zapretPcEquivalent = "general (ALT2).bat (tls-record + midsld)",
            description = "Формирует два TLS-рекорда со смещением ровно по центру SNI.",
            mode = DesyncMode.TLS_RECORD_MID_SNI,
            args = listOf("-r", "0+s", "-s", "0+s", "-q", "1"),
            recommendedFor = "Провайдеры с глубоким анализом TLS-записей"
        ),
        WhitezStrategy(
            id = "s04_alt3_ext_offset",
            name = "04. General ALT 3 (SNI Ext +1)",
            badge = "ТСПУ",
            zapretPcEquivalent = "general (ALT3).bat (sniext+1)",
            description = "Сдвигает точку фрагментации на начало расширения SNI.",
            mode = DesyncMode.TLS_RECORD_EXT_OFFSET,
            args = listOf("-r", "1+s", "-s", "1+s", "-q", "1"),
            recommendedFor = "Сети со строгой проверкой заголовка ClientHello"
        ),
        WhitezStrategy(
            id = "s05_alt4_first_dot",
            name = "05. General ALT 4 (First Dot Split)",
            badge = "Поддомены",
            zapretPcEquivalent = "general (ALT4).bat (split on first dot)",
            description = "Разрезает имя хоста на первой точке (например, www.|youtube.com).",
            mode = DesyncMode.SNI_FIRST_DOT,
            args = listOf("-s", "1+s", "-q", "1"),
            recommendedFor = "Ресурсы с множеством поддоменов и CDN"
        ),
        WhitezStrategy(
            id = "s06_alt5_last_dot",
            name = "06. General ALT 5 (TLD Dot Split)",
            badge = "Зона домена",
            zapretPcEquivalent = "general (ALT5).bat (split before TLD)",
            description = "Разбивает запрос перед доменной зоной (.com, .gg, .org).",
            mode = DesyncMode.SNI_LAST_DOT,
            args = listOf("-s", "-1+s", "-q", "1"),
            recommendedFor = "Сайты и сервисы в зонах .gg / .org / .io"
        ),
        WhitezStrategy(
            id = "s07_alt6_pos_1",
            name = "07. General ALT 6 (Split Pos 1)",
            badge = "1 байт",
            zapretPcEquivalent = "general (ALT6).bat (split=1)",
            description = "Отправляет первый байт ClientHello отдельным сегментом.",
            mode = DesyncMode.OFFSET_1_BYTE,
            args = listOf("-s", "1", "-q", "1"),
            recommendedFor = "Лёгкий обход с минимальными накладными расходами"
        ),
        WhitezStrategy(
            id = "s08_alt7_pos_2",
            name = "08. General ALT 7 (Split Pos 2)",
            badge = "2 байта",
            zapretPcEquivalent = "general (ALT7).bat (split=2)",
            description = "Разделяет TLS ClientHello на 2-м байте.",
            mode = DesyncMode.OFFSET_2_BYTE,
            args = listOf("-s", "2", "-q", "1"),
            recommendedFor = "Сети, где split=1 не даёт эффекта"
        ),
        WhitezStrategy(
            id = "s09_alt8_pos_3",
            name = "09. General ALT 8 (Split Pos 3)",
            badge = "3 байта",
            zapretPcEquivalent = "general (ALT8).bat (split=3)",
            description = "Разделяет стартовый пакет на 3-м байте.",
            mode = DesyncMode.OFFSET_3_BYTE,
            args = listOf("-s", "3", "-q", "1"),
            recommendedFor = "Локальные провайдеры и домашний Wi-Fi"
        ),
        WhitezStrategy(
            id = "s10_alt9_pos_5",
            name = "10. General ALT 9 (Split Pos 5)",
            badge = "TLS Header",
            zapretPcEquivalent = "general (ALT9).bat (split=5)",
            description = "Отделяет 5-байтный заголовок TLS Record от тела Handshake.",
            mode = DesyncMode.OFFSET_5_BYTE,
            args = listOf("-s", "5", "-q", "1"),
            recommendedFor = "DPI-системы, анализирующие границу TLS-записи"
        ),
        WhitezStrategy(
            id = "s11_alt10_multi_1_sni",
            name = "11. General ALT 10 (Multi Split SNI)",
            badge = "Мульти-сплит",
            zapretPcEquivalent = "general (ALT10).bat (multisplit 1,mid,end)",
            description = "Нарезает пакет в трёх ключевых точках: начало, середина и конец SNI.",
            mode = DesyncMode.MULTI_1_SNI_END,
            args = listOf("-s", "1", "-s", "0+s", "-s", "1+s", "-q", "1"),
            recommendedFor = "МТС, Билайн, МегаФон, Т2 (провод и 4G)"
        ),
        WhitezStrategy(
            id = "s12_alt11_multi_2_5",
            name = "12. General ALT 11 (Multi 2+5+SNI)",
            badge = "Комбо-сплит",
            zapretPcEquivalent = "general (ALT11).bat (multisplit 2,5,mid)",
            description = "Комбинированная нарезка заголовка и имени хоста.",
            mode = DesyncMode.MULTI_2_5_MID_SNI,
            args = listOf("-s", "2", "-s", "5", "-s", "0+s", "-q", "1"),
            recommendedFor = "Региональные операторы и сложные ТСПУ"
        ),
        WhitezStrategy(
            id = "s13_alt12_multi_4x",
            name = "13. General ALT 12 (4-Chunk Split)",
            badge = "4 фрагмента",
            zapretPcEquivalent = "general (ALT12).bat (4-part multisplit)",
            description = "Делит ClientHello на 4 фрагмента для затруднения сборки сигнатуры.",
            mode = DesyncMode.MULTI_1_6_MID_END,
            args = listOf("-s", "1", "-s", "6", "-s", "0+s", "-s", "1+s", "-q", "1"),
            recommendedFor = "Мобильный интернет 4G/5G с жёстким DPI"
        ),
        WhitezStrategy(
            id = "s14_alt13_disorder_mid",
            name = "14. General ALT 13 (Disorder Mid-SNI)",
            badge = "Disorder",
            zapretPcEquivalent = "general (ALT13).bat (disorder midsld)",
            description = "Отправляет вторую половину SNI перед первой с разрывом по центру.",
            mode = DesyncMode.DISORDER_MID_SNI,
            args = listOf("-d", "1", "-s", "0+s", "-q", "1"),
            recommendedFor = "Системы DPI, чувствительные к порядку TCP-сегментов"
        ),
        WhitezStrategy(
            id = "s15_alt14_disorder_2",
            name = "15. General ALT 14 (Disorder Pos 2)",
            badge = "Анти-сброс",
            zapretPcEquivalent = "general (ALT14).bat (disorder pos 2)",
            description = "Инверсия сегментов при разделении на 2-м байте.",
            mode = DesyncMode.DISORDER_2_BYTE,
            args = listOf("-d", "1", "-s", "2", "-q", "1"),
            recommendedFor = "Соединения с обрывами при загрузке видео"
        ),
        WhitezStrategy(
            id = "s16_alt15_disorder_5",
            name = "16. General ALT 15 (Disorder Pos 5)",
            badge = "Disorder 5B",
            zapretPcEquivalent = "general (ALT15).bat (disorder pos 5)",
            description = "Инверсия сегментов на границе TLS-заголовка (5 байт).",
            mode = DesyncMode.DISORDER_5_BYTE,
            args = listOf("-d", "1", "-s", "5", "-q", "1"),
            recommendedFor = "Проверка устойчивости к перестановке сегментов"
        ),
        WhitezStrategy(
            id = "s17_alt16_fake_google",
            name = "17. General ALT 16 (Fake SNI Google)",
            badge = "Fake Google",
            zapretPcEquivalent = "general (ALT16).bat (fake www.google.com)",
            description = "Отправляет префикс с разрешённым SNI www.google.com перед реальным запросом.",
            mode = DesyncMode.FAKE_SNI_GOOGLE,
            args = listOf("--fake-sni", "www.google.com", "-s", "0+s", "-q", "1"),
            recommendedFor = "Провайдеры с фильтрацией по списку запрещённых SNI"
        ),
        WhitezStrategy(
            id = "s18_alt17_fake_ya",
            name = "18. General ALT 17 (Fake SNI ya.ru)",
            badge = "Fake Yandex",
            zapretPcEquivalent = "general (ALT17).bat (fake ya.ru)",
            description = "Использует маскировку под домен ya.ru и разрез SNI.",
            mode = DesyncMode.FAKE_SNI_YA,
            args = listOf("--fake-sni", "ya.ru", "-r", "1+s", "-s", "0+s", "-q", "1"),
            recommendedFor = "Российские сети с белым списком для ya.ru"
        ),
        WhitezStrategy(
            id = "s19_alt18_fake_vk",
            name = "19. General ALT 18 (Fake SNI vk.com)",
            badge = "Fake VK",
            zapretPcEquivalent = "general (ALT18).bat (fake vk.com)",
            description = "Использует маскировку под домен vk.com и фрагментацию TLS.",
            mode = DesyncMode.FAKE_SNI_VK,
            args = listOf("--fake-sni", "vk.com", "-r", "1+s", "-s", "0+s", "-q", "1"),
            recommendedFor = "Сети, где vk.com проходит без ограничений"
        ),
        WhitezStrategy(
            id = "s20_alt19_fake_cf",
            name = "20. General ALT 19 (Fake SNI Cloudflare)",
            badge = "Fake CF",
            zapretPcEquivalent = "general (ALT19).bat (fake cloudflare.com)",
            description = "Комбинирует имитацию cloudflare.com с разрезом по середине SNI.",
            mode = DesyncMode.FAKE_SNI_CLOUDFLARE,
            args = listOf("--fake-sni", "cloudflare.com", "-s", "1", "-s", "0+s", "-q", "1"),
            recommendedFor = "Дополнительный вариант для обхода фильтрации SNI"
        ),
        WhitezStrategy(
            id = "s21_quic_only",
            name = "21. QUIC Block Only (UDP 443)",
            badge = "Только QUIC",
            zapretPcEquivalent = "quic_block_only (UDP 443 drop)",
            description = "Блокирует QUIC (UDP 443), переводя трафик на TCP без изменения TLS-пакетов.",
            mode = DesyncMode.QUIC_DROP_ONLY,
            args = emptyList(),
            recommendedFor = "Проверка работы сервиса только через TCP/TLS"
        )
    )

    val targetDomains: List<String> = listOf(
        "youtube.com",
        "www.youtube.com",
        "m.youtube.com",
        "youtu.be",
        "googlevideo.com",
        "ytimg.com",
        "ggpht.com",
        "youtubei.googleapis.com",
        "discord.com",
        "gateway.discord.gg",
        "cdn.discordapp.com",
        "media.discordapp.net",
        "rutracker.org",
        "ntc.party"
    )
}
