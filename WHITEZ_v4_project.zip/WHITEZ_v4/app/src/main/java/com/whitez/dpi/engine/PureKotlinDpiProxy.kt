package com.whitez.dpi.engine

import android.net.VpnService
import android.util.Log
import com.whitez.dpi.model.DesyncMode
import com.whitez.dpi.model.WhitezStrategy
import kotlinx.coroutines.*
import java.io.InputStream
import java.io.OutputStream
import java.net.InetSocketAddress
import java.net.ServerSocket
import java.net.Socket

class PureKotlinDpiProxy(
    private val vpnService: VpnService?,
    private val port: Int,
    private val strategy: WhitezStrategy,
    private val targetDomains: Set<String>
) {
    companion object {
        private const val TAG = "WhitezDpiProxy"
    }

    private var serverSocket: ServerSocket? = null
    private var job: Job? = null

    fun start(scope: CoroutineScope) {
        stop()
        job = scope.launch(Dispatchers.IO) {
            try {
                serverSocket = ServerSocket().apply {
                    reuseAddress = true
                    bind(InetSocketAddress("127.0.0.1", port))
                }
                Log.i(TAG, "WHITEZ SOCKS5 запущен на порту $port (${strategy.name})")
                while (isActive) {
                    val client = try {
                        serverSocket?.accept()
                    } catch (_: Exception) {
                        null
                    } ?: break
                    launch { handleSocksClient(client) }
                }
            } catch (e: Exception) {
                if (isActive) Log.e(TAG, "Ошибка SOCKS5 сервера", e)
            }
        }
    }

    fun stop() {
        try {
            serverSocket?.close()
        } catch (_: Exception) {
        }
        serverSocket = null
        job?.cancel()
        job = null
    }

    private suspend fun handleSocksClient(client: Socket) = withContext(Dispatchers.IO) {
        var remote: Socket? = null
        try {
            client.tcpNoDelay = true
            val input = client.getInputStream()
            val output = client.getOutputStream()

            val ver = input.read()
            if (ver != 5) {
                client.close()
                return@withContext
            }
            val nMethods = input.read()
            if (nMethods > 0) input.readNBytesCompat(nMethods)
            output.write(byteArrayOf(0x05, 0x00))
            output.flush()

            val reqHeader = input.readNBytesCompat(4)
            if (reqHeader.size < 4 || reqHeader[1].toInt() != 0x01) {
                client.close()
                return@withContext
            }

            val host: String
            when (reqHeader[3].toInt()) {
                0x01 -> {
                    val addr = input.readNBytesCompat(4)
                    host = addr.joinToString(".") { (it.toInt() and 0xFF).toString() }
                }
                0x03 -> {
                    val len = input.read()
                    host = String(input.readNBytesCompat(len), Charsets.UTF_8)
                }
                0x04 -> {
                    val addr = input.readNBytesCompat(16)
                    host = addr.toList().chunked(2).joinToString(":") {
                        "%02x%02x".format(it[0], it[1])
                    }
                }
                else -> {
                    client.close()
                    return@withContext
                }
            }

            val portBytes = input.readNBytesCompat(2)
            val destPort = ((portBytes[0].toInt() and 0xFF) shl 8) or (portBytes[1].toInt() and 0xFF)

            remote = Socket().apply {
                tcpNoDelay = true
                vpnService?.protect(this)
                connect(InetSocketAddress(host, destPort), 3500)
            }

            output.write(byteArrayOf(0x05, 0x00, 0x00, 0x01, 0, 0, 0, 0, 0, 0))
            output.flush()

            val remoteIn = remote.getInputStream()
            val remoteOut = remote.getOutputStream()

            val c2r = launch {
                try {
                    relayClientToRemote(input, remoteOut, host, destPort)
                } catch (_: Exception) {
                }
            }
            val r2c = launch {
                try {
                    relayStream(remoteIn, output)
                } catch (_: Exception) {
                }
            }
            joinAll(c2r, r2c)
        } catch (_: Exception) {
        } finally {
            try { client.close() } catch (_: Exception) {}
            try { remote?.close() } catch (_: Exception) {}
        }
    }

    private fun relayClientToRemote(
        input: InputStream,
        output: OutputStream,
        host: String,
        port: Int
    ) {
        val buffer = ByteArray(16384)
        var isFirstPacket = true
        while (true) {
            val read = input.read(buffer)
            if (read <= 0) break

            if (isFirstPacket && port == 443 && read > 12 && buffer[0] == 0x16.toByte()) {
                isFirstPacket = false
                val sniInfo = findSniOffset(buffer, read)
                val sniHost = sniInfo?.first ?: host

                val shouldApplyDpi = targetDomains.isEmpty() ||
                        targetDomains.any { sniHost.endsWith(it, ignoreCase = true) }

                if (shouldApplyDpi && strategy.mode != DesyncMode.QUIC_DROP_ONLY) {
                    applyDesync(output, buffer, read, sniInfo)
                    continue
                }
            }
            isFirstPacket = false
            output.write(buffer, 0, read)
            output.flush()
        }
    }

    private fun applyDesync(
        output: OutputStream,
        data: ByteArray,
        length: Int,
        sniInfo: Triple<String, Int, Int>?
    ) {
        val sniStart = sniInfo?.second ?: -1
        val sniLen = sniInfo?.third ?: 0
        val sniStr = sniInfo?.first ?: ""

        val midSni = if (sniStart > 0 && sniLen > 1) sniStart + (sniLen / 2) else minOf(length / 2, 42)
        val firstDotPos = if (sniStart > 0 && sniStr.indexOf('.') > 0) {
            sniStart + sniStr.indexOf('.')
        } else {
            minOf(length / 3, 24)
        }
        val lastDotPos = if (sniStart > 0 && sniStr.lastIndexOf('.') > 0) {
            sniStart + sniStr.lastIndexOf('.')
        } else {
            maxOf(10, length - 12)
        }
        val sniEndPos = if (sniStart > 0 && sniLen > 0) sniStart + sniLen else minOf(length - 4, 64)

        when (strategy.mode) {
            DesyncMode.TLS_RECORD_1_BYTE -> {
                sendTlsSplitRecord(output, data, length, 1)
            }
            DesyncMode.TLS_RECORD_MID_SNI -> {
                sendTlsSplitRecord(output, data, length, midSni)
            }
            DesyncMode.TLS_RECORD_EXT_OFFSET -> {
                val extPos = if (sniStart > 5) sniStart - 5 else 6
                sendTlsSplitRecord(output, data, length, extPos)
            }
            DesyncMode.SNI_MID_SPLIT -> {
                sendSplitTcp(output, data, length, intArrayOf(midSni))
            }
            DesyncMode.SNI_FIRST_DOT -> {
                sendSplitTcp(output, data, length, intArrayOf(firstDotPos))
            }
            DesyncMode.SNI_LAST_DOT -> {
                sendSplitTcp(output, data, length, intArrayOf(lastDotPos))
            }
            DesyncMode.OFFSET_1_BYTE -> {
                sendSplitTcp(output, data, length, intArrayOf(1))
            }
            DesyncMode.OFFSET_2_BYTE -> {
                sendSplitTcp(output, data, length, intArrayOf(2))
            }
            DesyncMode.OFFSET_3_BYTE -> {
                sendSplitTcp(output, data, length, intArrayOf(3))
            }
            DesyncMode.OFFSET_5_BYTE -> {
                sendSplitTcp(output, data, length, intArrayOf(5))
            }
            DesyncMode.MULTI_1_SNI_END -> {
                sendSplitTcp(output, data, length, intArrayOf(1, midSni, sniEndPos))
            }
            DesyncMode.MULTI_2_5_MID_SNI -> {
                sendSplitTcp(output, data, length, intArrayOf(2, 5, midSni))
            }
            DesyncMode.MULTI_1_6_MID_END -> {
                sendSplitTcp(output, data, length, intArrayOf(1, 6, midSni, sniEndPos))
            }
            DesyncMode.DISORDER_MID_SNI -> {
                sendDisorderTcp(output, data, length, midSni)
            }
            DesyncMode.DISORDER_2_BYTE -> {
                sendDisorderTcp(output, data, length, 2)
            }
            DesyncMode.DISORDER_5_BYTE -> {
                sendDisorderTcp(output, data, length, 5)
            }
            DesyncMode.FAKE_SNI_GOOGLE,
            DesyncMode.FAKE_SNI_YA,
            DesyncMode.FAKE_SNI_VK,
            DesyncMode.FAKE_SNI_CLOUDFLARE -> {
                sendTlsSplitRecord(output, data, length, midSni)
            }
            DesyncMode.QUIC_DROP_ONLY -> {
                output.write(data, 0, length)
                output.flush()
            }
        }
    }

    private fun sendTlsSplitRecord(output: OutputStream, data: ByteArray, length: Int, splitAt: Int) {
        val payloadLen = ((data[3].toInt() and 0xFF) shl 8) or (data[4].toInt() and 0xFF)
        if (payloadLen + 5 == length && splitAt in 6..(length - 2)) {
            val verMajor = data[1]
            val verMinor = data[2]
            val p1Len = splitAt - 5
            val p2Len = length - splitAt

            val rec1 = ByteArray(5 + p1Len).apply {
                this[0] = 0x16
                this[1] = verMajor
                this[2] = verMinor
                this[3] = ((p1Len shr 8) and 0xFF).toByte()
                this[4] = (p1Len and 0xFF).toByte()
                System.arraycopy(data, 5, this, 5, p1Len)
            }
            val rec2 = ByteArray(5 + p2Len).apply {
                this[0] = 0x16
                this[1] = verMajor
                this[2] = verMinor
                this[3] = ((p2Len shr 8) and 0xFF).toByte()
                this[4] = (p2Len and 0xFF).toByte()
                System.arraycopy(data, splitAt, this, 5, p2Len)
            }
            output.write(rec1)
            output.write(rec2)
            output.flush()
        } else {
            sendSplitTcp(output, data, length, intArrayOf(splitAt))
        }
    }

    private fun sendSplitTcp(output: OutputStream, data: ByteArray, length: Int, splitPoints: IntArray) {
        var prev = 0
        for (pt in splitPoints.sorted().distinct()) {
            if (pt in (prev + 1) until length) {
                output.write(data, prev, pt - prev)
                prev = pt
            }
        }
        if (prev < length) {
            output.write(data, prev, length - prev)
        }
        output.flush()
    }

    private fun sendDisorderTcp(output: OutputStream, data: ByteArray, length: Int, splitPos: Int) {
        val pos = splitPos.coerceIn(1, maxOf(1, length - 1))
        output.write(data, pos, length - pos)
        output.write(data, 0, pos)
        output.flush()
    }

    private fun findSniOffset(data: ByteArray, len: Int): Triple<String, Int, Int>? {
        try {
            if (len < 44 || data[0] != 0x16.toByte() || data[5] != 0x01.toByte()) return null
            var pos = 43
            val sessionIdLen = data[pos].toInt() and 0xFF
            pos += 1 + sessionIdLen
            if (pos + 2 > len) return null

            val cipherSuitesLen = ((data[pos].toInt() and 0xFF) shl 8) or (data[pos + 1].toInt() and 0xFF)
            pos += 2 + cipherSuitesLen
            if (pos + 1 > len) return null

            val compMethodsLen = data[pos].toInt() and 0xFF
            pos += 1 + compMethodsLen
            if (pos + 2 > len) return null

            val extensionsLen = ((data[pos].toInt() and 0xFF) shl 8) or (data[pos + 1].toInt() and 0xFF)
            pos += 2
            val endExt = minOf(len, pos + extensionsLen)

            while (pos + 4 <= endExt) {
                val extType = ((data[pos].toInt() and 0xFF) shl 8) or (data[pos + 1].toInt() and 0xFF)
                val extLen = ((data[pos + 2].toInt() and 0xFF) shl 8) or (data[pos + 3].toInt() and 0xFF)
                pos += 4
                if (extType == 0x0000 && pos + 5 <= endExt) {
                    val nameLen = ((data[pos + 3].toInt() and 0xFF) shl 8) or (data[pos + 4].toInt() and 0xFF)
                    val nameStart = pos + 5
                    if (nameStart + nameLen <= endExt) {
                        val domain = String(data, nameStart, nameLen, Charsets.US_ASCII)
                        return Triple(domain, nameStart, nameLen)
                    }
                }
                pos += extLen
            }
        } catch (_: Exception) {
        }
        return null
    }

    private fun relayStream(input: InputStream, output: OutputStream) {
        val buffer = ByteArray(16384)
        while (true) {
            val read = input.read(buffer)
            if (read <= 0) break
            output.write(buffer, 0, read)
            output.flush()
        }
    }

    private fun InputStream.readNBytesCompat(n: Int): ByteArray {
        val buf = ByteArray(n)
        var offset = 0
        while (offset < n) {
            val read = read(buf, offset, n - offset)
            if (read <= 0) break
            offset += read
        }
        return if (offset == n) buf else buf.copyOf(offset)
    }
}
