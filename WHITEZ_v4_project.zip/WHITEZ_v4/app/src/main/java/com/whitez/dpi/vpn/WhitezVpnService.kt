package com.whitez.dpi.vpn

import android.app.Notification
import android.app.PendingIntent
import android.content.Intent
import android.net.ConnectivityManager
import android.net.Network
import android.net.NetworkCapabilities
import android.net.NetworkRequest
import android.net.VpnService
import android.os.Build
import android.os.ParcelFileDescriptor
import android.util.Log
import androidx.core.app.NotificationCompat
import com.whitez.dpi.MainActivity
import com.whitez.dpi.WhitezApp
import com.whitez.dpi.data.SettingsRepository
import com.whitez.dpi.engine.NativeDpiEngine
import com.whitez.dpi.engine.PureKotlinDpiProxy
import com.whitez.dpi.model.StrategyRepository
import com.whitez.dpi.model.WhitezStrategy
import kotlinx.coroutines.*
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.first
import java.io.File
import java.io.FileInputStream
import java.io.FileOutputStream
import java.io.InputStream
import java.io.OutputStream
import java.net.DatagramPacket
import java.net.DatagramSocket
import java.net.InetAddress
import java.net.InetSocketAddress
import java.net.Socket
import java.util.concurrent.ConcurrentHashMap
import java.util.concurrent.Executors

enum class VpnState {
    DISCONNECTED,
    CONNECTING,
    CONNECTED,
    ERROR
}

class WhitezVpnService : VpnService() {

    companion object {
        private const val TAG = "WhitezVpnService"
        private const val NOTIFICATION_ID = 2026

        const val ACTION_START = "com.whitez.dpi.START"
        const val ACTION_STOP = "com.whitez.dpi.STOP"
        const val ACTION_RESTART = "com.whitez.dpi.RESTART"

        private val _vpnState = MutableStateFlow(VpnState.DISCONNECTED)
        val vpnState: StateFlow<VpnState> = _vpnState

        private val _activeStrategy = MutableStateFlow<WhitezStrategy?>(null)
        val activeStrategy: StateFlow<WhitezStrategy?> = _activeStrategy

        private val _networkType = MutableStateFlow("Сеть активна")
        val networkType: StateFlow<String> = _networkType
    }

    private val ioExecutor = Executors.newCachedThreadPool()
    private val ioDispatcher = ioExecutor.asCoroutineDispatcher()
    private val serviceScope = CoroutineScope(SupervisorJob() + ioDispatcher)

    private var vpnInterface: ParcelFileDescriptor? = null
    private lateinit var nativeEngine: NativeDpiEngine
    private var kotlinProxy: PureKotlinDpiProxy? = null
    private var networkCallback: ConnectivityManager.NetworkCallback? = null
    private val tcpSessions = ConcurrentHashMap<String, TcpTunSession>()

    override fun onCreate() {
        super.onCreate()
        nativeEngine = NativeDpiEngine(this)
        refreshCurrentNetwork()
        registerNetworkWatcher()
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        refreshCurrentNetwork()
        when (intent?.action) {
            ACTION_STOP -> {
                stopVpn()
                stopSelf()
                return START_NOT_STICKY
            }
            ACTION_RESTART -> {
                serviceScope.launch {
                    stopVpn()
                    delay(120)
                    startVpn()
                }
            }
            else -> {
                startForeground(NOTIFICATION_ID, buildNotification("Запуск WHITEZ..."))
                serviceScope.launch {
                    startVpn()
                }
            }
        }
        return START_STICKY
    }

    private suspend fun startVpn() {
        if (_vpnState.value == VpnState.CONNECTED) return
        _vpnState.value = VpnState.CONNECTING

        try {
            val settingsRepo = SettingsRepository(applicationContext)
            val settings = settingsRepo.settingsFlow.first()
            val strategy = StrategyRepository.strategies.find { it.id == settings.selectedStrategyId }
                ?: StrategyRepository.strategies.first()

            _activeStrategy.value = strategy

            val allDomains = buildSet {
                addAll(StrategyRepository.targetDomains)
                settings.customDomainsRaw
                    .split("\n", ",", " ")
                    .map { it.trim() }
                    .filter { it.isNotBlank() }
                    .forEach { add(it) }
            }

            val hostsFile = writeHostsFile(allDomains)

            val nativeStarted = nativeEngine.startDpiProxy(
                strategy = strategy,
                port = NativeDpiEngine.SOCKS_PORT,
                hostsFilePath = if (settings.onlyTargetDomains) hostsFile.absolutePath else null
            )

            if (!nativeStarted) {
                kotlinProxy = PureKotlinDpiProxy(
                    vpnService = this,
                    port = NativeDpiEngine.SOCKS_PORT,
                    strategy = strategy,
                    targetDomains = if (settings.onlyTargetDomains) allDomains else emptySet()
                ).also { it.start(serviceScope) }
            }

            val builder = Builder()
                .setSession("WHITEZ (${strategy.name})")
                .setMtu(1500)
                .addAddress("10.10.0.2", 24)
                .addDnsServer("8.8.8.8")
                .addDnsServer("1.1.1.1")
                .addRoute("0.0.0.0", 0)

            try {
                builder.addDisallowedApplication(packageName)
            } catch (_: Exception) {
            }

            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                builder.setMetered(false)
            }

            vpnInterface = builder.establish()
            val pfd = vpnInterface ?: throw IllegalStateException("Не удалось создать TUN-интерфейс")

            startTunPacketLoop(pfd, settings.blockQuic || strategy.blockQuic)

            _vpnState.value = VpnState.CONNECTED
            updateNotification("Активно • ${strategy.name}")
        } catch (e: Exception) {
            Log.e(TAG, "Ошибка запуска WHITEZ", e)
            _vpnState.value = VpnState.ERROR
            stopVpn()
        }
    }

    private fun startTunPacketLoop(pfd: ParcelFileDescriptor, blockQuic: Boolean) {
        val tunInput = FileInputStream(pfd.fileDescriptor)
        val tunOutput = FileOutputStream(pfd.fileDescriptor)
        val writeLock = Any()

        fun writeToTun(packet: ByteArray) {
            synchronized(writeLock) {
                try {
                    tunOutput.write(packet)
                } catch (_: Exception) {
                }
            }
        }

        serviceScope.launch {
            val buffer = ByteArray(32767)
            while (isActive && _vpnState.value == VpnState.CONNECTED) {
                val len = try {
                    tunInput.read(buffer)
                } catch (_: Exception) {
                    break
                }
                if (len <= 0) continue

                val ipVer = (buffer[0].toInt() shr 4) and 0x0F
                if (ipVer != 4 || len < 20) continue

                val ihl = (buffer[0].toInt() and 0x0F) * 4
                val protocol = buffer[9].toInt() and 0xFF
                val srcIp = ByteArray(4).also { System.arraycopy(buffer, 12, it, 0, 4) }
                val dstIp = ByteArray(4).also { System.arraycopy(buffer, 16, it, 0, 4) }

                when (protocol) {
                    17 -> {
                        if (len >= ihl + 8) {
                            val srcPort = readU16(buffer, ihl)
                            val dstPort = readU16(buffer, ihl + 2)
                            val udpLen = readU16(buffer, ihl + 4)
                            val payloadOffset = ihl + 8
                            val payloadLen = minOf(len - payloadOffset, udpLen - 8)

                            if (blockQuic && dstPort == 443) {
                                continue
                            }

                            if (payloadLen > 0) {
                                val payload = ByteArray(payloadLen)
                                System.arraycopy(buffer, payloadOffset, payload, 0, payloadLen)
                                ioExecutor.execute {
                                    forwardUdpPacket(srcIp, srcPort, dstIp, dstPort, payload, ::writeToTun)
                                }
                            }
                        }
                    }

                    6 -> {
                        if (len >= ihl + 20) {
                            val srcPort = readU16(buffer, ihl)
                            val dstPort = readU16(buffer, ihl + 2)
                            val seqNum = readU32(buffer, ihl + 4)
                            val tcpHeaderLen = ((buffer[ihl + 12].toInt() shr 4) and 0x0F) * 4
                            val flags = buffer[ihl + 13].toInt() and 0xFF
                            val payloadOffset = ihl + tcpHeaderLen
                            val payloadLen = maxOf(0, len - payloadOffset)

                            val dstIpStr = dstIp.joinToString(".") { (it.toInt() and 0xFF).toString() }
                            val key = "$srcPort->$dstIpStr:$dstPort"

                            val isSyn = (flags and 0x02) != 0
                            val isFin = (flags and 0x01) != 0
                            val isRst = (flags and 0x04) != 0

                            if (isRst) {
                                tcpSessions.remove(key)?.close()
                                continue
                            }

                            if (isSyn) {
                                tcpSessions.remove(key)?.close()
                                val session = TcpTunSession(
                                    key = key,
                                    clientIp = srcIp,
                                    clientPort = srcPort,
                                    serverIp = dstIp,
                                    serverPort = dstPort,
                                    clientIsn = seqNum,
                                    writeTun = ::writeToTun,
                                    onClosed = { tcpSessions.remove(key) }
                                )
                                tcpSessions[key] = session
                                ioExecutor.execute { session.runLoop() }
                            } else {
                                val session = tcpSessions[key]
                                if (session != null) {
                                    if (payloadLen > 0) {
                                        val payload = ByteArray(payloadLen)
                                        System.arraycopy(buffer, payloadOffset, payload, 0, payloadLen)
                                        session.onClientData(seqNum, payload)
                                    }
                                    if (isFin) {
                                        session.onClientFin(seqNum + payloadLen)
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }

    private fun forwardUdpPacket(
        clientIp: ByteArray,
        clientPort: Int,
        serverIp: ByteArray,
        serverPort: Int,
        payload: ByteArray,
        writeTun: (ByteArray) -> Unit
    ) {
        var udpSocket: DatagramSocket? = null
        try {
            udpSocket = DatagramSocket()
            protect(udpSocket)
            udpSocket.soTimeout = 2500
            val destAddr = InetAddress.getByAddress(serverIp)
            udpSocket.send(DatagramPacket(payload, payload.size, destAddr, serverPort))

            val respBuf = ByteArray(4096)
            val respPacket = DatagramPacket(respBuf, respBuf.size)
            udpSocket.receive(respPacket)

            val respData = ByteArray(respPacket.length)
            System.arraycopy(respBuf, 0, respData, 0, respPacket.length)
            val ipUdpPacket = buildIpv4UdpPacket(serverIp, serverPort, clientIp, clientPort, respData)
            writeTun(ipUdpPacket)
        } catch (_: Exception) {
        } finally {
            try {
                udpSocket?.close()
            } catch (_: Exception) {
            }
        }
    }

    private inner class TcpTunSession(
        val key: String,
        val clientIp: ByteArray,
        val clientPort: Int,
        val serverIp: ByteArray,
        val serverPort: Int,
        clientIsn: Long,
        val writeTun: (ByteArray) -> Unit,
        val onClosed: () -> Unit
    ) {
        @Volatile
        private var active = true
        private var socksSocket: Socket? = null
        private var socksOut: OutputStream? = null

        private val serverIsn = (System.nanoTime() and 0x7FFFFFFFL) + 1000L
        private var serverSeq = serverIsn
        private var clientNextSeq = (clientIsn + 1L) and 0xFFFFFFFFL
        private val pendingOut = ArrayList<ByteArray>()
        private var connected = false

        fun runLoop() {
            try {
                val sock = Socket().apply {
                    tcpNoDelay = true
                    receiveBufferSize = 65536
                    sendBufferSize = 65536
                    connect(InetSocketAddress("127.0.0.1", NativeDpiEngine.SOCKS_PORT), 3000)
                }
                socksSocket = sock
                val out = sock.getOutputStream()
                val inp = sock.getInputStream()
                socksOut = out

                out.write(byteArrayOf(0x05, 0x01, 0x00))
                out.flush()
                val greet = ByteArray(2)
                if (inp.read(greet) < 2 || greet[1] != 0x00.toByte()) {
                    closeWithRst()
                    return
                }

                val req = ByteArray(10)
                req[0] = 0x05
                req[1] = 0x01
                req[2] = 0x00
                req[3] = 0x01
                System.arraycopy(serverIp, 0, req, 4, 4)
                req[8] = ((serverPort shr 8) and 0xFF).toByte()
                req[9] = (serverPort and 0xFF).toByte()
                out.write(req)
                out.flush()

                val rep = ByteArray(10)
                var readTotal = 0
                while (readTotal < 10) {
                    val r = inp.read(rep, readTotal, 10 - readTotal)
                    if (r <= 0) break
                    readTotal += r
                }
                if (readTotal < 10 || rep[1] != 0x00.toByte()) {
                    closeWithRst()
                    return
                }

                sendTcp(flags = 0x12, payload = ByteArray(0))
                serverSeq = (serverSeq + 1L) and 0xFFFFFFFFL

                synchronized(pendingOut) {
                    connected = true
                    for (chunk in pendingOut) {
                        out.write(chunk)
                    }
                    out.flush()
                    pendingOut.clear()
                }

                val buf = ByteArray(4096)
                while (active) {
                    val n = inp.read(buf)
                    if (n <= 0) break
                    val chunk = ByteArray(n)
                    System.arraycopy(buf, 0, chunk, 0, n)
                    sendTcp(flags = 0x18, payload = chunk)
                    serverSeq = (serverSeq + n.toLong()) and 0xFFFFFFFFL
                }

                if (active) {
                    sendTcp(flags = 0x11, payload = ByteArray(0))
                    serverSeq = (serverSeq + 1L) and 0xFFFFFFFFL
                }
            } catch (_: Exception) {
                if (active) closeWithRst()
            } finally {
                close()
            }
        }

        fun onClientData(seqNum: Long, data: ByteArray) {
            if (!active) return
            if (seqNum == clientNextSeq) {
                clientNextSeq = (clientNextSeq + data.size.toLong()) and 0xFFFFFFFFL
                sendTcp(flags = 0x10, payload = ByteArray(0))
                synchronized(pendingOut) {
                    if (connected) {
                        try {
                            socksOut?.write(data)
                            socksOut?.flush()
                        } catch (_: Exception) {
                            close()
                        }
                    } else {
                        pendingOut.add(data)
                    }
                }
            } else {
                sendTcp(flags = 0x10, payload = ByteArray(0))
            }
        }

        fun onClientFin(finSeq: Long) {
            if (!active) return
            clientNextSeq = (finSeq + 1L) and 0xFFFFFFFFL
            sendTcp(flags = 0x11, payload = ByteArray(0))
            close()
        }

        private fun sendTcp(flags: Int, payload: ByteArray) {
            val pkt = buildIpv4TcpPacket(
                srcIp = serverIp,
                srcPort = serverPort,
                dstIp = clientIp,
                dstPort = clientPort,
                seq = serverSeq,
                ack = clientNextSeq,
                flags = flags,
                payload = payload
            )
            writeTun(pkt)
        }

        private fun closeWithRst() {
            try {
                sendTcp(flags = 0x14, payload = ByteArray(0))
            } catch (_: Exception) {
            }
            close()
        }

        fun close() {
            active = false
            try { socksSocket?.close() } catch (_: Exception) {}
            socksSocket = null
            onClosed()
        }
    }

    private fun buildIpv4UdpPacket(
        srcIp: ByteArray,
        srcPort: Int,
        dstIp: ByteArray,
        dstPort: Int,
        payload: ByteArray
    ): ByteArray {
        val udpLen = 8 + payload.size
        val totalLen = 20 + udpLen
        val pkt = ByteArray(totalLen)

        pkt[0] = 0x45
        writeU16(pkt, 2, totalLen)
        pkt[8] = 64
        pkt[9] = 17
        System.arraycopy(srcIp, 0, pkt, 12, 4)
        System.arraycopy(dstIp, 0, pkt, 16, 4)
        writeU16(pkt, 10, computeIpChecksum(pkt, 0, 20))

        writeU16(pkt, 20, srcPort)
        writeU16(pkt, 22, dstPort)
        writeU16(pkt, 24, udpLen)
        writeU16(pkt, 26, 0)
        System.arraycopy(payload, 0, pkt, 28, payload.size)

        return pkt
    }

    private fun buildIpv4TcpPacket(
        srcIp: ByteArray,
        srcPort: Int,
        dstIp: ByteArray,
        dstPort: Int,
        seq: Long,
        ack: Long,
        flags: Int,
        payload: ByteArray
    ): ByteArray {
        val tcpLen = 20 + payload.size
        val totalLen = 20 + tcpLen
        val pkt = ByteArray(totalLen)

        pkt[0] = 0x45
        writeU16(pkt, 2, totalLen)
        pkt[8] = 64
        pkt[9] = 6
        System.arraycopy(srcIp, 0, pkt, 12, 4)
        System.arraycopy(dstIp, 0, pkt, 16, 4)
        writeU16(pkt, 10, computeIpChecksum(pkt, 0, 20))

        writeU16(pkt, 20, srcPort)
        writeU16(pkt, 22, dstPort)
        writeU32(pkt, 24, seq)
        writeU32(pkt, 28, ack)
        pkt[32] = 0x50
        pkt[33] = flags.toByte()
        writeU16(pkt, 34, 65535)
        System.arraycopy(payload, 0, pkt, 40, payload.size)

        val tcpCsum = computeTcpChecksum(srcIp, dstIp, pkt, 20, tcpLen)
        writeU16(pkt, 36, tcpCsum)
        return pkt
    }

    private fun computeIpChecksum(buf: ByteArray, offset: Int, len: Int): Int {
        var sum = 0L
        var i = offset
        while (i < offset + len) {
            val word = ((buf[i].toInt() and 0xFF) shl 8) or (buf[i + 1].toInt() and 0xFF)
            sum += word
            i += 2
        }
        while ((sum shr 16) != 0L) {
            sum = (sum and 0xFFFFL) + (sum shr 16)
        }
        return (sum.inv() and 0xFFFFL).toInt()
    }

    private fun computeTcpChecksum(
        srcIp: ByteArray,
        dstIp: ByteArray,
        pkt: ByteArray,
        tcpOffset: Int,
        tcpLen: Int
    ): Int {
        var sum = 0L
        sum += ((srcIp[0].toInt() and 0xFF) shl 8) or (srcIp[1].toInt() and 0xFF)
        sum += ((srcIp[2].toInt() and 0xFF) shl 8) or (srcIp[3].toInt() and 0xFF)
        sum += ((dstIp[0].toInt() and 0xFF) shl 8) or (dstIp[1].toInt() and 0xFF)
        sum += ((dstIp[2].toInt() and 0xFF) shl 8) or (dstIp[3].toInt() and 0xFF)
        sum += 6L
        sum += tcpLen.toLong()

        var i = 0
        while (i + 1 < tcpLen) {
            val word = ((pkt[tcpOffset + i].toInt() and 0xFF) shl 8) or
                    (pkt[tcpOffset + i + 1].toInt() and 0xFF)
            sum += word
            i += 2
        }
        if (i < tcpLen) {
            sum += ((pkt[tcpOffset + i].toInt() and 0xFF) shl 8)
        }
        while ((sum shr 16) != 0L) {
            sum = (sum and 0xFFFFL) + (sum shr 16)
        }
        return (sum.inv() and 0xFFFFL).toInt()
    }

    private fun readU16(buf: ByteArray, off: Int): Int =
        ((buf[off].toInt() and 0xFF) shl 8) or (buf[off + 1].toInt() and 0xFF)

    private fun readU32(buf: ByteArray, off: Int): Long =
        ((buf[off].toLong() and 0xFFL) shl 24) or
                ((buf[off + 1].toLong() and 0xFFL) shl 16) or
                ((buf[off + 2].toLong() and 0xFFL) shl 8) or
                (buf[off + 3].toLong() and 0xFFL)

    private fun writeU16(buf: ByteArray, off: Int, value: Int) {
        buf[off] = ((value shr 8) and 0xFF).toByte()
        buf[off + 1] = (value and 0xFF).toByte()
    }

    private fun writeU32(buf: ByteArray, off: Int, value: Long) {
        buf[off] = ((value shr 24) and 0xFFL).toByte()
        buf[off + 1] = ((value shr 16) and 0xFFL).toByte()
        buf[off + 2] = ((value shr 8) and 0xFFL).toByte()
        buf[off + 3] = (value and 0xFFL).toByte()
    }

    private fun writeHostsFile(domains: Set<String>): File {
        val file = File(filesDir, "whitez_hosts.txt")
        file.writeText(domains.joinToString("\n"))
        return file
    }

    private fun stopVpn() {
        _vpnState.value = VpnState.DISCONNECTED
        _activeStrategy.value = null
        tcpSessions.values.forEach { it.close() }
        tcpSessions.clear()
        kotlinProxy?.stop()
        kotlinProxy = null
        nativeEngine.stopDpiProxy()
        try {
            vpnInterface?.close()
        } catch (_: Exception) {
        }
        vpnInterface = null
    }

    private fun refreshCurrentNetwork() {
        val cm = getSystemService(ConnectivityManager::class.java)
        val activeNet = cm?.activeNetwork
        if (activeNet != null) {
            updateNetworkLabel(cm, activeNet)
        }
    }

    private fun registerNetworkWatcher() {
        val cm = getSystemService(ConnectivityManager::class.java)
        val request = NetworkRequest.Builder()
            .addCapability(NetworkCapabilities.NET_CAPABILITY_INTERNET)
            .build()

        networkCallback = object : ConnectivityManager.NetworkCallback() {
            override fun onAvailable(network: Network) {
                updateNetworkLabel(cm, network)
            }

            override fun onCapabilitiesChanged(network: Network, caps: NetworkCapabilities) {
                updateNetworkLabel(cm, network)
            }
        }
        try {
            cm.registerNetworkCallback(request, networkCallback!!)
        } catch (_: Exception) {
        }
    }

    private fun updateNetworkLabel(cm: ConnectivityManager, network: Network) {
        val caps = cm.getNetworkCapabilities(network) ?: return
        _networkType.value = when {
            caps.hasTransport(NetworkCapabilities.TRANSPORT_WIFI) -> "Wi-Fi"
            caps.hasTransport(NetworkCapabilities.TRANSPORT_CELLULAR) -> "4G / 5G"
            caps.hasTransport(NetworkCapabilities.TRANSPORT_ETHERNET) -> "Ethernet"
            else -> "Сеть активна"
        }
    }

    private fun buildNotification(text: String): Notification {
        val openIntent = PendingIntent.getActivity(
            this,
            0,
            Intent(this, MainActivity::class.java),
            PendingIntent.FLAG_IMMUTABLE
        )

        val stopIntent = PendingIntent.getService(
            this,
            1,
            Intent(this, WhitezVpnService::class.java).apply { action = ACTION_STOP },
            PendingIntent.FLAG_IMMUTABLE
        )

        return NotificationCompat.Builder(this, WhitezApp.CHANNEL_ID)
            .setContentTitle("WHITEZ")
            .setContentText(text)
            .setSmallIcon(android.R.drawable.ic_lock_lock)
            .setContentIntent(openIntent)
            .addAction(android.R.drawable.ic_media_pause, "Отключить", stopIntent)
            .setOngoing(true)
            .build()
    }

    private fun updateNotification(text: String) {
        val nm = getSystemService(android.app.NotificationManager::class.java)
        nm.notify(NOTIFICATION_ID, buildNotification(text))
    }

    override fun onDestroy() {
        networkCallback?.let {
            try {
                getSystemService(ConnectivityManager::class.java).unregisterNetworkCallback(it)
            } catch (_: Exception) {
            }
        }
        stopVpn()
        serviceScope.cancel()
        ioExecutor.shutdownNow()
        super.onDestroy()
    }
}
