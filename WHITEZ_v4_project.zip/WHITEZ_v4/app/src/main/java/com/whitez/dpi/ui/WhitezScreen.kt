package com.whitez.dpi.ui

import androidx.compose.animation.animateColorAsState
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.whitez.dpi.model.StrategyRepository
import com.whitez.dpi.model.WhitezStrategy
import com.whitez.dpi.ui.theme.*
import com.whitez.dpi.vpn.VpnState

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun WhitezMainScreen(
    viewModel: MainViewModel,
    onRequestVpnPermission: () -> Unit
) {
    val vpnState by viewModel.vpnState.collectAsState()
    val settings by viewModel.settings.collectAsState()
    val networkType by viewModel.networkType.collectAsState()
    val autoTest by viewModel.autoTestState.collectAsState()

    var selectedTab by remember { mutableIntStateOf(0) }

    val selectedStrategy = remember(settings.selectedStrategyId) {
        StrategyRepository.strategies.find { it.id == settings.selectedStrategyId }
            ?: StrategyRepository.strategies.first()
    }

    Scaffold(
        containerColor = BgDark,
        topBar = {
            TopAppBar(
                title = {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text(
                            text = "WHITEZ",
                            fontWeight = FontWeight.ExtraBold,
                            letterSpacing = 2.sp,
                            color = TextPrimary
                        )
                        Spacer(Modifier.width(8.dp))
                        Surface(
                            color = SurfaceElevated,
                            shape = RoundedCornerShape(6.dp),
                            border = BorderStroke(1.dp, AccentCyan.copy(alpha = 0.4f))
                        ) {
                            Text(
                                text = "21 STRATEGIES",
                                fontSize = 10.sp,
                                fontWeight = FontWeight.Bold,
                                color = AccentCyan,
                                modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                            )
                        }
                    }
                },
                actions = {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        modifier = Modifier.padding(end = 16.dp)
                    ) {
                        Icon(
                            imageVector = Icons.Rounded.CellTower,
                            contentDescription = null,
                            tint = AccentCyan,
                            modifier = Modifier.size(16.dp)
                        )
                        Spacer(Modifier.width(4.dp))
                        Text(
                            text = networkType,
                            fontSize = 12.sp,
                            color = TextSecondary
                        )
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(containerColor = BgDark)
            )
        },
        bottomBar = {
            NavigationBar(
                containerColor = SurfaceDark,
                tonalElevation = 0.dp
            ) {
                NavigationBarItem(
                    selected = selectedTab == 0,
                    onClick = { selectedTab = 0 },
                    icon = { Icon(Icons.Rounded.PowerSettingsNew, contentDescription = null) },
                    label = { Text("Главная") }
                )
                NavigationBarItem(
                    selected = selectedTab == 1,
                    onClick = { selectedTab = 1 },
                    icon = { Icon(Icons.Rounded.Tune, contentDescription = null) },
                    label = { Text("Стратегии") }
                )
                NavigationBarItem(
                    selected = selectedTab == 2,
                    onClick = { selectedTab = 2 },
                    icon = { Icon(Icons.Rounded.Speed, contentDescription = null) },
                    label = { Text("Автоподбор") }
                )
                NavigationBarItem(
                    selected = selectedTab == 3,
                    onClick = { selectedTab = 3 },
                    icon = { Icon(Icons.Rounded.Language, contentDescription = null) },
                    label = { Text("Домены") }
                )
            }
        }
    ) { padding ->
        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
        ) {
            when (selectedTab) {
                0 -> HomeTab(
                    vpnState = vpnState,
                    selectedStrategy = selectedStrategy,
                    onToggleConnection = {
                        if (vpnState == VpnState.CONNECTED || vpnState == VpnState.CONNECTING) {
                            viewModel.stopVpnService()
                        } else {
                            onRequestVpnPermission()
                        }
                    },
                    onOpenStrategies = { selectedTab = 1 },
                    onRunAutoPick = {
                        selectedTab = 2
                        viewModel.startAutoPick()
                    }
                )
                1 -> StrategiesTab(
                    selectedId = settings.selectedStrategyId,
                    onSelect = { viewModel.selectStrategy(it) }
                )
                2 -> AutoPickTab(
                    autoTest = autoTest,
                    onStartTest = { viewModel.startAutoPick() },
                    onCancelTest = { viewModel.cancelAutoPick() },
                    onApplyStrategy = {
                        viewModel.selectStrategy(it)
                        selectedTab = 0
                    }
                )
                3 -> DomainsAndSettingsTab(
                    onlyTargetDomains = settings.onlyTargetDomains,
                    blockQuic = settings.blockQuic,
                    customDomains = settings.customDomainsRaw,
                    onToggleOnlyTarget = viewModel::toggleOnlyTargetDomains,
                    onToggleBlockQuic = viewModel::toggleBlockQuic,
                    onCustomDomainsChange = viewModel::updateCustomDomains
                )
            }
        }
    }
}

@Composable
private fun HomeTab(
    vpnState: VpnState,
    selectedStrategy: WhitezStrategy,
    onToggleConnection: () -> Unit,
    onOpenStrategies: () -> Unit,
    onRunAutoPick: () -> Unit
) {
    val isConnected = vpnState == VpnState.CONNECTED

    val buttonColor by animateColorAsState(
        targetValue = when (vpnState) {
            VpnState.CONNECTED -> AccentGreen
            VpnState.CONNECTING -> AccentAmber
            VpnState.ERROR -> AccentRed
            VpnState.DISCONNECTED -> SurfaceElevated
        },
        label = "btnColor"
    )

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(20.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.SpaceBetween
    ) {
        Spacer(Modifier.height(6.dp))

        Column(horizontalAlignment = Alignment.CenterHorizontally) {
            Box(
                contentAlignment = Alignment.Center,
                modifier = Modifier
                    .size(180.dp)
                    .clip(CircleShape)
                    .background(buttonColor.copy(alpha = 0.14f))
                    .clickable { onToggleConnection() }
            ) {
                Surface(
                    shape = CircleShape,
                    color = buttonColor,
                    border = BorderStroke(
                        2.dp,
                        if (isConnected) AccentGreen else AccentCyan.copy(alpha = 0.35f)
                    ),
                    modifier = Modifier.size(138.dp)
                ) {
                    Box(contentAlignment = Alignment.Center) {
                        Icon(
                            imageVector = Icons.Rounded.PowerSettingsNew,
                            contentDescription = "Включить WHITEZ",
                            tint = if (isConnected) Color.Black else TextPrimary,
                            modifier = Modifier.size(58.dp)
                        )
                    }
                }
            }

            Spacer(Modifier.height(18.dp))

            Text(
                text = when (vpnState) {
                    VpnState.CONNECTED -> "WHITEZ активен"
                    VpnState.CONNECTING -> "Запуск обхода DPI..."
                    VpnState.ERROR -> "Ошибка запуска"
                    VpnState.DISCONNECTED -> "Отключено"
                },
                fontSize = 21.sp,
                fontWeight = FontWeight.Bold,
                color = when (vpnState) {
                    VpnState.CONNECTED -> AccentGreen
                    VpnState.ERROR -> AccentRed
                    else -> TextPrimary
                }
            )

            Spacer(Modifier.height(6.dp))

            Text(
                text = if (isConnected)
                    "Трафик YouTube и заблокированных сайтов проходит через локальный десинхронизатор пакетов"
                else
                    "Нажмите кнопку выше для запуска выбранной стратегии под вашего провайдера",
                fontSize = 13.sp,
                color = TextSecondary,
                modifier = Modifier.padding(horizontal = 20.dp),
                lineHeight = 18.sp
            )
        }

        Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
            Surface(
                color = SurfaceDark,
                shape = RoundedCornerShape(14.dp),
                border = BorderStroke(1.dp, BorderDark),
                modifier = Modifier
                    .fillMaxWidth()
                    .clickable { onOpenStrategies() }
            ) {
                Row(
                    modifier = Modifier.padding(16.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Column(modifier = Modifier.weight(1f)) {
                        Text(
                            text = "ТЕКУЩАЯ СТРАТЕГИЯ (${StrategyRepository.strategies.size} ДОСТУПНО)",
                            fontSize = 11.sp,
                            fontWeight = FontWeight.SemiBold,
                            color = AccentCyan
                        )
                        Spacer(Modifier.height(4.dp))
                        Text(
                            text = selectedStrategy.name,
                            fontSize = 16.sp,
                            fontWeight = FontWeight.SemiBold,
                            color = TextPrimary
                        )
                        Spacer(Modifier.height(2.dp))
                        Text(
                            text = selectedStrategy.recommendedFor,
                            fontSize = 12.sp,
                            color = TextSecondary
                        )
                    }
                    Icon(
                        imageVector = Icons.Rounded.ChevronRight,
                        contentDescription = null,
                        tint = TextSecondary
                    )
                }
            }

            OutlinedButton(
                onClick = onRunAutoPick,
                shape = RoundedCornerShape(12.dp),
                border = BorderStroke(1.dp, AccentCyan),
                modifier = Modifier
                    .fillMaxWidth()
                    .height(50.dp)
            ) {
                Icon(Icons.Rounded.AutoFixHigh, contentDescription = null, tint = AccentCyan)
                Spacer(Modifier.width(8.dp))
                Text(
                    text = "Автоподбор из 21 стратегии",
                    color = TextPrimary,
                    fontWeight = FontWeight.SemiBold
                )
            }
        }
    }
}

@Composable
private fun StrategiesTab(
    selectedId: String,
    onSelect: (WhitezStrategy) -> Unit
) {
    LazyColumn(
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        item {
            Text(
                text = "Стратегии Zapret (${StrategyRepository.strategies.size} режимов)",
                fontSize = 18.sp,
                fontWeight = FontWeight.Bold,
                color = TextPrimary,
                modifier = Modifier.padding(bottom = 4.dp)
            )
            Text(
                text = "Разные провайдеры и сети по-разному реагируют на сплит, SNI и disorder — выберите режим под вашу сеть.",
                fontSize = 13.sp,
                color = TextSecondary,
                modifier = Modifier.padding(bottom = 8.dp)
            )
        }

        items(StrategyRepository.strategies) { strategy ->
            val isSelected = strategy.id == selectedId
            Surface(
                color = if (isSelected) SurfaceElevated else SurfaceDark,
                shape = RoundedCornerShape(14.dp),
                border = BorderStroke(
                    width = if (isSelected) 1.5.dp else 1.dp,
                    color = if (isSelected) AccentCyan else BorderDark
                ),
                modifier = Modifier
                    .fillMaxWidth()
                    .clickable { onSelect(strategy) }
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween,
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Text(
                            text = strategy.name,
                            fontSize = 15.sp,
                            fontWeight = FontWeight.Bold,
                            color = TextPrimary,
                            modifier = Modifier.weight(1f)
                        )
                        Spacer(Modifier.width(8.dp))
                        Surface(
                            color = BgDark,
                            shape = RoundedCornerShape(6.dp),
                            border = BorderStroke(1.dp, BorderDark)
                        ) {
                            Text(
                                text = strategy.badge,
                                fontSize = 11.sp,
                                color = if (isSelected) AccentGreen else AccentCyan,
                                modifier = Modifier.padding(horizontal = 8.dp, vertical = 3.dp)
                            )
                        }
                    }

                    Spacer(Modifier.height(6.dp))

                    Text(
                        text = strategy.description,
                        fontSize = 13.sp,
                        color = TextSecondary,
                        lineHeight = 18.sp
                    )

                    Spacer(Modifier.height(6.dp))

                    Text(
                        text = "Для сети: ${strategy.recommendedFor}",
                        fontSize = 12.sp,
                        color = TextPrimary.copy(alpha = 0.85f)
                    )

                    Spacer(Modifier.height(4.dp))

                    Text(
                        text = "ПК-аналог: ${strategy.zapretPcEquivalent}",
                        fontSize = 11.sp,
                        color = AccentCyan.copy(alpha = 0.85f)
                    )
                }
            }
        }
    }
}

@Composable
private fun AutoPickTab(
    autoTest: AutoTestUiState,
    onStartTest: () -> Unit,
    onCancelTest: () -> Unit,
    onApplyStrategy: (WhitezStrategy) -> Unit
) {
    LazyColumn(
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        item {
            Text(
                text = "Автоподбор из ${StrategyRepository.strategies.size} стратегий",
                fontSize = 18.sp,
                fontWeight = FontWeight.Bold,
                color = TextPrimary
            )
            Spacer(Modifier.height(4.dp))
            Text(
                text = "Последовательно проверяет стратегии на доступность YouTube и серверов видео (googlevideo.com).",
                fontSize = 13.sp,
                color = TextSecondary
            )
            Spacer(Modifier.height(12.dp))

            if (autoTest.isRunning) {
                Surface(
                    color = SurfaceDark,
                    shape = RoundedCornerShape(14.dp),
                    border = BorderStroke(1.dp, BorderDark),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(modifier = Modifier.padding(16.dp)) {
                        Row(
                            horizontalArrangement = Arrangement.SpaceBetween,
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Text(
                                text = "Тест: ${autoTest.currentStrategyName}",
                                fontSize = 14.sp,
                                fontWeight = FontWeight.SemiBold,
                                color = TextPrimary,
                                modifier = Modifier.weight(1f)
                            )
                            Text(
                                text = "${autoTest.progressIndex}/${autoTest.totalCount}",
                                fontSize = 14.sp,
                                color = AccentCyan
                            )
                        }
                        Spacer(Modifier.height(10.dp))
                        LinearProgressIndicator(
                            progress = {
                                if (autoTest.totalCount > 0)
                                    autoTest.progressIndex.toFloat() / autoTest.totalCount
                                else 0f
                            },
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(6.dp)
                                .clip(RoundedCornerShape(3.dp)),
                            color = AccentCyan,
                            trackColor = BgDark
                        )
                        Spacer(Modifier.height(12.dp))
                        TextButton(onClick = onCancelTest) {
                            Text("Остановить", color = AccentRed)
                        }
                    }
                }
            } else {
                Button(
                    onClick = onStartTest,
                    shape = RoundedCornerShape(12.dp),
                    colors = ButtonDefaults.buttonColors(containerColor = AccentCyan),
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(48.dp)
                ) {
                    Icon(Icons.Rounded.PlayArrow, contentDescription = null, tint = Color.Black)
                    Spacer(Modifier.width(8.dp))
                    Text("Проверить все 21 стратегий", color = Color.Black, fontWeight = FontWeight.Bold)
                }
            }
        }

        autoTest.bestStrategy?.let { winner ->
            item {
                Surface(
                    color = AccentGreen.copy(alpha = 0.12f),
                    shape = RoundedCornerShape(14.dp),
                    border = BorderStroke(1.dp, AccentGreen),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(modifier = Modifier.padding(16.dp)) {
                        Text(
                            text = "ЛУЧШАЯ СТРАТЕГИЯ НАЙДЕНА",
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Bold,
                            color = AccentGreen
                        )
                        Spacer(Modifier.height(4.dp))
                        Text(
                            text = "${winner.strategy.name} (${winner.latencyMs} мс)",
                            fontSize = 16.sp,
                            fontWeight = FontWeight.Bold,
                            color = TextPrimary
                        )
                        Spacer(Modifier.height(10.dp))
                        Button(
                            onClick = { onApplyStrategy(winner.strategy) },
                            colors = ButtonDefaults.buttonColors(containerColor = AccentGreen),
                            shape = RoundedCornerShape(10.dp)
                        ) {
                            Text("Применить и включить", color = Color.Black, fontWeight = FontWeight.Bold)
                        }
                    }
                }
            }
        }

        items(autoTest.results) { res ->
            Surface(
                color = SurfaceDark,
                shape = RoundedCornerShape(12.dp),
                border = BorderStroke(1.dp, BorderDark),
                modifier = Modifier
                    .fillMaxWidth()
                    .clickable(enabled = res.isSuccess) { onApplyStrategy(res.strategy) }
            ) {
                Row(
                    modifier = Modifier.padding(14.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Column(modifier = Modifier.weight(1f)) {
                        Text(
                            text = res.strategy.name,
                            fontSize = 14.sp,
                            fontWeight = FontWeight.SemiBold,
                            color = TextPrimary
                        )
                        Text(
                            text = res.details,
                            fontSize = 12.sp,
                            color = if (res.isSuccess) AccentGreen else TextSecondary
                        )
                    }
                    Icon(
                        imageVector = if (res.isSuccess) Icons.Rounded.CheckCircle else Icons.Rounded.Cancel,
                        contentDescription = null,
                        tint = if (res.isSuccess) AccentGreen else AccentRed
                    )
                }
            }
        }
    }
}

@Composable
private fun DomainsAndSettingsTab(
    onlyTargetDomains: Boolean,
    blockQuic: Boolean,
    customDomains: String,
    onToggleOnlyTarget: (Boolean) -> Unit,
    onToggleBlockQuic: (Boolean) -> Unit,
    onCustomDomainsChange: (String) -> Unit
) {
    LazyColumn(
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        item {
            Text(
                text = "Фильтрация и домены",
                fontSize = 18.sp,
                fontWeight = FontWeight.Bold,
                color = TextPrimary
            )
        }

        item {
            Surface(
                color = SurfaceDark,
                shape = RoundedCornerShape(14.dp),
                border = BorderStroke(1.dp, BorderDark)
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween,
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Column(modifier = Modifier.weight(1f)) {
                            Text(
                                text = "Только список доменов (Split Tunneling)",
                                fontSize = 15.sp,
                                fontWeight = FontWeight.SemiBold,
                                color = TextPrimary
                            )
                            Text(
                                text = "Банки, Госуслуги и игры идут напрямую с нулевой задержкой",
                                fontSize = 12.sp,
                                color = TextSecondary
                            )
                        }
                        Switch(
                            checked = onlyTargetDomains,
                            onCheckedChange = onToggleOnlyTarget
                        )
                    }

                    HorizontalDivider(
                        color = BorderDark,
                        modifier = Modifier.padding(vertical = 12.dp)
                    )

                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween,
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Column(modifier = Modifier.weight(1f)) {
                            Text(
                                text = "Блокировать QUIC (UDP 443)",
                                fontSize = 15.sp,
                                fontWeight = FontWeight.SemiBold,
                                color = TextPrimary
                            )
                            Text(
                                text = "Переводит YouTube с HTTP/3 на TCP для срабатывания обхода DPI",
                                fontSize = 12.sp,
                                color = TextSecondary
                            )
                        }
                        Switch(
                            checked = blockQuic,
                            onCheckedChange = onToggleBlockQuic
                        )
                    }
                }
            }
        }

        item {
            Text(
                text = "Свои домены (по одному на строку)",
                fontSize = 14.sp,
                fontWeight = FontWeight.SemiBold,
                color = TextPrimary
            )
            Spacer(Modifier.height(6.dp))
            OutlinedTextField(
                value = customDomains,
                onValueChange = onCustomDomainsChange,
                placeholder = { Text("example.com\nmy-site.org") },
                modifier = Modifier
                    .fillMaxWidth()
                    .height(130.dp),
                shape = RoundedCornerShape(12.dp)
            )
        }

        item {
            Text(
                text = "Встроенный список (${StrategyRepository.targetDomains.size} доменов):",
                fontSize = 13.sp,
                fontWeight = FontWeight.SemiBold,
                color = TextSecondary
            )
            Spacer(Modifier.height(6.dp))
            Surface(
                color = SurfaceDark,
                shape = RoundedCornerShape(12.dp),
                border = BorderStroke(1.dp, BorderDark),
                modifier = Modifier.fillMaxWidth()
            ) {
                Text(
                    text = StrategyRepository.targetDomains.joinToString(", "),
                    fontSize = 12.sp,
                    color = TextSecondary,
                    modifier = Modifier.padding(12.dp)
                )
            }
        }
    }
}
