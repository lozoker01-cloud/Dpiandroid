# WHITEZ
GitHub Actions -> Build WHITEZ APK -> Run workflow -> артефакт WHITEZ-apk (debug APK).
Или Android Studio: Build -> Build APK(s). minSdk 29 (Android 10+).
Ядра скачиваются в app/libs автоматически. Ссылку подписки вводите в приложении.
