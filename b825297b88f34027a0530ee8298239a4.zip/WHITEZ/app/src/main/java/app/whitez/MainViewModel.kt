package app.whitez
import android.app.Application
import android.content.Context
import android.content.Intent
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.launch
import libv2ray.Libv2ray

object State {
    val running = MutableStateFlow(false)
    val error = MutableStateFlow<String?>(null)
}

class MainViewModel(app: Application) : AndroidViewModel(app) {
    private val prefs = app.getSharedPreferences("w", Context.MODE_PRIVATE)
    val url = MutableStateFlow(prefs.getString("url", "") ?: "")
    val servers = MutableStateFlow<List<Server>>(emptyList())
    val status = MutableStateFlow("Вставьте ссылку подписки")
    val busy = MutableStateFlow(false)
    val selected = MutableStateFlow<Server?>(null)

    init { try { Libv2ray.initCoreEnv(app.filesDir.path, "") } catch (_: Throwable) {} }

    fun setUrl(v: String) { url.value = v; prefs.edit().putString("url", v).apply() }

    fun refresh() = viewModelScope.launch {
        busy.value = true; status.value = "Загрузка подписки…"
        try {
            val list = Net.fetchSubscription(url.value)
            val ranked = Net.rank(list) { status.value = it }
            servers.value = ranked
            val best = ranked.firstOrNull { it.realMs >= 0 } ?: ranked.firstOrNull { it.pingMs >= 0 }
            selected.value = best
            status.value = best?.let {
                if (it.realMs >= 0) "Лучший: ${it.label} (${it.realMs} мс)" else "Лучший: ${it.label} (TCP ${it.pingMs} мс)"
            } ?: "Нет доступных узлов"
        } catch (e: Exception) { status.value = "Ошибка: ${e.message}" }
        busy.value = false
    }

    fun start() {
        val s = selected.value ?: return
        State.error.value = null
        val i = Intent(getApplication(), WhitezVpnService::class.java).putExtra("config", XrayConfig.build(s))
        getApplication<Application>().startForegroundService(i)
    }
    fun stop() {
        getApplication<Application>().startService(
            Intent(getApplication(), WhitezVpnService::class.java).setAction("STOP"))
    }
}
