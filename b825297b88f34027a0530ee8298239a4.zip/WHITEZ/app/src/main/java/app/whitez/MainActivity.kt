package app.whitez
import android.app.Activity
import android.net.VpnService
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.activity.viewModels
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

class MainActivity : ComponentActivity() {
    private val vm: MainViewModel by viewModels()
    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        if (android.os.Build.VERSION.SDK_INT >= 33)
            requestPermissions(arrayOf(android.Manifest.permission.POST_NOTIFICATIONS), 1)
        setContent { MaterialTheme(colorScheme = darkColorScheme()) { Screen(vm) } }
    }
}

@Composable
fun Screen(vm: MainViewModel) {
    val url by vm.url.collectAsState(); val servers by vm.servers.collectAsState()
    val status by vm.status.collectAsState(); val busy by vm.busy.collectAsState()
    val sel by vm.selected.collectAsState(); val on by State.running.collectAsState()
    val err by State.error.collectAsState()
    val ctx = LocalContext.current
    val perm = rememberLauncherForActivityResult(ActivityResultContracts.StartActivityForResult()) {
        if (it.resultCode == Activity.RESULT_OK) vm.start()
    }
    val accent = if (on) Color(0xFF22D3A6) else Color(0xFF6366F1)

    Column(Modifier.fillMaxSize()
        .background(Brush.verticalGradient(listOf(Color(0xFF0B0F1A), Color(0xFF151B33))))
        .statusBarsPadding().padding(20.dp), horizontalAlignment = Alignment.CenterHorizontally) {
        Text("WHITEZ", fontSize = 30.sp, fontWeight = FontWeight.Black, color = Color.White, letterSpacing = 6.sp)
        Spacer(Modifier.height(24.dp))
        Box(Modifier.size(150.dp).background(accent.copy(alpha = 0.18f), CircleShape).padding(14.dp)
            .background(accent, CircleShape).clickable(enabled = sel != null) {
                if (on) vm.stop() else {
                    val i = VpnService.prepare(ctx)
                    if (i != null) perm.launch(i) else vm.start()
                }
            }, contentAlignment = Alignment.Center) {
            Text(if (on) "ВКЛ" else "СТАРТ", color = Color.White, fontSize = 22.sp, fontWeight = FontWeight.Bold)
        }
        Spacer(Modifier.height(14.dp))
        Text(status, color = Color(0xFFB8C0E0))
        err?.let { Text("Ошибка VPN: $it", color = Color(0xFFFF6B6B)) }
        Spacer(Modifier.height(16.dp))
        OutlinedTextField(url, vm::setUrl, label = { Text("Ссылка подписки") },
            singleLine = true, modifier = Modifier.fillMaxWidth())
        Spacer(Modifier.height(8.dp))
        Button(onClick = { vm.refresh() }, enabled = !busy && url.isNotBlank(),
            modifier = Modifier.fillMaxWidth()) { Text(if (busy) "Подождите…" else "Обновить и выбрать лучший") }
        Spacer(Modifier.height(12.dp))
        LazyColumn(verticalArrangement = Arrangement.spacedBy(8.dp)) {
            items(servers) { s ->
                val ms = if (s.realMs >= 0) s.realMs else s.pingMs
                Row(Modifier.fillMaxWidth().background(
                    if (s == sel) Color(0x336366F1) else Color(0x22FFFFFF), RoundedCornerShape(14.dp))
                    .clickable { vm.selected.value = s }.padding(14.dp),
                    horizontalArrangement = Arrangement.SpaceBetween) {
                    Text(s.label, color = Color.White, modifier = Modifier.weight(1f))
                    Text(if (ms < 0) "—" else "$ms мс",
                        color = if (ms in 0..300) Color(0xFF22D3A6) else Color(0xFFFFB020))
                }
            }
        }
    }
}
