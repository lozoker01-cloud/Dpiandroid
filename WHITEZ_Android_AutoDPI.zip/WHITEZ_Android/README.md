# WHITEZ Android — Автоматический обход DPI в 1 нажатие

## Почему старые стратегии давали `SocketTimeoutException` на Android
На ПК `zapret` / `GoodbyeDPI` работают через драйвер WinDivert (уровень ядра Windows), где можно отправлять поддельные пакеты с низким TTL (`Fake SNI`) или битой контрольной суммой (`BadSum`).
На Android без root-прав приложение работает через `VpnService` (пользовательский уровень). Попытка применить ПК-стратегии (`Fake SNI Google / vk / ya.ru`) на Android приводит к двум проблемам:
1. Android-сокет не даёт подменить IP TTL и TCP checksum без root — в итоге «фейковый» пакет доходит до реального сервера и ломает TLS-рукопожатие, вызывая `SocketTimeoutException`.
2. Если тестовый сокет автоподбора не защищён через `VpnService.protect(socket)`, трафик зацикливается сам в себя через TUN-интерфейс и умирает по таймауту.

## Как устроен новый движок WHITEZ
1. **Нулевая настройка (1 кнопка):** Пользователь нажимает одну кнопку **«ВКЛЮЧИТЬ»**. Никаких вкладок с доменами, списками стратегий и ручных параметров.
2. **Защищённый автоподбор (`AutoSelector`):** Перед запуском туннеля приложение через `VpnService.protect()` за 1–2 секунды проверяет 5 реальных non-root стратегий (как в ByeDPI / PowerTunnel) и само выбирает самую быструю для текущего оператора.
3. **Защита от петли и DNS-блокировок:**
   - `builder.addDisallowedApplication(packageName)` исключает сам WHITEZ из VPN-маршрутизации.
   - Принудительные DNS `1.1.1.1` и `8.8.8.8` обходят зависания системного Private DNS.
   - Автоматический сброс QUIC (`UDP 443`) переводит браузеры и приложения на `TCP + TLS`, где работает фрагментация SNI (`Split`, `TLS Record Split`, `OOB Urgent Byte`, `TCP Disorder`).

## Сборка APK
1. Откройте папку `WHITEZ_Android` в **Android Studio** (Iguana / Jellyfish / Koala или новее).
2. Дождитесь синхронизации Gradle.
3. Нажмите **Build → Build Bundle(s) / APK(s) → Build APK(s)**.
4. Готовый файл `app-debug.apk` появится в `app/build/outputs/apk/debug/`.
