package com.whitez.dpi.engine

enum class DesyncMethod {
    SPLIT,
    DISORDER,
    OOB,
    TLSREC_SPLIT
}

data class DpiStrategy(
    val id: Int,
    val name: String,
    val description: String,
    val method: DesyncMethod,
    val splitOffset: Int = 2,
    val tlsRecordSplitOffset: Int = 1,
    val oobByte: Byte = 0x00,
    val blockQuic: Boolean = true,
    val hostMixedCase: Boolean = true
)

object StrategyCatalog {
    /**
     * Стратегии, адаптированные специально под Android без root (VpnService + TCP Proxy).
     * Исключены Fake-TTL/BadSum стратегии, вызывающие SocketTimeoutException в Java-сокетах.
     */
    val STRATEGIES = listOf(
        DpiStrategy(
            id = 1,
            name = "Smart Split + QUIC Drop (Универсальная)",
            description = "Разрезает TLS ClientHello на 2-м байте и блокирует UDP/443 (QUIC)",
            method = DesyncMethod.SPLIT,
            splitOffset = 2,
            blockQuic = true
        ),
        DpiStrategy(
            id = 2,
            name = "TLS Record Split (Мягкий обход)",
            description = "Делит TLS-запись на два фрагмента до проверки SNI",
            method = DesyncMethod.TLSREC_SPLIT,
            tlsRecordSplitOffset = 1,
            splitOffset = 3,
            blockQuic = true
        ),
        DpiStrategy(
            id = 3,
            name = "OOB Urgent Byte (Против жёсткого ТСПУ)",
            description = "Отправляет Out-Of-Band байт перед SNI с разрывом пакета",
            method = DesyncMethod.OOB,
            splitOffset = 1,
            oobByte = 0x20,
            blockQuic = true
        ),
        DpiStrategy(
            id = 4,
            name = "TCP Disorder + Split (Анти-реассемблинг)",
            description = "Дробит стартовый пакет мелкими чанками с задержкой сегментации",
            method = DesyncMethod.DISORDER,
            splitOffset = 1,
            blockQuic = true
        ),
        DpiStrategy(
            id = 5,
            name = "Deep SNI Split (Смещение 5 байт)",
            description = "Разрез ровно перед началом имени домена в ClientHello",
            method = DesyncMethod.SPLIT,
            splitOffset = 5,
            blockQuic = true
        )
    )
}
