package com.whitez.dpi.vpn

import java.net.InetAddress
import java.nio.ByteBuffer

object PacketBuilder {

    fun buildUdpIpv4Packet(
        srcIp: InetAddress,
        srcPort: Int,
        dstIp: InetAddress,
        dstPort: Int,
        payload: ByteArray
    ): ByteArray {
        val udpLen = 8 + payload.size
        val totalLen = 20 + udpLen
        val buf = ByteBuffer.allocate(totalLen)

        // IPv4 Header
        buf.put(0x45.toByte())
        buf.put(0x00.toByte())
        buf.putShort(totalLen.toShort())
        buf.putShort(0)
        buf.putShort(0x4000.toShort())
        buf.put(64.toByte())
        buf.put(17.toByte()) // UDP
        buf.putShort(0) // checksum placeholder
        buf.put(srcIp.address)
        buf.put(dstIp.address)

        val ipChecksum = checksum(buf.array(), 0, 20)
        buf.putShort(10, ipChecksum)

        // UDP Header
        buf.putShort(srcPort.toShort())
        buf.putShort(dstPort.toShort())
        buf.putShort(udpLen.toShort())
        buf.putShort(0) // UDP checksum optional in IPv4
        buf.put(payload)

        return buf.array()
    }

    fun buildTcpIpv4Packet(
        srcIp: InetAddress,
        srcPort: Int,
        dstIp: InetAddress,
        dstPort: Int,
        seq: Long,
        ack: Long,
        flags: Int,
        payload: ByteArray
    ): ByteArray {
        val tcpLen = 20 + payload.size
        val totalLen = 20 + tcpLen
        val buf = ByteBuffer.allocate(totalLen)

        // IPv4 Header
        buf.put(0x45.toByte())
        buf.put(0x00.toByte())
        buf.putShort(totalLen.toShort())
        buf.putShort(0)
        buf.putShort(0x4000.toShort())
        buf.put(64.toByte())
        buf.put(6.toByte()) // TCP
        buf.putShort(0)
        buf.put(srcIp.address)
        buf.put(dstIp.address)

        val ipChecksum = checksum(buf.array(), 0, 20)
        buf.putShort(10, ipChecksum)

        // TCP Header
        buf.putShort(srcPort.toShort())
        buf.putShort(dstPort.toShort())
        buf.putInt(seq.toInt())
        buf.putInt(ack.toInt())
        buf.put(0x50.toByte()) // Data offset 5 (20 bytes)
        buf.put(flags.toByte())
        buf.putShort(65535.toShort()) // Window size
        buf.putShort(0) // TCP checksum placeholder
        buf.putShort(0) // Urgent pointer
        buf.put(payload)

        val tcpChecksum = tcpChecksum(srcIp.address, dstIp.address, buf.array(), 20, tcpLen)
        buf.putShort(36, tcpChecksum)

        return buf.array()
    }

    private fun checksum(data: ByteArray, offset: Int, length: Int): Short {
        var sum = 0L
        var i = offset
        val end = offset + length
        while (i < end - 1) {
            val word = ((data[i].toInt() and 0xFF) shl 8) or (data[i + 1].toInt() and 0xFF)
            sum += word
            i += 2
        }
        if (i < end) {
            sum += (data[i].toInt() and 0xFF) shl 8
        }
        while ((sum shr 16) != 0L) {
            sum = (sum and 0xFFFF) + (sum shr 16)
        }
        return (sum.inv() and 0xFFFF).toShort()
    }

    private fun tcpChecksum(
        srcAddr: ByteArray,
        dstAddr: ByteArray,
        packet: ByteArray,
        tcpOffset: Int,
        tcpLen: Int
    ): Short {
        val pseudo = ByteBuffer.allocate(12 + tcpLen)
        pseudo.put(srcAddr)
        pseudo.put(dstAddr)
        pseudo.put(0.toByte())
        pseudo.put(6.toByte())
        pseudo.putShort(tcpLen.toShort())
        pseudo.put(packet, tcpOffset, tcpLen)
        return checksum(pseudo.array(), 0, pseudo.capacity())
    }
}
