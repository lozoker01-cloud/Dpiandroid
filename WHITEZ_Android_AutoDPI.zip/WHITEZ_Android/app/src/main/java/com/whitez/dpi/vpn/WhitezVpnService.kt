package com.whitez.dpi.vpn

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Intent
import android.net.VpnService
import android.os.Build
import android.os.ParcelFileDescriptor
import androidx.core.app.NotificationCompat
import com.whitez.dpi.engine.AutoSelector
import com.whitez.dpi.engine.DpiPacketModifier
import com.whitez.dpi.engine.DpiStrategy
import com.whitez.dpi.engine.StrategyCatalog
import com.whitez.dpi.ui.MainActivity
import kotlinx.coroutines.*
import java.io.FileInputStream
import java.io.FileOutputStream
import java.net.InetAddress
import java.net.InetSocketAddress
import java.net.Socket
import java.nio.ByteBuffer
import java.util.concurrent.ConcurrentHashMap

class WhitezVpnService : VpnService() {

    companion object {
        const val ACTION_START = "com.whitez.dpi.START"
        const val ACTION_STOP = "com.whitez.dpi.STOP"
        const val BROADCAST_STATUS = "com.whitez.dpi.STATUS"
        const val EXTRA_STATE = "state"
        const val EXTRA_MESSAGE = "message"

        const val STATE_IDLE = "IDLE"
        const val STATE_SEARCHING = "SEARCHING"
        const val STATE_CONNECTED = "CONNECTED"

        @Volatile
        var currentState: String = STATE_IDLE

        @Volatile
        var activeStrategyName: String = ""
    }

    private var vpnInterface: ParcelFileDescriptor? = null
    private val serviceScope = CoroutineScope(SupervisorJob() + Dispatchers.IO)
    private var activeStrategy: DpiStrategy = StrategyCatalog.STRATEGIES.first()
    private val tcpSessions = ConcurrentHashMap<String, TcpSession>()

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        when (intent?.action) {
            ACTION_STOP -> {
                stopVpn()
                return START_NOT_STICKY
            }
            ACTION_START, null -> {
                startForeground(101, buildNotification("Подключение и подбор..."))
                serviceScope.launch {
                    startAutoFlow()
                }
            }
        }
        return START_STICKY
    }

    private suspend fun startAutoFlow() {
        updateStatus(STATE_SEARCHING, "Автонастройка под вашу сеть...")

        // 1. Автоматически ищем рабочую стратегию без участия пользователя
        val best = AutoSelector.findBestStrategy(this) { stepMsg ->
            updateStatus(STATE_SEARCHING, stepMsg)
        }
        activeStrategy = best.strategy
        activeStrategyName = best.strategy.name

        // 2. Поднимаем локальный TUN с корректным DNS и исключением самого приложения
        establishTun()

        updateStatus(
            STATE_CONNECTED,
            "Защита активна (${best.strategy.name})"
        )
        updateNotification("Активно: ${best.strategy.name}")

        // 3. Запускаем обработку IP-пакетов из TUN
        runPacketLoop()
    }

    private fun establishTun() {
        vpnInterface?.close()
        val builder = Builder()
            .setSession("WHITEZ Auto DPI")
            .setMtu(1500)
            .addAddress("10.111.222.1", 30)
            .addRoute("0.0.0.0", 0)
            // Явные быстрые DNS, чтобы не было зависаний из-за Private DNS провайдера
            .addDnsServer("1.1.1.1")
            .addDnsServer("8.8.8.8")

        // Исключаем само приложение WHITEZ из туннеля — защита от бесконечной петли и таймаутов
        try {
            builder.addDisallowedApplication(packageName)
        } catch (_: Exception) {
        }

        vpnInterface = builder.establish()
    }

    private suspend fun runPacketLoop() = withContext(Dispatchers.IO) {
        val fd = vpnInterface?.fileDescriptor ?: return@withContext
        val input = FileInputStream(fd)
        val output = FileOutputStream(fd)
        val buffer = ByteArray(32767)

        while (isActive && vpnInterface != null) {
            val length = try {
                input.read(buffer)
            } catch (_: Exception) {
                break
            }
            if (length <= 0) continue

            val packet = buffer.copyOf(length)
            handleIpPacket(packet, output)
        }
    }

    private fun handleIpPacket(packet: ByteArray, tunOut: FileOutputStream) {
        if (packet.size < 20) return
        val version = (packet[0].toInt() shr 4) and 0x0F
        if (version != 4) return

        val ihl = (packet[0].toInt() and 0x0F) * 4
        val protocol = packet[9].toInt() and 0xFF
        val srcIp = InetAddress.getByAddress(packet.copyOfRange(12, 16))
        val dstIp = InetAddress.getByAddress(packet.copyOfRange(16, 20))

        // Протокол 17 = UDP
        if (protocol == 17 && packet.size >= ihl + 8) {
            val dstPort = ((packet[ihl + 2].toInt() and 0xFF) shl 8) or (packet[ihl + 3].toInt() and 0xFF)
            // Блокируем QUIC (UDP 443), чтобы браузеры и YouTube мгновенно перешли на TCP+TLS,
            // где работает фрагментация SNI
            if (dstPort == 443 && activeStrategy.blockQuic) {
                return
            }
            // Остальной UDP (включая DNS порт 53) пробрасываем через защищённый сокет
            forwardUdpPacket(packet, ihl, srcIp, dstIp, tunOut)
        }
        // Протокол 6 = TCP
        else if (protocol == 6 && packet.size >= ihl + 20) {
            forwardTcpPacket(packet, ihl, srcIp, dstIp, tunOut)
        }
    }

    private fun forwardUdpPacket(
        packet: ByteArray,
        ihl: Int,
        srcIp: InetAddress,
        dstIp: InetAddress,
        tunOut: FileOutputStream
    ) {
        val srcPort = ((packet[ihl].toInt() and 0xFF) shl 8) or (packet[ihl + 1].toInt() and 0xFF)
        val dstPort = ((packet[ihl + 2].toInt() and 0xFF) shl 8) or (packet[ihl + 3].toInt() and 0xFF)
        val payloadOffset = ihl + 8
        if (payloadOffset >= packet.size) return
        val payload = packet.copyOfRange(payloadOffset, packet.size)

        serviceScope.launch {
            val datagramSocket = java.net.DatagramSocket()
            try {
                protect(datagramSocket)
                datagramSocket.soTimeout = 3000
                val outPkt = java.net.DatagramPacket(payload, payload.size, dstIp, dstPort)
                datagramSocket.send(outPkt)

                val respBuf = ByteArray(4096)
                val inPkt = java.net.DatagramPacket(respBuf, respBuf.size)
                datagramSocket.receive(inPkt)

                val respData = respBuf.copyOf(inPkt.length)
                val ipResponse = PacketBuilder.buildUdpIpv4Packet(
                    dstIp, dstPort, srcIp, srcPort, respData
                )
                synchronized(tunOut) {
                    tunOut.write(ipResponse)
                }
            } catch (_: Exception) {
            } finally {
                datagramSocket.close()
            }
        }
    }

    private fun forwardTcpPacket(
        packet: ByteArray,
        ihl: Int,
        srcIp: InetAddress,
        dstIp: InetAddress,
        tunOut: FileOutputStream
    ) {
        val srcPort = ((packet[ihl].toInt() and 0xFF) shl 8) or (packet[ihl + 1].toInt() and 0xFF)
        val dstPort = ((packet[ihl + 2].toInt() and 0xFF) shl 8) or (packet[ihl + 3].toInt() and 0xFF)
        val seqNum = ByteBuffer.wrap(packet, ihl + 4, 4).int.toLong() and 0xFFFFFFFFL
        val tcpHeaderLen = ((packet[ihl + 12].toInt() shr 4) and 0x0F) * 4
        val flags = packet[ihl + 13].toInt() and 0xFF

        val syn = (flags and 0x02) != 0
        val fin = (flags and 0x01) != 0
        val rst = (flags and 0x04) != 0

        val key = "${srcIp.hostAddress}:$srcPort->${dstIp.hostAddress}:$dstPort"

        if (rst || fin) {
            tcpSessions.remove(key)?.close()
            return
        }

        if (syn) {
            tcpSessions.remove(key)?.close()
            val session = TcpSession(
                vpnService = this,
                srcIp = srcIp,
                srcPort = srcPort,
                dstIp = dstIp,
                dstPort = dstPort,
                initialClientSeq = seqNum,
                strategy = activeStrategy,
                tunOut = tunOut,
                onClosed = { tcpSessions.remove(key) }
            )
            tcpSessions[key] = session
            session.start()
            return
        }

        val payloadOffset = ihl + tcpHeaderLen
        if (payloadOffset < packet.size) {
            val payload = packet.copyOfRange(payloadOffset, packet.size)
            tcpSessions[key]?.sendToRemote(payload, seqNum)
        }
    }

    private fun stopVpn() {
        tcpSessions.values.forEach { it.close() }
        tcpSessions.clear()
        try {
            vpnInterface?.close()
        } catch (_: Exception) {
        }
        vpnInterface = null
        updateStatus(STATE_IDLE, "Нажмите, чтобы включить")
        stopForeground(STOP_FOREGROUND_REMOVE)
        stopSelf()
    }

    private fun updateStatus(state: String, message: String) {
        currentState = state
        val intent = Intent(BROADCAST_STATUS).apply {
            setPackage(packageName)
            putExtra(EXTRA_STATE, state)
            putExtra(EXTRA_MESSAGE, message)
        }
        sendBroadcast(intent)
    }

    private fun buildNotification(text: String): Notification {
        val channelId = "whitez_dpi_channel"
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(
                channelId,
                "WHITEZ DPI Protection",
                NotificationManager.IMPORTANCE_LOW
            )
            getSystemService(NotificationManager::class.java)?.createNotificationChannel(channel)
        }
        val openIntent = PendingIntent.getActivity(
            this, 0,
            Intent(this, MainActivity::class.java),
            PendingIntent.FLAG_IMMUTABLE
        )
        return NotificationCompat.Builder(this, channelId)
            .setContentTitle("WHITEZ")
            .setContentText(text)
            .setSmallIcon(android.R.drawable.ic_lock_lock)
            .setContentIntent(openIntent)
            .setOngoing(true)
            .build()
    }

    private fun updateNotification(text: String) {
        val nm = getSystemService(NotificationManager::class.java)
        nm?.notify(101, buildNotification(text))
    }

    override fun onDestroy() {
        stopVpn()
        serviceScope.cancel()
        super.onDestroy()
    }
}

class TcpSession(
    private val vpnService: VpnService,
    private val srcIp: InetAddress,
    private val srcPort: Int,
    private val dstIp: InetAddress,
    private val dstPort: Int,
    initialClientSeq: Long,
    private val strategy: DpiStrategy,
    private val tunOut: FileOutputStream,
    private val onClosed: () -> Unit
) {
    private val socket = Socket()
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.IO)
    private var serverSeq = 1000L
    private var clientNextSeq = (initialClientSeq + 1) and 0xFFFFFFFFL
    private var firstPayloadSent = false

    fun start() {
        scope.launch {
            try {
                vpnService.protect(socket)
                socket.tcpNoDelay = true
                socket.connect(InetSocketAddress(dstIp, dstPort), 4000)

                // Отправляем SYN-ACK обратно в TUN
                val synAck = PacketBuilder.buildTcpIpv4Packet(
                    dstIp, dstPort, srcIp, srcPort,
                    seq = serverSeq,
                    ack = clientNextSeq,
                    flags = 0x12, // SYN + ACK
                    payload = ByteArray(0)
                )
                serverSeq = (serverSeq + 1) and 0xFFFFFFFFL
                synchronized(tunOut) { tunOut.write(synAck) }

                // Читаем ответ сервера и пишем в TUN
                val inStream = socket.getInputStream()
                val buf = ByteArray(1400)
                while (isActive) {
                    val read = inStream.read(buf)
                    if (read <= 0) break
                    val chunk = buf.copyOf(read)
                    val dataPkt = PacketBuilder.buildTcpIpv4Packet(
                        dstIp, dstPort, srcIp, srcPort,
                        seq = serverSeq,
                        ack = clientNextSeq,
                        flags = 0x18, // PSH + ACK
                        payload = chunk
                    )
                    serverSeq = (serverSeq + read) and 0xFFFFFFFFL
                    synchronized(tunOut) { tunOut.write(dataPkt) }
                }
            } catch (_: Exception) {
            } finally {
                close()
            }
        }
    }

    fun sendToRemote(payload: ByteArray, seq: Long) {
        scope.launch {
            try {
                if (!socket.isConnected) return@launch
                clientNextSeq = (seq + payload.size) and 0xFFFFFFFFL

                // Подтверждаем приём данных от клиента (ACK)
                val ackPkt = PacketBuilder.buildTcpIpv4Packet(
                    dstIp, dstPort, srcIp, srcPort,
                    seq = serverSeq,
                    ack = clientNextSeq,
                    flags = 0x10, // ACK
                    payload = ByteArray(0)
                )
                synchronized(tunOut) { tunOut.write(ackPkt) }

                val out = socket.getOutputStream()
                if (!firstPayloadSent) {
                    firstPayloadSent = true
                    DpiPacketModifier.writeDesyncPayload(socket, out, payload, strategy)
                } else {
                    out.write(payload)
                    out.flush()
                }
            } catch (_: Exception) {
                close()
            }
        }
    }

    fun close() {
        scope.cancel()
        try { socket.close() } catch (_: Exception) {}
        onClosed()
    }
}
