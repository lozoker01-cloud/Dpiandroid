package com.whitez.dpi.engine

import android.net.VpnService
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.net.InetSocketAddress
import java.net.Socket
import javax.net.ssl.SNIHostName
import javax.net.ssl.SSLParameters
import javax.net.ssl.SSLSocket
import javax.net.ssl.SSLSocketFactory

data class StrategyTestResult(
    val strategy: DpiStrategy,
    val success: Boolean,
    val latencyMs: Long,
    val error: String? = null
)

object AutoSelector {

    // Тестовые цели с поддержкой TLS 1.3 и SNI
    private val PROBE_TARGETS = listOf(
        "www.youtube.com" to 443,
        "discord.com" to 443,
        "googlevideo.com" to 443
    )

    /**
     * Проверяет каждую стратегию в защищённом (protected) сокете, минуя петлю VPN.
     * Именно отсутствие protect() или попытка слать Fake-пакеты вызывали SocketTimeoutException.
     */
    suspend fun findBestStrategy(
        vpnService: VpnService?,
        onProgress: (String) -> Unit
    ): StrategyTestResult = withContext(Dispatchers.IO) {
        var bestResult: StrategyTestResult? = null

        for (strategy in StrategyCatalog.STRATEGIES) {
            onProgress("Проверка: ${strategy.name}...")
            val result = testSingleStrategy(strategy, vpnService)
            if (result.success) {
                if (bestResult == null || result.latencyMs < bestResult.latencyMs) {
                    bestResult = result
                }
                // Если нашли быструю рабочую стратегию (< 450 мс) — сразу выбираем её для пользователя
                if (result.latencyMs < 450L) {
                    return@withContext result
                }
            }
        }

        return@withContext bestResult ?: StrategyTestResult(
            strategy = StrategyCatalog.STRATEGIES.first(),
            success = true,
            latencyMs = 0L,
            error = "Fallback to default"
        )
    }

    private fun testSingleStrategy(
        strategy: DpiStrategy,
        vpnService: VpnService?
    ): StrategyTestResult {
        val start = System.currentTimeMillis()
        for ((host, port) in PROBE_TARGETS) {
            val rawSocket = Socket()
            try {
                // КРИТИЧНО ДЛЯ ANDROID: сокет пробы не должен попадать обратно в TUN-интерфейс
                vpnService?.protect(rawSocket)
                rawSocket.tcpNoDelay = true
                rawSocket.connect(InetSocketAddress(host, port), 2500)

                val factory = SSLSocketFactory.getDefault() as SSLSocketFactory
                val sslSocket = factory.createSocket(rawSocket, host, port, true) as SSLSocket
                val params = SSLParameters()
                params.serverNames = listOf(SNIHostName(host))
                sslSocket.sslParameters = params
                sslSocket.soTimeout = 2500

                // Применяем фрагментацию TLS handshake на уровне сокета
                DpiPacketModifier.performProtectedHandshake(sslSocket, rawSocket, strategy)

                val elapsed = System.currentTimeMillis() - start
                sslSocket.close()
                return StrategyTestResult(strategy, true, elapsed)
            } catch (e: Exception) {
                try { rawSocket.close() } catch (_: Exception) {}
            }
        }
        return StrategyTestResult(strategy, false, Long.MAX_VALUE, "Timeout")
    }
}
