package com.whitez.dpi.ui

import android.app.Activity
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.net.VpnService
import android.os.Build
import android.os.Bundle
import android.view.View
import android.widget.ProgressBar
import android.widget.TextView
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import com.google.android.material.button.MaterialButton
import com.whitez.dpi.R
import com.whitez.dpi.vpn.WhitezVpnService

class MainActivity : AppCompatActivity() {

    private lateinit var btnPower: MaterialButton
    private lateinit var tvStatusTitle: TextView
    private lateinit var tvStatusSubtitle: TextView
    private lateinit var progressSearching: ProgressBar

    private val vpnPermissionLauncher = registerForActivityResult(
        ActivityResultContracts.StartActivityForResult()
    ) { result ->
        if (result.resultCode == Activity.RESULT_OK) {
            startVpnService()
        } else {
            tvStatusTitle.text = "Нужно разрешение"
            tvStatusSubtitle.text = "Нажмите кнопку и разрешите VPN-подключение"
        }
    }

    private val statusReceiver = object : BroadcastReceiver() {
        override fun onReceive(context: Context?, intent: Intent?) {
            val state = intent?.getStringExtra(WhitezVpnService.EXTRA_STATE) ?: return
            val message = intent.getStringExtra(WhitezVpnService.EXTRA_MESSAGE) ?: ""
            renderState(state, message)
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        btnPower = findViewById(R.id.btnPower)
        tvStatusTitle = findViewById(R.id.tvStatusTitle)
        tvStatusSubtitle = findViewById(R.id.tvStatusSubtitle)
        progressSearching = findViewById(R.id.progressSearching)

        btnPower.setOnClickListener {
            when (WhitezVpnService.currentState) {
                WhitezVpnService.STATE_IDLE -> requestVpnAndStart()
                else -> stopVpnService()
            }
        }

        renderState(
            WhitezVpnService.currentState,
            if (WhitezVpnService.currentState == WhitezVpnService.STATE_CONNECTED)
                "Активно: ${WhitezVpnService.activeStrategyName}"
            else
                "Никаких настроек — просто нажмите кнопку"
        )
    }

    override fun onStart() {
        super.onStart()
        val filter = IntentFilter(WhitezVpnService.BROADCAST_STATUS)
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            registerReceiver(statusReceiver, filter, RECEIVER_NOT_EXPORTED)
        } else {
            registerReceiver(statusReceiver, filter)
        }
    }

    override fun onStop() {
        super.onStop()
        unregisterReceiver(statusReceiver)
    }

    private fun requestVpnAndStart() {
        val prepareIntent = VpnService.prepare(this)
        if (prepareIntent != null) {
            vpnPermissionLauncher.launch(prepareIntent)
        } else {
            startVpnService()
        }
    }

    private fun startVpnService() {
        val intent = Intent(this, WhitezVpnService::class.java).apply {
            action = WhitezVpnService.ACTION_START
        }
        ContextCompat.startForegroundService(this, intent)
    }

    private fun stopVpnService() {
        val intent = Intent(this, WhitezVpnService::class.java).apply {
            action = WhitezVpnService.ACTION_STOP
        }
        startService(intent)
    }

    private fun renderState(state: String, message: String) {
        when (state) {
            WhitezVpnService.STATE_IDLE -> {
                progressSearching.visibility = View.GONE
                btnPower.text = "ВКЛЮЧИТЬ"
                btnPower.setBackgroundColor(0xFF1F242D.toInt())
                tvStatusTitle.text = "Отключено"
                tvStatusSubtitle.text = message
            }
            WhitezVpnService.STATE_SEARCHING -> {
                progressSearching.visibility = View.VISIBLE
                btnPower.text = "ОТМЕНА"
                btnPower.setBackgroundColor(0xFF2B3240.toInt())
                tvStatusTitle.text = "Настраиваем..."
                tvStatusSubtitle.text = message
            }
            WhitezVpnService.STATE_CONNECTED -> {
                progressSearching.visibility = View.GONE
                btnPower.text = "ВЫКЛЮЧИТЬ"
                btnPower.setBackgroundColor(0xFF1E8E5A.toInt())
                tvStatusTitle.text = "Работает"
                tvStatusSubtitle.text = message
            }
        }
    }
}
