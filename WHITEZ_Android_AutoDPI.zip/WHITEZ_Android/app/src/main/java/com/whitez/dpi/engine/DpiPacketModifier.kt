package com.whitez.dpi.engine

import java.io.OutputStream
import java.net.Socket
import javax.net.ssl.SSLSocket

object DpiPacketModifier {

    /**
     * Записывает первый TLS ClientHello с учётом выбранной стратегии обхода DPI.
     * Работает через стандартный TCP без необходимости root-прав и сырых IP-заголовков.
     */
    fun writeDesyncPayload(
        socket: Socket,
        out: OutputStream,
        payload: ByteArray,
        strategy: DpiStrategy
    ) {
        // Проверяем, является ли пакет TLS Handshake (0x16 0x03)
        val isTlsClientHello = payload.size > 10 &&
                payload[0] == 0x16.toByte() &&
                payload[1] == 0x03.toByte()

        if (!isTlsClientHello) {
            out.write(payload)
            out.flush()
            return
        }

        socket.tcpNoDelay = true

        when (strategy.method) {
            DesyncMethod.SPLIT -> {
                val splitIdx = strategy.splitOffset.coerceIn(1, payload.size - 1)
                out.write(payload, 0, splitIdx)
                out.flush()
                Thread.sleep(2)
                out.write(payload, splitIdx, payload.size - splitIdx)
                out.flush()
            }

            DesyncMethod.TLSREC_SPLIT -> {
                // Разбиваем 1 TLS Record на 2 валидных TLS Record'а по 5-байтовому заголовку
                val recordLen = ((payload[3].toInt() and 0xFF) shl 8) or (payload[4].toInt() and 0xFF)
                if (payload.size >= 5 + recordLen && recordLen > 4) {
                    val splitPoint = strategy.tlsRecordSplitOffset.coerceIn(1, recordLen - 1)
                    val part1Len = splitPoint
                    val part2Len = recordLen - splitPoint

                    val rec1 = byteArrayOf(
                        payload[0], payload[1], payload[2],
                        ((part1Len shr 8) and 0xFF).toByte(),
                        (part1Len and 0xFF).toByte()
                    ) + payload.copyOfRange(5, 5 + part1Len)

                    val rec2 = byteArrayOf(
                        payload[0], payload[1], payload[2],
                        ((part2Len shr 8) and 0xFF).toByte(),
                        (part2Len and 0xFF).toByte()
                    ) + payload.copyOfRange(5 + part1Len, 5 + recordLen)

                    out.write(rec1)
                    out.flush()
                    Thread.sleep(2)
                    out.write(rec2)
                    out.flush()
                } else {
                    out.write(payload)
                    out.flush()
                }
            }

            DesyncMethod.OOB -> {
                val splitIdx = strategy.splitOffset.coerceIn(1, payload.size - 1)
                out.write(payload, 0, splitIdx)
                out.flush()
                // Отправляем urgent OOB-байт (TCP URG), который сервер игнорирует, а ТСПУ сбивается
                socket.sendUrgentData(strategy.oobByte.toInt())
                Thread.sleep(2)
                out.write(payload, splitIdx, payload.size - splitIdx)
                out.flush()
            }

            DesyncMethod.DISORDER -> {
                // Мелкая побайтовая сегментация первых 16 байт заголовка ClientHello
                val headLimit = minOf(16, payload.size)
                for (i in 0 until headLimit) {
                    out.write(payload, i, 1)
                    out.flush()
                }
                if (headLimit < payload.size) {
                    out.write(payload, headLimit, payload.size - headLimit)
                    out.flush()
                }
            }
        }
    }

    fun performProtectedHandshake(
        sslSocket: SSLSocket,
        rawSocket: Socket,
        strategy: DpiStrategy
    ) {
        rawSocket.tcpNoDelay = true
        sslSocket.startHandshake()
    }
}
