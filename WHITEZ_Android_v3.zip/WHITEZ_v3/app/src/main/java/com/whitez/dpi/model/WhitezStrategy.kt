package com.whitez.dpi.model

enum class DesyncMode {
    TLS_RECORD_SPLIT,       // Разрез TLS ClientHello на 2 TLS-записи + TCP split на позиции 1 и середине SNI
    SNI_MID_SPLIT,          // Разрыв ровно посередине SNI-домена (аналог split2 / midsld)
    DISORDER_SPLIT,         // Нарезка со смещением 2 байта + разрез SNI (аналог disorder / badseq)
    MULTI_CHUNK_AGGRESSIVE, // Многосегментная нарезка для жёстких ТСПУ и мобильных сетей (4G/5G)
    QUIC_DROP_ONLY          // Только блокировка QUIC (UDP:443), трафик идёт напрямую без лишних пауз
}

data class WhitezStrategy(
    val id: String,
    val name: String,
    val badge: String,
    val zapretPcEquivalent: String,
    val description: String,
    val mode: DesyncMode,
    val args: List<String>,
    val blockQuic: Boolean = true,
    val recommendedFor: String
)

object StrategyRepository {

    val strategies: List<WhitezStrategy> = listOf(
        WhitezStrategy(
            id = "zapret_general_split",
            name = "Zapret General (TLS Split + SNI)",
            badge = "Рекомендуемая",
            zapretPcEquivalent = "general.bat (--dpi-desync=multisplit --dpi-desync-split-pos=1,sniext+1)",
            description = "Разбивает TLS ClientHello на фрагменты на уровне TLS-записей и TCP, обходя анализ SNI на ТСПУ.",
            mode = DesyncMode.TLS_RECORD_SPLIT,
            args = listOf("-r", "1+s", "-s", "1", "-q", "1"),
            blockQuic = true,
            recommendedFor = "Большинство домашних провайдеров и Wi-Fi"
        ),
        WhitezStrategy(
            id = "zapret_alt1_sni_mid",
            name = "Zapret ALT 1 (Разрыв середины SNI)",
            badge = "Низкий пинг",
            zapretPcEquivalent = "general (ALT2).bat (--dpi-desync=split2 --dpi-desync-split-pos=midsld)",
            description = "Разделяет пакет ровно посередине доменного имени (SNI) с минимальной задержкой.",
            mode = DesyncMode.SNI_MID_SPLIT,
            args = listOf("-s", "0+s", "-q", "1"),
            blockQuic = true,
            recommendedFor = "Быстрый отклик и загрузка превью/видео"
        ),
        WhitezStrategy(
            id = "zapret_alt2_disorder",
            name = "Zapret ALT 2 (Disorder + Offset 2)",
            badge = "Анти-сброс",
            zapretPcEquivalent = "general (ALT4).bat (--dpi-desync=disorder --dpi-desync-split-pos=2)",
            description = "Фрагментация со смещением на 2 байта и разрывом SNI. Помогает при обрывах TCP-соединений.",
            mode = DesyncMode.DISORDER_SPLIT,
            args = listOf("-d", "1", "-s", "2", "-q", "1"),
            blockQuic = true,
            recommendedFor = "Сети с обрывами или сбросом соединения"
        ),
        WhitezStrategy(
            id = "zapret_alt3_mobile",
            name = "Zapret ALT 3 (Мобильный 4G/5G / ТСПУ)",
            badge = "Мобильная сеть",
            zapretPcEquivalent = "general (ALT3).bat (--dpi-desync=fake,disorder2 --dpi-desync-ttl=5)",
            description = "Многоступенчатая нарезка ClientHello для мобильных операторов (МТС, МегаФон, Билайн, Т2).",
            mode = DesyncMode.MULTI_CHUNK_AGGRESSIVE,
            args = listOf("-s", "1", "-s", "6", "-s", "0+s", "-q", "1"),
            blockQuic = true,
            recommendedFor = "Мобильный интернет и сложные ТСПУ"
        ),
        WhitezStrategy(
            id = "zapret_quic_only",
            name = "Только блокировка QUIC (UDP 443)",
            badge = "Минимальный пинг",
            zapretPcEquivalent = "quic_block_only (--wf-udp=443)",
            description = "Блокирует QUIC (UDP 443), переводя YouTube и браузер на TCP без модификации TLS-сегментов.",
            mode = DesyncMode.QUIC_DROP_ONLY,
            args = emptyList(),
            blockQuic = true,
            recommendedFor = "Когда достаточно отключить HTTP/3 (QUIC)"
        )
    )

    val targetDomains: List<String> = listOf(
        "youtube.com",
        "www.youtube.com",
        "m.youtube.com",
        "youtu.be",
        "googlevideo.com",
        "ytimg.com",
        "ggpht.com",
        "youtubei.googleapis.com",
        "discord.com",
        "gateway.discord.gg",
        "cdn.discordapp.com",
        "media.discordapp.net",
        "rutracker.org",
        "ntc.party"
    )
}
