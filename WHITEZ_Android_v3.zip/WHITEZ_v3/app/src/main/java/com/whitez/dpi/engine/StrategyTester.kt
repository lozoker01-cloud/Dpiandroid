package com.whitez.dpi.engine

import android.content.Context
import android.net.VpnService
import com.whitez.dpi.model.StrategyRepository
import com.whitez.dpi.model.WhitezStrategy
import kotlinx.coroutines.*
import okhttp3.ConnectionPool
import okhttp3.OkHttpClient
import okhttp3.Request
import java.net.InetSocketAddress
import java.net.Proxy
import java.util.concurrent.TimeUnit

data class StrategyTestResult(
    val strategy: WhitezStrategy,
    val isSuccess: Boolean,
    val latencyMs: Long,
    val details: String
)

class StrategyTester(
    private val context: Context,
    private val vpnService: VpnService? = null
) {

    private val testUrls = listOf(
        "https://www.youtube.com/generate_204",
        "https://rr1---sn-4g5e6nze.googlevideo.com/generate_204"
    )

    suspend fun testAllStrategies(
        onProgress: (index: Int, total: Int, current: WhitezStrategy) -> Unit,
        onResult: (StrategyTestResult) -> Unit
    ): List<StrategyTestResult> = withContext(Dispatchers.IO) {
        val results = mutableListOf<StrategyTestResult>()
        val all = StrategyRepository.strategies

        val sharedClient = OkHttpClient.Builder()
            .proxy(Proxy(Proxy.Type.SOCKS, InetSocketAddress("127.0.0.1", NativeDpiEngine.TEST_SOCKS_PORT)))
            .connectionPool(ConnectionPool(0, 1, TimeUnit.MILLISECONDS))
            .connectTimeout(2500, TimeUnit.MILLISECONDS)
            .readTimeout(2500, TimeUnit.MILLISECONDS)
            .retryOnConnectionFailure(false)
            .build()

        for ((index, strategy) in all.withIndex()) {
            if (!isActive) break
            withContext(Dispatchers.Main) {
                onProgress(index + 1, all.size, strategy)
            }
            val result = try {
                testSingleStrategy(strategy, sharedClient)
            } catch (e: CancellationException) {
                throw e
            } catch (e: Exception) {
                StrategyTestResult(
                    strategy = strategy,
                    isSuccess = false,
                    latencyMs = -1L,
                    details = "Ошибка теста: ${e.javaClass.simpleName}"
                )
            }
            results.add(result)
            withContext(Dispatchers.Main) {
                onResult(result)
            }
        }
        results
    }

    private suspend fun testSingleStrategy(
        strategy: WhitezStrategy,
        client: OkHttpClient
    ): StrategyTestResult = withContext(Dispatchers.IO) {
        val testPort = NativeDpiEngine.TEST_SOCKS_PORT
        val nativeEngine = NativeDpiEngine(context)
        var kotlinProxy: PureKotlinDpiProxy? = null

        try {
            val startedNative = try {
                nativeEngine.startDpiProxy(strategy, port = testPort)
            } catch (_: Exception) {
                false
            }

            if (!startedNative) {
                kotlinProxy = PureKotlinDpiProxy(
                    vpnService = vpnService,
                    port = testPort,
                    strategy = strategy,
                    targetDomains = emptySet()
                )
                kotlinProxy.start(this)
            }

            delay(30)

            var successCount = 0
            var minPingMs = Long.MAX_VALUE
            var lastCode = 0

            for (url in testUrls) {
                try {
                    val req = Request.Builder()
                        .url(url)
                        .header("User-Agent", "Mozilla/5.0 (Linux; Android 14)")
                        .build()
                    val reqStart = System.nanoTime()
                    client.newCall(req).execute().use { resp ->
                        val reqMs = maxOf(1L, (System.nanoTime() - reqStart) / 1_000_000)
                        lastCode = resp.code
                        if (resp.code in 200..399) {
                            successCount++
                            if (reqMs < minPingMs) minPingMs = reqMs
                        }
                    }
                } catch (_: Exception) {
                }
            }

            val bestPing = if (successCount > 0 && minPingMs != Long.MAX_VALUE) minPingMs else -1L
            val isOk = successCount == testUrls.size

            StrategyTestResult(
                strategy = strategy,
                isSuccess = isOk,
                latencyMs = bestPing,
                details = when {
                    isOk -> "Доступен • пинг ${bestPing} мс"
                    successCount > 0 -> "Частично ($successCount/${testUrls.size}) • ${bestPing} мс"
                    else -> "Недоступен (код $lastCode)"
                }
            )
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            StrategyTestResult(
                strategy = strategy,
                isSuccess = false,
                latencyMs = -1L,
                details = "Ошибка: ${e.localizedMessage ?: e.javaClass.simpleName}"
            )
        } finally {
            try { kotlinProxy?.stop() } catch (_: Exception) {}
            try { nativeEngine.stopDpiProxy() } catch (_: Exception) {}
        }
    }
}
