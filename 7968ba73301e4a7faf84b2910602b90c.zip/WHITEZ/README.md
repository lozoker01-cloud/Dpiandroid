# WHITEZ 3.4
Обход (ciadpi/ByeDPI): 21 стратегия, тест, фильтр приложений, журнал движка, авто-перезапуск движка. VPN (VLESS/Xray) без изменений.
Сборка: scripts/build_ciadpi.sh, затем gradle assembleDebug. Workflow: docs/workflow-for-zip-repo.yml.
