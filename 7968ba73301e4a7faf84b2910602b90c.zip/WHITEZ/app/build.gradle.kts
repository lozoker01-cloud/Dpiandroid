import java.net.URL

plugins { id("com.android.application"); id("org.jetbrains.kotlin.android") }
android {
    namespace = "app.whitez"
    compileSdk = 34
    defaultConfig {
        applicationId = "app.whitez"
        minSdk = 29; targetSdk = 34
        versionCode = 5; versionName = "3.4"
    }
    buildTypes { release { isMinifyEnabled = false; signingConfig = signingConfigs.getByName("debug") } }
    compileOptions { sourceCompatibility = JavaVersion.VERSION_17; targetCompatibility = JavaVersion.VERSION_17 }
    kotlinOptions { jvmTarget = "17" }
    buildFeatures { compose = true }
    composeOptions { kotlinCompilerExtensionVersion = "1.5.14" }
    packaging { jniLibs { useLegacyPackaging = true } }
}
dependencies {
    implementation(fileTree(mapOf("dir" to "libs", "include" to listOf("*.aar"))))
    implementation(platform("androidx.compose:compose-bom:2024.06.00"))
    implementation("androidx.compose.material3:material3")
    implementation("androidx.compose.ui:ui")
    implementation("androidx.activity:activity-compose:1.9.0")
    implementation("androidx.lifecycle:lifecycle-viewmodel-compose:2.8.3")
    implementation("androidx.core:core-ktx:1.13.1")
    implementation("org.jetbrains.kotlinx:kotlinx-coroutines-android:1.8.1")
}

val fetchCores by tasks.registering {
    doLast {
        val libs = file("libs").apply { mkdirs() }
        mapOf(
            "libv2ray.aar" to "https://github.com/2dust/AndroidLibXrayLite/releases/latest/download/libv2ray.aar",
            "hev-socks5-tunnel.aar" to "https://github.com/heiher/hev-socks5-tunnel/releases/latest/download/hev-socks5-tunnel.aar"
        ).forEach { (name, url) ->
            val f = File(libs, name)
            if (!f.exists() || f.length() < 100_000) {
                println("Downloading $name")
                URL(url).openStream().use { i -> f.outputStream().use { o -> i.copyTo(o) } }
            }
        }
    }
}
tasks.named("preBuild") { dependsOn(fetchCores) }
