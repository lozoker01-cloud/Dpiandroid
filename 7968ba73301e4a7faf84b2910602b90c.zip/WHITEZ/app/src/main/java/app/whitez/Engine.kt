package app.whitez
import android.content.Context
import android.os.Build
import kotlinx.coroutines.*
import kotlinx.coroutines.sync.Semaphore
import kotlinx.coroutines.sync.withPermit
import org.json.JSONObject
import java.io.File
import java.net.HttpURLConnection
import java.net.InetAddress
import java.net.InetSocketAddress
import java.net.Proxy
import java.net.Socket
import java.net.URL
import java.util.concurrent.ConcurrentHashMap
import javax.net.ssl.SSLSocket
import javax.net.ssl.SSLSocketFactory

object Engine {
    fun binary(ctx: Context) = File(ctx.applicationInfo.nativeLibraryDir, "libciadpi.so")
    fun available(ctx: Context) = binary(ctx).exists()

    fun diag(ctx: Context): String {
        val dir = File(ctx.applicationInfo.nativeLibraryDir)
        val files = dir.list()?.joinToString(", ") ?: "папка не найдена"
        return "Движок не найден. ABI: ${Build.SUPPORTED_ABIS.joinToString("/")}; в ${dir.name}: $files"
    }

    class Proc(val p: Process, val out: StringBuilder)

    fun spawnProc(ctx: Context, port: Int, args: List<String>, onLine: ((String) -> Unit)? = null): Proc {
        val bin = binary(ctx)
        bin.setExecutable(true, false)
        val cmd = listOf(bin.absolutePath, "-i", "127.0.0.1", "-p", port.toString()) + args
        val p = ProcessBuilder(cmd).redirectErrorStream(true).start()
        val sb = StringBuilder()
        Thread {
            try {
                p.inputStream.bufferedReader().forEachLine { l ->
                    if (sb.length < 400) sb.append(l).append('\n')
                    onLine?.invoke(l)
                }
            } catch (_: Exception) {}
        }.start()
        return Proc(p, sb)
    }

    fun spawn(ctx: Context, port: Int, args: List<String>, onLine: ((String) -> Unit)? = null): Process =
        spawnProc(ctx, port, args, onLine).p

    private val dohCache = ConcurrentHashMap<String, List<String>>()

    fun resolveDoh(host: String): List<String> {
        dohCache[host]?.let { return it }
        val res = try {
            val c = URL("https://1.1.1.1/dns-query?name=$host&type=A").openConnection() as HttpURLConnection
            c.connectTimeout = 3000; c.readTimeout = 3000
            c.setRequestProperty("accept", "application/dns-json")
            val j = JSONObject(c.inputStream.bufferedReader().readText())
            val arr = j.optJSONArray("Answer")
            val l = mutableListOf<String>()
            if (arr != null) for (i in 0 until arr.length()) {
                val a = arr.getJSONObject(i); if (a.optInt("type") == 1) l.add(a.getString("data"))
            }
            l
        } catch (e: Exception) { emptyList() }
        val final = if (res.isNotEmpty()) res else try {
            InetAddress.getAllByName(host).filter { it.address.size == 4 }.map { it.hostAddress ?: "" }
        } catch (e: Exception) { emptyList() }
        if (final.isNotEmpty()) dohCache[host] = final
        return final
    }

    suspend fun dnsReport(): String? = withContext(Dispatchers.IO) {
        val bad = mutableListOf<String>()
        for (h in listOf("www.youtube.com", "discord.com", "www.instagram.com")) {
            val sys = try { InetAddress.getAllByName(h).filter { it.address.size == 4 }.map { it.hostAddress ?: "" } } catch (e: Exception) { emptyList() }
            val doh = resolveDoh(h)
            val fake = sys.any { it.startsWith("0.") || it.startsWith("127.") || it.startsWith("10.") || it.startsWith("192.168.") }
            if (sys.isEmpty() || fake || (doh.isNotEmpty() && sys.intersect(doh.toSet()).isEmpty())) bad.add(h.removePrefix("www."))
        }
        if (bad.isEmpty()) null else "DNS провайдера, возможно, подменяется (${bad.joinToString()}). Включите «Частный DNS»: dns.google"
    }

    private class Probe(val ok: Boolean, val hsMs: Long, val kbps: Long)

    private const val MIN_BYTES = 64 * 1024

    private fun probe(host: String, port: Int, transfer: Boolean): Probe {
        val bad = Probe(false, -1, -1)
        return try {
            val ip = resolveDoh(host).firstOrNull() ?: return bad
            val t = System.nanoTime()
            val proxy = Proxy(Proxy.Type.SOCKS, InetSocketAddress("127.0.0.1", port))
            val raw = Socket(proxy)
            raw.connect(InetSocketAddress(InetAddress.getByAddress(ip.split(".").map { it.toInt().toByte() }.toByteArray()), 443), 3500)
            val ssl = (SSLSocketFactory.getDefault() as SSLSocketFactory).createSocket(raw, host, 443, true) as SSLSocket
            try {
                ssl.soTimeout = 4000
                ssl.startHandshake()
                val hs = (System.nanoTime() - t) / 1_000_000
                val req = "GET / HTTP/1.1\r\nHost: $host\r\nUser-Agent: Mozilla/5.0 (Linux; Android 14) AppleWebKit/537.36 Chrome/124 Mobile Safari/537.36\r\nAccept-Encoding: identity\r\nConnection: close\r\n\r\n"
                ssl.outputStream.write(req.toByteArray()); ssl.outputStream.flush()
                val buf = ByteArray(16 * 1024)
                val need = if (transfer) MIN_BYTES else 1
                var total = 0; var eof = false
                var t1 = 0L
                val deadline = System.nanoTime() + 8_000_000_000L
                while (total < need && System.nanoTime() < deadline) {
                    val n = ssl.inputStream.read(buf)
                    if (n < 0) { eof = true; break }
                    if (total == 0) t1 = System.nanoTime()
                    total += n
                }
                val ok = total >= need || (eof && total > 0)
                val secs = (System.nanoTime() - t1) / 1e9
                val kb = if (transfer && total >= 32 * 1024 && secs > 0.05) (total / 1024.0 / secs).toLong() else -1L
                Probe(ok, hs, kb)
            } finally { try { ssl.close() } catch (_: Exception) {}; try { raw.close() } catch (_: Exception) {} }
        } catch (e: Exception) { bad }
    }

    private val gate = Semaphore(2)

    suspend fun test(ctx: Context, st: Strategy, port: Int): StrategyResult = gate.withPermit {
        withContext(Dispatchers.IO) {
            val pr = try { spawnProc(ctx, port, st.args) } catch (e: Exception) {
                return@withContext StrategyResult(st, error = "нет движка", tested = true)
            }
            val p = pr.p
            try {
                delay(500)
                if (!p.isAlive) {
                    delay(100)
                    val msg = pr.out.toString().trim().lines().firstOrNull { it.isNotBlank() }?.take(34) ?: "код ${p.exitValue()}"
                    return@withContext StrategyResult(st, error = msg, tested = true)
                }
                Services.all.forEach { svc -> svc.urls.forEach { resolveDoh(it) } }
                val res = coroutineScope {
                    Services.all.map { svc ->
                        async { svc to svc.urls.mapIndexed { i, u -> async { probe(u, port, i == 0) } }.awaitAll() }
                    }.awaitAll()
                }
                val passed = res.filter { (_, r) ->
                    r.first().ok && r.count { it.ok } * 2 >= r.size
                }.map { it.first.id }.toSet()
                val hs = res.flatMap { it.second }.filter { it.ok }.map { it.hsMs }
                val sp = res.map { it.second.first() }.filter { it.ok && it.kbps > 0 }.map { it.kbps }
                StrategyResult(st, passed,
                    if (hs.isEmpty()) -1 else hs.average().toLong(),
                    if (sp.isEmpty()) -1 else sp.average().toLong(), null, true)
            } finally { p.destroy() }
        }
    }
}
