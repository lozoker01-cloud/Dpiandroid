package com.whitez.dpi.ui

import android.app.Application
import android.content.Intent
import android.os.Build
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.whitez.dpi.data.AppSettings
import com.whitez.dpi.data.SettingsRepository
import com.whitez.dpi.engine.StrategyTestResult
import com.whitez.dpi.engine.StrategyTester
import com.whitez.dpi.model.StrategyRepository
import com.whitez.dpi.model.WhitezStrategy
import com.whitez.dpi.vpn.VpnState
import com.whitez.dpi.vpn.WhitezVpnService
import kotlinx.coroutines.CoroutineExceptionHandler
import kotlinx.coroutines.Job
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch

data class AutoTestUiState(
    val isRunning: Boolean = false,
    val progressIndex: Int = 0,
    val totalCount: Int = StrategyRepository.strategies.size,
    val currentStrategyName: String = "",
    val results: List<StrategyTestResult> = emptyList(),
    val bestStrategy: StrategyTestResult? = null
)

class MainViewModel(application: Application) : AndroidViewModel(application) {

    private val settingsRepo = SettingsRepository(application)
    private val strategyTester = StrategyTester(application)

    val settings: StateFlow<AppSettings> = settingsRepo.settingsFlow
        .stateIn(viewModelScope, SharingStarted.Eagerly, AppSettings())

    val vpnState: StateFlow<VpnState> = WhitezVpnService.vpnState
    val networkType: StateFlow<String> = WhitezVpnService.networkType

    private val _autoTestState = MutableStateFlow(AutoTestUiState())
    val autoTestState: StateFlow<AutoTestUiState> = _autoTestState

    private var testJob: Job? = null

    private val safeExceptionHandler = CoroutineExceptionHandler { _, _ ->
        _autoTestState.update { it.copy(isRunning = false) }
    }

    fun startVpnService() {
        val ctx = getApplication<Application>()
        val intent = Intent(ctx, WhitezVpnService::class.java).apply {
            action = WhitezVpnService.ACTION_START
        }
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            ctx.startForegroundService(intent)
        } else {
            ctx.startService(intent)
        }
    }

    fun stopVpnService() {
        val ctx = getApplication<Application>()
        val intent = Intent(ctx, WhitezVpnService::class.java).apply {
            action = WhitezVpnService.ACTION_STOP
        }
        ctx.startService(intent)
    }

    fun selectStrategy(strategy: WhitezStrategy) {
        viewModelScope.launch {
            settingsRepo.setSelectedStrategy(strategy.id)
            if (vpnState.value == VpnState.CONNECTED) {
                val ctx = getApplication<Application>()
                val intent = Intent(ctx, WhitezVpnService::class.java).apply {
                    action = WhitezVpnService.ACTION_RESTART
                }
                ctx.startService(intent)
            }
        }
    }

    fun toggleOnlyTargetDomains(enabled: Boolean) {
        viewModelScope.launch { settingsRepo.setOnlyTargetDomains(enabled) }
    }

    fun toggleBlockQuic(enabled: Boolean) {
        viewModelScope.launch { settingsRepo.setBlockQuic(enabled) }
    }

    fun updateCustomDomains(raw: String) {
        viewModelScope.launch { settingsRepo.setCustomDomains(raw) }
    }

    fun startAutoPick() {
        if (_autoTestState.value.isRunning) return
        val wasConnected = vpnState.value == VpnState.CONNECTED
        if (wasConnected) {
            stopVpnService()
        }

        testJob = viewModelScope.launch(safeExceptionHandler) {
            _autoTestState.value = AutoTestUiState(
                isRunning = true,
                totalCount = StrategyRepository.strategies.size
            )

            val allResults = strategyTester.testAllStrategies(
                onProgress = { idx, total, strategy ->
                    _autoTestState.update {
                        it.copy(
                            progressIndex = idx,
                            totalCount = total,
                            currentStrategyName = strategy.name
                        )
                    }
                },
                onResult = { result ->
                    _autoTestState.update {
                        val updated = it.results + result
                        val best = updated.filter { r -> r.isSuccess }
                            .minByOrNull { r -> r.latencyMs }
                        it.copy(results = updated, bestStrategy = best)
                    }
                }
            )

            val winner = allResults.filter { it.isSuccess }.minByOrNull { it.latencyMs }
            if (winner != null) {
                settingsRepo.setSelectedStrategy(winner.strategy.id)
            }

            _autoTestState.update { it.copy(isRunning = false, bestStrategy = winner) }

            if (wasConnected && winner != null) {
                startVpnService()
            }
        }
    }

    fun cancelAutoPick() {
        testJob?.cancel()
        _autoTestState.update { it.copy(isRunning = false) }
    }
}
