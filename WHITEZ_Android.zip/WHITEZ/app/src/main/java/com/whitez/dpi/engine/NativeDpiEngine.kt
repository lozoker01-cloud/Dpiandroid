package com.whitez.dpi.engine

import android.content.Context
import android.util.Log
import com.whitez.dpi.model.WhitezStrategy
import java.io.File

class NativeDpiEngine(private val context: Context) {

    companion object {
        private const val TAG = "NativeDpiEngine"
        const val SOCKS_HOST = "127.0.0.1"
        const val SOCKS_PORT = 1080
        const val TEST_SOCKS_PORT = 1081
    }

    private var dpiProcess: Process? = null

    fun getNativeBinary(libName: String): File {
        val nativeDir = context.applicationInfo.nativeLibraryDir
        return File(nativeDir, libName)
    }

    fun startDpiProxy(
        strategy: WhitezStrategy,
        port: Int = SOCKS_PORT,
        hostsFilePath: String? = null
    ): Boolean {
        stopDpiProxy()
        val binary = getNativeBinary("libciadpi.so")
        if (!binary.exists()) {
            return false
        }

        return try {
            val cmd = mutableListOf(
                binary.absolutePath,
                "-i", SOCKS_HOST,
                "-p", port.toString()
            )
            if (!hostsFilePath.isNullOrBlank()) {
                cmd.addAll(listOf("-H", hostsFilePath))
            }
            cmd.addAll(strategy.args)

            Log.i(TAG, "Запуск нативного DPI ядра: ${cmd.joinToString(" ")}")
            dpiProcess = ProcessBuilder(cmd)
                .redirectErrorStream(true)
                .start()
            true
        } catch (e: Exception) {
            Log.e(TAG, "Ошибка запуска libciadpi.so", e)
            false
        }
    }

    fun stopDpiProxy() {
        try {
            dpiProcess?.destroy()
            dpiProcess = null
        } catch (_: Exception) {
        }
    }
}
