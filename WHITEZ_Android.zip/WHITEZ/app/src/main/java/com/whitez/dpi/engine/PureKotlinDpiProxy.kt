package com.whitez.dpi.engine

import android.net.VpnService
import android.util.Log
import com.whitez.dpi.model.DesyncMode
import com.whitez.dpi.model.WhitezStrategy
import kotlinx.coroutines.*
import java.io.InputStream
import java.io.OutputStream
import java.net.InetSocketAddress
import java.net.ServerSocket
import java.net.Socket

/**
 * Локальный SOCKS5-движок WHITEZ с настоящей фрагментацией на уровне TLS Record Layer
 * и разрывом SNI (Server Name Indication), аналогично zapret / ByeDPI.
 */
class PureKotlinDpiProxy(
    private val vpnService: VpnService?,
    private val port: Int,
    private val strategy: WhitezStrategy,
    private val targetDomains: Set<String>
) {
    companion object {
        private const val TAG = "WhitezDpiProxy"
    }

    private var serverSocket: ServerSocket? = null
    private var job: Job? = null

    fun start(scope: CoroutineScope) {
        stop()
        job = scope.launch(Dispatchers.IO) {
            try {
                serverSocket = ServerSocket().apply {
                    reuseAddress = true
                    bind(InetSocketAddress("127.0.0.1", port))
                }
                Log.i(TAG, "WHITEZ DPI SOCKS5 запущен на порту $port (${strategy.name})")
                while (isActive) {
                    val client = try {
                        serverSocket?.accept()
                    } catch (_: Exception) {
                        null
                    } ?: break
                    launch { handleSocksClient(client) }
                }
            } catch (e: Exception) {
                if (isActive) Log.e(TAG, "Ошибка SOCKS5 сервера", e)
            }
        }
    }

    fun stop() {
        try {
            serverSocket?.close()
        } catch (_: Exception) {
        }
        serverSocket = null
        job?.cancel()
        job = null
    }

    private suspend fun handleSocksClient(client: Socket) = withContext(Dispatchers.IO) {
        var remote: Socket? = null
        try {
            client.tcpNoDelay = true
            val input = client.getInputStream()
            val output = client.getOutputStream()

            // SOCKS5 Handshake
            val ver = input.read()
            if (ver != 5) {
                client.close()
                return@withContext
            }
            val nMethods = input.read()
            if (nMethods > 0) input.readNBytesCompat(nMethods)
            output.write(byteArrayOf(0x05, 0x00))
            output.flush()

            // SOCKS5 Connect Request
            val reqHeader = input.readNBytesCompat(4)
            if (reqHeader.size < 4 || reqHeader[1].toInt() != 0x01) {
                client.close()
                return@withContext
            }

            val host: String
            when (reqHeader[3].toInt()) {
                0x01 -> {
                    val addr = input.readNBytesCompat(4)
                    host = addr.joinToString(".") { (it.toInt() and 0xFF).toString() }
                }
                0x03 -> {
                    val len = input.read()
                    host = String(input.readNBytesCompat(len), Charsets.UTF_8)
                }
                0x04 -> {
                    val addr = input.readNBytesCompat(16)
                    host = addr.toList().chunked(2).joinToString(":") {
                        "%02x%02x".format(it[0], it[1])
                    }
                }
                else -> {
                    client.close()
                    return@withContext
                }
            }

            val portBytes = input.readNBytesCompat(2)
            val destPort = ((portBytes[0].toInt() and 0xFF) shl 8) or (portBytes[1].toInt() and 0xFF)

            remote = Socket().apply {
                tcpNoDelay = true
                vpnService?.protect(this)
                connect(InetSocketAddress(host, destPort), 6000)
            }

            output.write(byteArrayOf(0x05, 0x00, 0x00, 0x01, 0, 0, 0, 0, 0, 0))
            output.flush()

            val remoteIn = remote.getInputStream()
            val remoteOut = remote.getOutputStream()

            val c2r = launch {
                try {
                    relayClientToRemote(input, remoteOut, host, destPort)
                } catch (_: Exception) {
                }
            }
            val r2c = launch {
                try {
                    relayStream(remoteIn, output)
                } catch (_: Exception) {
                }
            }
            joinAll(c2r, r2c)
        } catch (_: Exception) {
        } finally {
            try { client.close() } catch (_: Exception) {}
            try { remote?.close() } catch (_: Exception) {}
        }
    }

    private fun relayClientToRemote(
        input: InputStream,
        output: OutputStream,
        host: String,
        port: Int
    ) {
        val buffer = ByteArray(16384)
        var isFirstPacket = true
        while (true) {
            val read = input.read(buffer)
            if (read <= 0) break

            if (isFirstPacket && port == 443 && read > 12 && buffer[0] == 0x16.toByte()) {
                isFirstPacket = false
                val sniInfo = findSniOffset(buffer, read)
                val sniHost = sniInfo?.first ?: host

                val shouldApplyDpi = targetDomains.isEmpty() ||
                        targetDomains.any { sniHost.endsWith(it, ignoreCase = true) }

                if (shouldApplyDpi && strategy.mode != DesyncMode.QUIC_DROP_ONLY) {
                    applyDpiBypass(output, buffer, read, sniInfo)
                    continue
                }
            }
            isFirstPacket = false
            output.write(buffer, 0, read)
            output.flush()
        }
    }

    /**
     * Применяет выбранную стратегию обхода DPI к TLS ClientHello:
     * - Нарезка на уровне TLS Record Layer (разбивает 1 TLS-запись на 2 валидных TLS-рекорда)
     * - Разрыв ровно посередине SNI-домена
     * - Многосегментная TCP-фрагментация с TCP_NODELAY
     */
    private fun applyDpiBypass(
        output: OutputStream,
        data: ByteArray,
        length: Int,
        sniInfo: Triple<String, Int, Int>?
    ) {
        val tlsRecordPayloadLen = ((data[3].toInt() and 0xFF) shl 8) or (data[4].toInt() and 0xFF)
        val isSingleTlsRecord = (tlsRecordPayloadLen + 5 == length)

        // Точка разреза строго посередине SNI, если SNI найден в пакете
        val midSniPos = if (sniInfo != null) {
            sniInfo.second + (sniInfo.third / 2)
        } else {
            minOf(length / 2, 42)
        }

        when (strategy.mode) {
            DesyncMode.TLS_RECORD_SPLIT, DesyncMode.FAKE_SNI_SPLIT -> {
                if (isSingleTlsRecord && midSniPos > 10 && midSniPos < length - 5) {
                    // Разбиваем 1 TLS Handshake Record на 2 отдельных TLS Record прямо посередине SNI!
                    // ТСПУ видит два неполных фрагмента и не может собрать SNI, а сервер склеивает их штатно.
                    val verMajor = data[1]
                    val verMinor = data[2]
                    val part1PayloadLen = midSniPos - 5
                    val part2PayloadLen = length - midSniPos

                    val rec1 = ByteArray(5 + part1PayloadLen)
                    rec1[0] = 0x16
                    rec1[1] = verMajor
                    rec1[2] = verMinor
                    rec1[3] = ((part1PayloadLen shr 8) and 0xFF).toByte()
                    rec1[4] = (part1PayloadLen and 0xFF).toByte()
                    System.arraycopy(data, 5, rec1, 5, part1PayloadLen)

                    val rec2 = ByteArray(5 + part2PayloadLen)
                    rec2[0] = 0x16
                    rec2[1] = verMajor
                    rec2[2] = verMinor
                    rec2[3] = ((part2PayloadLen shr 8) and 0xFF).toByte()
                    rec2[4] = (part2PayloadLen and 0xFF).toByte()
                    System.arraycopy(data, midSniPos, rec2, 5, part2PayloadLen)

                    // Отправляем первый рекорд двумя TCP-сегментами (1 байт + остаток)
                    output.write(rec1, 0, 1)
                    output.flush()
                    Thread.sleep(2)
                    output.write(rec1, 1, rec1.size - 1)
                    output.flush()
                    Thread.sleep(2)
                    output.write(rec2)
                    output.flush()
                } else {
                    sendSplitTcp(output, data, length, intArrayOf(1, midSniPos))
                }
            }

            DesyncMode.SNI_MID_SPLIT -> {
                sendSplitTcp(output, data, length, intArrayOf(midSniPos))
            }

            DesyncMode.DISORDER_SPLIT -> {
                sendSplitTcp(output, data, length, intArrayOf(2, midSniPos))
            }

            DesyncMode.MULTI_CHUNK_AGGRESSIVE -> {
                val p1 = 1
                val p2 = 6
                val p3 = midSniPos
                sendSplitTcp(output, data, length, intArrayOf(p1, p2, p3))
            }

            DesyncMode.QUIC_DROP_ONLY -> {
                output.write(data, 0, length)
                output.flush()
            }
        }
    }

    private fun sendSplitTcp(output: OutputStream, data: ByteArray, length: Int, splitPoints: IntArray) {
        var prev = 0
        for (pt in splitPoints.sorted()) {
            if (pt in (prev + 1) until length) {
                output.write(data, prev, pt - prev)
                output.flush()
                Thread.sleep(2)
                prev = pt
            }
        }
        if (prev < length) {
            output.write(data, prev, length - prev)
            output.flush()
        }
    }

    /**
     * Парсит бинарный TLS ClientHello и находит точное смещение и длину SNI (extension 0x0000).
     * Возвращает Triple(domainName, startOffsetInPacket, domainLength).
     */
    private fun findSniOffset(data: ByteArray, len: Int): Triple<String, Int, Int>? {
        try {
            if (len < 44 || data[0] != 0x16.toByte() || data[5] != 0x01.toByte()) return null
            var pos = 43 // После Random (32 байта) + SessionID length
            val sessionIdLen = data[pos].toInt() and 0xFF
            pos += 1 + sessionIdLen
            if (pos + 2 > len) return null

            val cipherSuitesLen = ((data[pos].toInt() and 0xFF) shl 8) or (data[pos + 1].toInt() and 0xFF)
            pos += 2 + cipherSuitesLen
            if (pos + 1 > len) return null

            val compMethodsLen = data[pos].toInt() and 0xFF
            pos += 1 + compMethodsLen
            if (pos + 2 > len) return null

            val extensionsLen = ((data[pos].toInt() and 0xFF) shl 8) or (data[pos + 1].toInt() and 0xFF)
            pos += 2
            val endExt = minOf(len, pos + extensionsLen)

            while (pos + 4 <= endExt) {
                val extType = ((data[pos].toInt() and 0xFF) shl 8) or (data[pos + 1].toInt() and 0xFF)
                val extLen = ((data[pos + 2].toInt() and 0xFF) shl 8) or (data[pos + 3].toInt() and 0xFF)
                pos += 4
                if (extType == 0x0000 && pos + 5 <= endExt) {
                    val nameLen = ((data[pos + 3].toInt() and 0xFF) shl 8) or (data[pos + 4].toInt() and 0xFF)
                    val nameStart = pos + 5
                    if (nameStart + nameLen <= endExt) {
                        val domain = String(data, nameStart, nameLen, Charsets.US_ASCII)
                        return Triple(domain, nameStart, nameLen)
                    }
                }
                pos += extLen
            }
        } catch (_: Exception) {
        }
        return null
    }

    private fun relayStream(input: InputStream, output: OutputStream) {
        val buffer = ByteArray(16384)
        while (true) {
            val read = input.read(buffer)
            if (read <= 0) break
            output.write(buffer, 0, read)
            output.flush()
        }
    }

    private fun InputStream.readNBytesCompat(n: Int): ByteArray {
        val buf = ByteArray(n)
        var offset = 0
        while (offset < n) {
            val read = read(buf, offset, n - offset)
            if (read <= 0) break
            offset += read
        }
        return if (offset == n) buf else buf.copyOf(offset)
    }
}
