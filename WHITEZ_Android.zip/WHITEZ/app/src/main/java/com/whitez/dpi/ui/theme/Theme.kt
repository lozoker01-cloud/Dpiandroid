package com.whitez.dpi.ui.theme

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

val BgDark = Color(0xFF090D16)
val SurfaceDark = Color(0xFF101827)
val SurfaceElevated = Color(0xFF172236)
val BorderDark = Color(0xFF24324D)
val AccentGreen = Color(0xFF22C55E)
val AccentCyan = Color(0xFF38BDF8)
val AccentAmber = Color(0xFFF59E0B)
val AccentRed = Color(0xFFEF4444)
val TextPrimary = Color(0xFFF8FAFC)
val TextSecondary = Color(0xFF94A3B8)

private val WhitezDarkColors = darkColorScheme(
    primary = AccentCyan,
    secondary = AccentGreen,
    background = BgDark,
    surface = SurfaceDark,
    surfaceVariant = SurfaceElevated,
    onPrimary = Color.Black,
    onBackground = TextPrimary,
    onSurface = TextPrimary,
    onSurfaceVariant = TextSecondary,
    outline = BorderDark
)

@Composable
fun WhitezTheme(content: @Composable () -> Unit) {
    MaterialTheme(
        colorScheme = WhitezDarkColors,
        content = content
    )
}
