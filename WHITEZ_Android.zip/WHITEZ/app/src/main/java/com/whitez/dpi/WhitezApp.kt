package com.whitez.dpi

import android.app.Application
import android.app.NotificationChannel
import android.app.NotificationManager
import android.os.Build

class WhitezApp : Application() {
    companion object {
        const val CHANNEL_ID = "whitez_vpn_channel"
    }

    override fun onCreate() {
        super.onCreate()
        createNotificationChannel()
    }

    private fun createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(
                CHANNEL_ID,
                "WHITEZ DPI Engine",
                NotificationManager.IMPORTANCE_LOW
            ).apply {
                description = "Локальный обход DPI (WHITEZ)"
                setShowBadge(false)
            }
            val manager = getSystemService(NotificationManager::class.java)
            manager.createNotificationChannel(channel)
        }
    }
}
