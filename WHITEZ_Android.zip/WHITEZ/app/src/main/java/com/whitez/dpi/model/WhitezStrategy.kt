package com.whitez.dpi.model

enum class DesyncMode {
    TLS_RECORD_SPLIT,       // -r 1+s (Разрез TLS-записи на 2 отдельных TLS-рекорда)
    SNI_MID_SPLIT,          // -s 0+s (Разрез TCP прямо посередине имени домена SNI)
    DISORDER_SPLIT,         // -d 1 -s 1 (Инверсия/двойная нарезка первого TCP-сегмента)
    FAKE_SNI_SPLIT,         // --fake-sni www.google.com -s 1 -r 1+s (Имитация разрешённого SNI + разрез)
    MULTI_CHUNK_AGGRESSIVE, // -o 1 -r 1+s -s 2+s (Агрессивная 4-сегментная нарезка для ТСПУ 2026)
    QUIC_DROP_ONLY          // Только сброс UDP:443 (принудительный перевод на TCP)
}

data class WhitezStrategy(
    val id: String,
    val name: String,
    val badge: String,
    val zapretPcEquivalent: String,
    val description: String,
    val mode: DesyncMode,
    val args: List<String>,
    val blockQuic: Boolean = true,
    val recommendedFor: String
)

object StrategyRepository {

    /**
     * Актуальные рабочие стратегии 2026 года, перенесённые из ПК-сборок
     * Flowseal/zapret-discord-youtube и ByeDPI/ByeByeDPI.
     */
    val strategies: List<WhitezStrategy> = listOf(
        WhitezStrategy(
            id = "zapret_general_2026",
            name = "Zapret General (Топ для YouTube 2026)",
            badge = "Рекомендуемая",
            zapretPcEquivalent = "general.bat (--dpi-desync=multisplit --dpi-desync-split-pos=1,sniext+1)",
            description = "Двойной разрез TLS-записи + разрыв SNI посередине + блокировка QUIC (UDP 443). Работает на большинстве проводных и Wi-Fi сетей.",
            mode = DesyncMode.TLS_RECORD_SPLIT,
            args = listOf("-r", "1+s", "-s", "1", "-q", "1", "--auto=ssl_err"),
            blockQuic = true,
            recommendedFor = "Ростелеком, МГТС, Дом.ру, региональные Wi-Fi"
        ),
        WhitezStrategy(
            id = "zapret_alt1_fake_sni",
            name = "Zapret ALT 1 (Fake SNI Google + Split)",
            badge = "YouTube 4K / Discord",
            zapretPcEquivalent = "general (ALT1).bat (--dpi-desync=fake,multisplit --dpi-desync-fooling=badseq)",
            description = "Внедрение заголовка SNI www.google.com + нарезка TLS-пакета по 1 байту. Лучший вариант при жёстком замедлении googlevideo.com.",
            mode = DesyncMode.FAKE_SNI_SPLIT,
            args = listOf("--fake-sni", "www.google.com", "-s", "1", "-q", "1", "-r", "1+s"),
            blockQuic = true,
            recommendedFor = "ТСПУ со строгой фильтрацией SNI"
        ),
        WhitezStrategy(
            id = "zapret_alt2_sni_mid",
            name = "Zapret ALT 2 (Разрыв середины SNI)",
            badge = "Быстрый отклик",
            zapretPcEquivalent = "general (ALT2).bat (--dpi-desync=split2 --dpi-desync-split-pos=midsld)",
            description = "Точный разрыв TCP-сегмента строго посередине доменного имени (например, yout|ube.com) без лишних задержек.",
            mode = DesyncMode.SNI_MID_SPLIT,
            args = listOf("-s", "0+s", "-r", "1+s", "-o", "1"),
            blockQuic = true,
            recommendedFor = "Низкий пинг, быстрая загрузка обложек и Shorts"
        ),
        WhitezStrategy(
            id = "zapret_alt3_mobile",
            name = "Zapret ALT 3 (Мобильный 4G/5G + ТСПУ)",
            badge = "МТС / Билайн / МегаФон / Т2",
            zapretPcEquivalent = "general (ALT3).bat (--dpi-desync=fake,disorder2 --dpi-desync-ttl=5)",
            description = "Многоступенчатая фрагментация ClientHello на 4 микро-сегмента с микро-паузой, обходящая мобильные ТСПУ.",
            mode = DesyncMode.MULTI_CHUNK_AGGRESSIVE,
            args = listOf("-f", "-1", "-t", "5", "-d", "1", "-s", "1", "-n", "ya.ru"),
            blockQuic = true,
            recommendedFor = "Мобильный интернет (МТС, МегаФон, Билайн, Tele2, Yota)"
        ),
        WhitezStrategy(
            id = "zapret_alt4_disorder",
            name = "Zapret ALT 4 (Disorder + TLS Record)",
            badge = "Анти-сброс",
            zapretPcEquivalent = "general (ALT4).bat (--dpi-desync=disorder --dpi-desync-split-pos=2)",
            description = "Разделение первого пакета со смещением 2 байта и нарезкой TLS-записи. Помогает, если видео обрывается через 10 секунд.",
            mode = DesyncMode.DISORDER_SPLIT,
            args = listOf("-d", "1", "-s", "2", "-r", "3+s", "-a", "1"),
            blockQuic = true,
            recommendedFor = "Сети с обрывом видеопотока (ERR_CONNECTION_RESET)"
        ),
        WhitezStrategy(
            id = "zapret_alt5_vk_fake",
            name = "Zapret ALT 5 (Белый SNI vk.com / ya.ru)",
            badge = "Тяжёлый ТСПУ",
            zapretPcEquivalent = "general (ALT5).bat (--dpi-desync=fake,split --dpi-desync-fake-tls=tls_clienthello_www_sferum_ru.bin)",
            description = "Маскировка первого TLS-пакета под российский домен из белого списка ТСПУ с последующей передачей реального SNI.",
            mode = DesyncMode.FAKE_SNI_SPLIT,
            args = listOf("--fake-sni", "vk.com", "-s", "1", "-r", "1+s", "-o", "1"),
            blockQuic = true,
            recommendedFor = "Сложные региональные блокировки и публичный Wi-Fi"
        ),
        WhitezStrategy(
            id = "zapret_quic_only",
            name = "Только блокировка QUIC (UDP 443)",
            badge = "Лёгкий режим",
            zapretPcEquivalent = "quic_block_only (--wf-udp=443 --dpi-desync=fake)",
            description = "Отбрасывает UDP-пакеты на порт 443, переводя браузер и YouTube с HTTP/3 (QUIC) на классический TCP.",
            mode = DesyncMode.QUIC_DROP_ONLY,
            args = emptyList(),
            blockQuic = true,
            recommendedFor = "Сети, где достаточно отключить QUIC"
        )
    )

    val targetDomains: List<String> = listOf(
        "youtube.com",
        "www.youtube.com",
        "m.youtube.com",
        "youtu.be",
        "googlevideo.com",
        "ytimg.com",
        "ggpht.com",
        "youtubei.googleapis.com",
        "discord.com",
        "gateway.discord.gg",
        "cdn.discordapp.com",
        "media.discordapp.net",
        "rutracker.org",
        "ntc.party"
    )
}
