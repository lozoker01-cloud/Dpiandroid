package app.whitez

data class Strategy(val id: Int, val name: String, val args: List<String>) {
    val cmd get() = if (args.isEmpty()) "без параметров (контроль)" else args.joinToString(" ")
}

data class Svc(val id: String, val short: String, val name: String, val urls: List<String>)

object Services {
    val all = listOf(
        Svc("yt", "YT", "YouTube", listOf("www.youtube.com", "youtubei.googleapis.com", "i.ytimg.com")),
        Svc("ds", "DS", "Discord", listOf("discord.com", "cdn.discordapp.com", "gateway.discord.gg")),
        Svc("tg", "TG", "Telegram", listOf("web.telegram.org", "telegram.org")),
        Svc("ig", "IG", "Instagram", listOf("www.instagram.com")),
        Svc("x", "X", "X / Twitter", listOf("x.com"))
    )
}

object Apps {
    val list = listOf(
        "com.google.android.youtube", "com.google.android.apps.youtube.music", "app.revanced.android.youtube",
        "com.discord", "org.telegram.messenger", "org.telegram.messenger.web", "org.thunderdog.challegram",
        "com.instagram.android", "com.twitter.android", "com.whatsapp",
        "com.android.chrome", "org.mozilla.firefox", "org.mozilla.fenix", "com.yandex.browser",
        "com.opera.browser", "com.microsoft.emmx", "com.brave.browser", "com.sec.android.app.sbrowser",
        "com.mi.globalbrowser", "com.android.browser"
    ).toTypedArray()
}

object Hosts {
    val builtin = listOf(
        "googlevideo.com", "youtubei.googleapis.com", "youtube.com", "ggpht.com", "ytimg.com", "youtu.be", "yt.be",
        "youtube-nocookie.com", "googleapis.com", "gstatic.com",
        "discord.com", "discord.gg", "discordapp.com", "discordapp.net", "discord.media", "discordcdn.com",
        "telegram.org", "t.me", "telegram.me", "telesco.pe", "tdesktop.com",
        "instagram.com", "cdninstagram.com", "facebook.com", "fbcdn.net", "fb.com", "whatsapp.com", "whatsapp.net", "threads.net",
        "x.com", "twitter.com", "twimg.com", "t.co"
    )
}

object Strategies {
    private fun s(id: Int, name: String, cmd: String) = Strategy(id, name, cmd.trim().split(Regex("\\s+")))

    const val RECOMMENDED = 1
    const val CUSTOM_ID = 100

    val baseline = Strategy(0, "Без обхода", emptyList())

    // Фильтр режет по имени сервера (SNI) в первом пакете TLS. ClientHello приложения YouTube ~1,75 КБ и уходит двумя сегментами,
    // поэтому нужны разрезы по всей длине. Видеокэши провайдера стоят в ~6 хопах: TTL приманки 5-6, не 3-4.
    val all = listOf(
        s(1,  "Нарезка по всему ClientHello",  "-d1 -s1+s -d3+s -s6+s -d9+s -s12+s -d15+s -s20+s -d25+s -s30+s -a1"),
        s(2,  "Приманка TTL 6",               "-f1+s -t6"),
        s(3,  "Disorder + приманка TTL 5",    "-d1 -f-1 -t5"),
        s(4,  "Disorder + OOB 25",            "-d1 -o25+s"),
        s(5,  "OOB 1 + 25, auto",             "-o1 -o25+s -T3 -At"),
        s(6,  "Приманка + TLS-rec 6/27",      "-f-2 -t5 -d2 -r6+s -r27+s"),
        s(7,  "Приманка с SNI google",        "-f-2 -t5 -n www.google.com -r23+s"),
        s(8,  "Ростелеком",                   "-r5+s -s25+s -a1 -At,r,s -s50 -r5+s -s50+s -a1 -r10+s"),
        s(9,  "Длинная цепочка (2026)",       "-d1 -d3+s -s6+s -d9+s -s12+s -d15+s -s20+s -d25+s -s30+s -d35+s -r1+s -S -a1 -As -d1 -d3+s -s6+s -d9+s -s12+s -d15+s -s20+s -d25+s -s30+s -d35+s -S -a1"),
        s(10, "Disorder + нарезка",           "-d1 -d1+s"),
        s(11, "Адаптивная SSL",               "--fake -1 --ttl 6 --auto=ssl_err --fake -1 --ttl 5 --udp-fake 1"),
        s(12, "Цепочка + auto (2025)",        "-Ku -a1 -An -d1 -s0+s -d3+s -s6+s -d9+s -s12+s -d15+s -s20+s -d25+s -s30+s -d35+s -At,r,s -s1 -q1 -At,r,s -s5 -o25000+s -At,r,s -o1 -d1 -r1+s -t10 -b1500 -s0+s -d3+s -At,r,s -f-1 -r1+s -At,r,s -s1 -o1+s -s-1"),
        s(13, "OOB + TLS-rec (2026)",         "-o1 -d3 -s8 -s8+s -o30+s -r26+s -T5 -At -X -b 65536"),
        s(14, "Билайн/Москва, TTL 6",         "-Kt,h -s0 -o1 -d1 -r1+s -Ar -o1 -At -f-1 -t6 -r1+s -As -An -Ku -a5 -s443+s -d80+s -s80+s"),
        s(15, "Auto torst / ssl, TTL 6",      "-s1 -d1 -o1 -Ar -o3 -At -f-1 -t6 -r1+s -As"),
        s(16, "Цепочка Ar/At, TTL 6",         "-s1 -o1 -Ar -o1 -At -f-1 -t6 -r1+s -As"),
        s(17, "Цепочка с -Y, TTL 6",          "-s1 -q1 -Y -Ar -s5 -o1+s -At -f-1 -t6 -r1+s -As -s1 -o1+s -s-1 -An"),
        s(18, "Цепочка split/disorder",       "-d1 -s0+s -d3+s -s6+s -d9+s -s12+s -d15+s -s20+s -d25+s -s30+s -d35+s"),
        s(19, "Цепочка 443/80/53",            "-d1+s -O1 -s29+s -t 5 -An -Ku -a5 -s443+s -d80+s -d443+s -s80+s -s443+s -d53+s -s53+s -d443+s -An"),
        s(20, "Disorder + TLS-rec + UDP",     "--disorder 1 --tlsrec 1+s --udp-fake 1"),
        s(21, "Split + Disorder + OOB",       "--split 1+s --disorder 3+s --oob 1+s --udp-fake 1")
    )

    fun custom(cmd: String): Strategy? {
        val t = cmd.trim()
        return if (t.isEmpty()) null else Strategy(CUSTOM_ID, "Своя стратегия", t.split(Regex("\\s+")))
    }

    fun byId(id: Int, customCmd: String = ""): Strategy = when {
        id == 0 -> baseline
        id == CUSTOM_ID -> custom(customCmd) ?: all[RECOMMENDED - 1]
        else -> all.firstOrNull { it.id == id } ?: all[RECOMMENDED - 1]
    }

    fun withHosts(args: List<String>, path: String): List<String> {
        fun isMarker(t: String) = t.startsWith("-A") || t.startsWith("--auto")
        val groups = mutableListOf(mutableListOf<String>())
        for (t in args) { if (isMarker(t)) groups.add(mutableListOf(t)) else groups.last().add(t) }
        val out = mutableListOf<String>()
        for (g in groups) {
            val marker = g.firstOrNull { isMarker(it) }
            val body = g.filter { !isMarker(it) }
            if (marker != null) out.add(marker)
            val udp = body.any { it.startsWith("-Ku") }
            if (body.isNotEmpty() && !udp) { out.add("-H"); out.add(path) }
            out.addAll(body)
        }
        if (out.lastOrNull() != "-An") out.add("-An")
        return out
    }
}

data class StrategyResult(
    val strategy: Strategy,
    val passed: Set<String> = emptySet(),
    val avgMs: Long = -1,
    val speedKb: Long = -1,
    val error: String? = null,
    val tested: Boolean = false
) { val score get() = passed.size }
