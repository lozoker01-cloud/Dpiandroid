package app.whitez
import android.app.*
import android.content.Intent
import android.net.ConnectivityManager
import android.net.VpnService
import android.os.ParcelFileDescriptor
import hev.htproxy.TProxyService
import libv2ray.CoreCallbackHandler
import libv2ray.CoreController
import libv2ray.Libv2ray
import java.io.File
import java.net.Inet4Address

class WhitezVpnService : VpnService() {
    private var tun: ParcelFileDescriptor? = null
    private var core: CoreController? = null
    @Volatile private var proc: Process? = null
    @Volatile private var stopping = false
    private var restarts = 0

    private val handler = object : CoreCallbackHandler {
        override fun startup(): Long = 0
        override fun shutdown(): Long = 0
        override fun onEmitStatus(code: Long, msg: String?): Long = 0
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action == "STOP") { stopVpn(); return START_NOT_STICKY }
        val mode = intent?.getStringExtra("mode") ?: "vpn"
        val config = intent?.getStringExtra("config")
        val args = intent?.getStringArrayExtra("args")
        val apps = intent?.getStringArrayExtra("apps")
        val dns = intent?.getStringExtra("dns") ?: "isp"
        if (mode == "vpn" && config == null) return START_NOT_STICKY
        if (mode == "dpi" && args == null) return START_NOT_STICKY
        startForeground(1, notification(mode))
        Thread { startVpn(mode, config, args, apps, dns) }.start()
        return START_NOT_STICKY
    }

    private fun launchEngine(port: Int, args: List<String>): Process {
        val p = Engine.spawn(this, port, args) { State.addLog(it) }
        proc = p
        Thread {
            val code = try { p.waitFor() } catch (_: Exception) { -1 }
            if (!stopping && proc === p) {
                State.addLog("[движок завершился, код $code]")
                if (restarts < 5) {
                    restarts++
                    try { Thread.sleep(300); State.addLog("[перезапуск $restarts]"); launchEngine(port, args) } catch (_: Throwable) {}
                } else State.error.value = "Движок остановлен системой (код $code)"
            }
        }.start()
        return p
    }

    private fun ispDns(): List<String> = try {
        val cm = getSystemService(ConnectivityManager::class.java)
        cm.getLinkProperties(cm.activeNetwork)?.dnsServers
            ?.filterIsInstance<Inet4Address>()?.mapNotNull { it.hostAddress }?.take(2) ?: emptyList()
    } catch (_: Throwable) { emptyList() }

    private fun startVpn(mode: String, config: String?, args: Array<String>?, apps: Array<String>?, dnsMode: String) {
        try {
            val isp = if (mode == "dpi" && dnsMode == "isp") ispDns() else emptyList()
            stopQuiet()
            stopping = false; restarts = 0
            val port: Int
            if (mode == "dpi") {
                port = 1080
                val base = args!!.toList()
                State.addLog("[ciadpi ${base.joinToString(" ")}]")
                var p = launchEngine(port, listOf("-x", "1") + base)
                Thread.sleep(500)
                if (!p.isAlive) {
                    State.addLog("[-x не принят, запуск без отладки]")
                    stopping = true; proc = null; stopping = false
                    p = launchEngine(port, base)
                    Thread.sleep(500)
                    if (!p.isAlive) throw IllegalStateException("Движок обхода не запустился (проверьте параметры стратегии)")
                }
            } else {
                port = XrayConfig.SOCKS_PORT
                Libv2ray.initCoreEnv(filesDir.path, "")
                core = CoreController(handler).also { it.startLoop(config!!, 0) }
            }
            val b = Builder().setSession("WHITEZ").setMtu(1500)
                .addAddress("10.10.14.1", 30).addRoute("0.0.0.0", 0)
            if (mode == "dpi") {
                if (isp.isNotEmpty()) {
                    isp.forEach { b.addDnsServer(it) }
                    State.addLog("[DNS провайдера: ${isp.joinToString()}]")
                } else {
                    b.addDnsServer("8.8.8.8").addDnsServer("8.8.4.4")
                    State.addLog("[DNS Google: 8.8.8.8]")
                }
            } else {
                b.addAddress("fd00::1", 126).addRoute("::", 0)
                    .addDnsServer("1.1.1.1").addDnsServer("8.8.8.8")
            }
            var allowed = 0
            if (apps != null) for (a in apps) {
                try { b.addAllowedApplication(a); allowed++ } catch (_: Exception) {}
            }
            if (allowed == 0) b.addDisallowedApplication(packageName)
            State.addLog("[VPN: приложений в туннеле: ${if (allowed == 0) "все" else allowed.toString()}]")
            tun = b.establish() ?: throw IllegalStateException("VPN не разрешён")
            val v6 = if (mode == "dpi") "" else "\n  ipv6: 'fd00::1'"
            val yml = File(filesDir, "tun.yml")
            yml.writeText(
                "tunnel:\n  mtu: 1500\n  ipv4: 10.10.14.1$v6\n" +
                "socks5:\n  port: $port\n  address: 127.0.0.1\n  udp: 'udp'\n" +
                "misc:\n  log-level: warn\n")
            TProxyService.TProxyStartService(yml.absolutePath, tun!!.fd)
            State.activeMode.value = mode
            State.running.value = true
        } catch (e: Throwable) {
            State.error.value = e.message ?: e.javaClass.simpleName
            stopVpn()
        }
    }

    private fun stopQuiet() {
        stopping = true
        try { TProxyService.TProxyStopService() } catch (_: Throwable) {}
        try { core?.stopLoop() } catch (_: Throwable) {}
        core = null
        try { proc?.destroy() } catch (_: Throwable) {}
        proc = null
        try { tun?.close() } catch (_: Throwable) {}
        tun = null
    }

    private fun stopVpn() {
        stopQuiet()
        State.running.value = false
        State.activeMode.value = ""
        stopForeground(STOP_FOREGROUND_REMOVE); stopSelf()
    }
    override fun onRevoke() { stopVpn() }
    override fun onDestroy() { stopQuiet(); State.running.value = false; super.onDestroy() }

    private fun notification(mode: String): Notification {
        val nm = getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(NotificationChannel("w", "WHITEZ", NotificationManager.IMPORTANCE_LOW))
        return Notification.Builder(this, "w").setContentTitle("WHITEZ")
            .setContentText(if (mode == "dpi") "Обход блокировок активен" else "VPN активен")
            .setSmallIcon(android.R.drawable.ic_lock_lock).build()
    }
}
