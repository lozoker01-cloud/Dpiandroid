package com.zapret.android.ui.theme

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

val BgDark = Color(0xFF0D0F12)
val SurfaceDark = Color(0xFF161A20)
val SurfaceElevated = Color(0xFF1E232B)
val BorderDark = Color(0xFF2A303C)
val AccentGreen = Color(0xFF22C55E)
val AccentBlue = Color(0xFF3B82F6)
val AccentAmber = Color(0xFFF59E0B)
val AccentRed = Color(0xFFEF4444)
val TextPrimary = Color(0xFFF3F4F6)
val TextSecondary = Color(0xFF9CA3AF)

private val ZapretDarkColors = darkColorScheme(
    primary = AccentBlue,
    secondary = AccentGreen,
    background = BgDark,
    surface = SurfaceDark,
    surfaceVariant = SurfaceElevated,
    onPrimary = Color.White,
    onBackground = TextPrimary,
    onSurface = TextPrimary,
    onSurfaceVariant = TextSecondary,
    outline = BorderDark
)

@Composable
fun ZapretTheme(content: @Composable () -> Unit) {
    MaterialTheme(
        colorScheme = ZapretDarkColors,
        content = content
    )
}
