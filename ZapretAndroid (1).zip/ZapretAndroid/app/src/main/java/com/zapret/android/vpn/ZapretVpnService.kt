package com.zapret.android.vpn

import android.app.Notification
import android.app.PendingIntent
import android.content.Intent
import android.net.ConnectivityManager
import android.net.Network
import android.net.NetworkCapabilities
import android.net.NetworkRequest
import android.net.VpnService
import android.os.Build
import android.os.ParcelFileDescriptor
import android.util.Log
import androidx.core.app.NotificationCompat
import com.zapret.android.MainActivity
import com.zapret.android.ZapretApp
import com.zapret.android.data.SettingsRepository
import com.zapret.android.engine.NativeDpiEngine
import com.zapret.android.engine.PureKotlinDpiProxy
import com.zapret.android.model.StrategyRepository
import com.zapret.android.model.ZapretStrategy
import kotlinx.coroutines.*
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.first
import java.io.File
import java.io.FileInputStream
import java.nio.ByteBuffer

enum class VpnState {
    DISCONNECTED,
    CONNECTING,
    CONNECTED,
    ERROR
}

class ZapretVpnService : VpnService() {

    companion object {
        private const val TAG = "ZapretVpnService"
        private const val NOTIFICATION_ID = 1001

        const val ACTION_START = "com.zapret.android.START"
        const val ACTION_STOP = "com.zapret.android.STOP"
        const val ACTION_RESTART = "com.zapret.android.RESTART"

        private val _vpnState = MutableStateFlow(VpnState.DISCONNECTED)
        val vpnState: StateFlow<VpnState> = _vpnState

        private val _activeStrategy = MutableStateFlow<ZapretStrategy?>(null)
        val activeStrategy: StateFlow<ZapretStrategy?> = _activeStrategy

        private val _networkType = MutableStateFlow("Определение сети...")
        val networkType: StateFlow<String> = _networkType
    }

    private val serviceScope = CoroutineScope(SupervisorJob() + Dispatchers.IO)
    private var vpnInterface: ParcelFileDescriptor? = null
    private lateinit var nativeEngine: NativeDpiEngine
    private var kotlinProxy: PureKotlinDpiProxy? = null
    private var networkCallback: ConnectivityManager.NetworkCallback? = null

    override fun onCreate() {
        super.onCreate()
        nativeEngine = NativeDpiEngine(this)
        registerNetworkWatcher()
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        when (intent?.action) {
            ACTION_STOP -> {
                stopVpn()
                stopSelf()
                return START_NOT_STICKY
            }
            ACTION_RESTART -> {
                serviceScope.launch {
                    stopVpn()
                    delay(300)
                    startVpn()
                }
            }
            else -> {
                startForeground(NOTIFICATION_ID, buildNotification("Запуск обхода DPI..."))
                serviceScope.launch {
                    startVpn()
                }
            }
        }
        return START_STICKY
    }

    private suspend fun startVpn() {
        if (_vpnState.value == VpnState.CONNECTED) return
        _vpnState.value = VpnState.CONNECTING

        try {
            val settingsRepo = SettingsRepository(applicationContext)
            val settings = settingsRepo.settingsFlow.first()
            val strategy = StrategyRepository.strategies.find { it.id == settings.selectedStrategyId }
                ?: StrategyRepository.strategies.first()

            _activeStrategy.value = strategy

            val allDomains = buildSet {
                addAll(StrategyRepository.targetDomains)
                settings.customDomainsRaw
                    .split("\n", ",", " ")
                    .map { it.trim() }
                    .filter { it.isNotBlank() }
                    .forEach { add(it) }
            }

            val hostsFile = writeHostsFile(allDomains)

            val nativeStarted = nativeEngine.startDpiProxy(
                strategy = strategy,
                port = NativeDpiEngine.SOCKS_PORT,
                hostsFilePath = if (settings.onlyTargetDomains) hostsFile.absolutePath else null
            )

            if (!nativeStarted) {
                kotlinProxy = PureKotlinDpiProxy(
                    vpnService = this,
                    port = NativeDpiEngine.SOCKS_PORT,
                    strategy = strategy,
                    targetDomains = if (settings.onlyTargetDomains) allDomains else emptySet()
                ).also { it.start(serviceScope) }
            }

            val builder = Builder()
                .setSession("Zapret DPI (${strategy.name})")
                .setMtu(1500)
                .addAddress("10.0.0.2", 24)
                .addDnsServer("1.1.1.1")
                .addDnsServer("8.8.8.8")
                .addRoute("0.0.0.0", 0)

            try {
                builder.addDisallowedApplication(packageName)
            } catch (_: Exception) {
            }

            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                builder.setMetered(false)
            }

            vpnInterface = builder.establish()
            val pfd = vpnInterface ?: throw IllegalStateException("Не удалось создать TUN-интерфейс")

            val tunStarted = nativeEngine.startTun2Socks(pfd.fd, mtu = 1500)
            if (!tunStarted) {
                launchFallbackPacketFilter(pfd, settings.blockQuic || strategy.blockQuic)
            }

            _vpnState.value = VpnState.CONNECTED
            updateNotification("Активно • ${strategy.name}")
            Log.i(TAG, "Zapret VPN успешно запущен со стратегией: ${strategy.name}")
        } catch (e: Exception) {
            Log.e(TAG, "Ошибка запуска VPN", e)
            _vpnState.value = VpnState.ERROR
            stopVpn()
        }
    }

    private fun launchFallbackPacketFilter(pfd: ParcelFileDescriptor, blockQuic: Boolean) {
        serviceScope.launch(Dispatchers.IO) {
            val input = FileInputStream(pfd.fileDescriptor)
            val buffer = ByteBuffer.allocate(32767)

            while (isActive && _vpnState.value == VpnState.CONNECTED) {
                try {
                    val length = input.read(buffer.array())
                    if (length > 0) {
                        val ipVersion = (buffer.get(0).toInt() shr 4) and 0xF
                        if (ipVersion == 4 && length >= 28) {
                            val protocol = buffer.get(9).toInt() and 0xFF
                            val ihl = (buffer.get(0).toInt() and 0xF) * 4
                            if (protocol == 17 && length >= ihl + 8) {
                                val dstPort = ((buffer.get(ihl + 2).toInt() and 0xFF) shl 8) or
                                        (buffer.get(ihl + 3).toInt() and 0xFF)
                                if (blockQuic && dstPort == 443) {
                                    buffer.clear()
                                    continue
                                }
                            }
                        }
                        buffer.clear()
                    }
                } catch (_: Exception) {
                    break
                }
            }
        }
    }

    private fun writeHostsFile(domains: Set<String>): File {
        val file = File(filesDir, "zapret_hosts.txt")
        file.writeText(domains.joinToString("\n"))
        return file
    }

    private fun stopVpn() {
        _vpnState.value = VpnState.DISCONNECTED
        _activeStrategy.value = null
        kotlinProxy?.stop()
        kotlinProxy = null
        nativeEngine.stopAll()
        try {
            vpnInterface?.close()
        } catch (_: Exception) {
        }
        vpnInterface = null
    }

    private fun registerNetworkWatcher() {
        val cm = getSystemService(ConnectivityManager::class.java)
        val request = NetworkRequest.Builder()
            .addCapability(NetworkCapabilities.NET_CAPABILITY_INTERNET)
            .build()

        networkCallback = object : ConnectivityManager.NetworkCallback() {
            override fun onAvailable(network: Network) {
                updateNetworkLabel(cm, network)
            }

            override fun onCapabilitiesChanged(network: Network, caps: NetworkCapabilities) {
                updateNetworkLabel(cm, network)
            }
        }
        try {
            cm.registerNetworkCallback(request, networkCallback!!)
        } catch (_: Exception) {
        }
    }

    private fun updateNetworkLabel(cm: ConnectivityManager, network: Network) {
        val caps = cm.getNetworkCapabilities(network) ?: return
        _networkType.value = when {
            caps.hasTransport(NetworkCapabilities.TRANSPORT_WIFI) -> "Wi-Fi сеть"
            caps.hasTransport(NetworkCapabilities.TRANSPORT_CELLULAR) -> "Мобильная сеть (4G/5G)"
            caps.hasTransport(NetworkCapabilities.TRANSPORT_ETHERNET) -> "Ethernet"
            else -> "Активная сеть"
        }
    }

    private fun buildNotification(text: String): Notification {
        val openIntent = PendingIntent.getActivity(
            this,
            0,
            Intent(this, MainActivity::class.java),
            PendingIntent.FLAG_IMMUTABLE
        )

        val stopIntent = PendingIntent.getService(
            this,
            1,
            Intent(this, ZapretVpnService::class.java).apply { action = ACTION_STOP },
            PendingIntent.FLAG_IMMUTABLE
        )

        return NotificationCompat.Builder(this, ZapretApp.CHANNEL_ID)
            .setContentTitle("Zapret DPI")
            .setContentText(text)
            .setSmallIcon(android.R.drawable.ic_lock_lock)
            .setContentIntent(openIntent)
            .addAction(android.R.drawable.ic_media_pause, "Отключить", stopIntent)
            .setOngoing(true)
            .build()
    }

    private fun updateNotification(text: String) {
        val nm = getSystemService(android.app.NotificationManager::class.java)
        nm.notify(NOTIFICATION_ID, buildNotification(text))
    }

    override fun onDestroy() {
        networkCallback?.let {
            try {
                getSystemService(ConnectivityManager::class.java).unregisterNetworkCallback(it)
            } catch (_: Exception) {
            }
        }
        stopVpn()
        serviceScope.cancel()
        super.onDestroy()
    }
}
