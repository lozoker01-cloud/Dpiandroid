package com.zapret.android.engine

import android.net.VpnService
import android.util.Log
import com.zapret.android.model.ZapretStrategy
import kotlinx.coroutines.*
import java.io.InputStream
import java.io.OutputStream
import java.net.InetSocketAddress
import java.net.ServerSocket
import java.net.Socket

class PureKotlinDpiProxy(
    private val vpnService: VpnService?,
    private val port: Int,
    private val strategy: ZapretStrategy,
    private val targetDomains: Set<String>
) {
    companion object {
        private const val TAG = "PureKotlinDpiProxy"
        private val DOMAIN_REGEX = Regex("[a-zA-Z0-9-]+(\\.[a-zA-Z0-9-]+)+")
    }

    private var serverSocket: ServerSocket? = null
    private var job: Job? = null

    fun start(scope: CoroutineScope) {
        stop()
        job = scope.launch(Dispatchers.IO) {
            try {
                serverSocket = ServerSocket().apply {
                    reuseAddress = true
                    bind(InetSocketAddress("127.0.0.1", port))
                }
                Log.i(TAG, "Kotlin DPI SOCKS5 запущен на порту $port (${strategy.name})")
                while (isActive) {
                    val client = serverSocket?.accept() ?: break
                    launch { handleSocksClient(client) }
                }
            } catch (e: Exception) {
                if (isActive) Log.e(TAG, "Ошибка сервера SOCKS5", e)
            }
        }
    }

    fun stop() {
        job?.cancel()
        try {
            serverSocket?.close()
        } catch (_: Exception) {
        }
        serverSocket = null
    }

    private suspend fun handleSocksClient(client: Socket) = withContext(Dispatchers.IO) {
        var remote: Socket? = null
        try {
            client.tcpNoDelay = true
            val input = client.getInputStream()
            val output = client.getOutputStream()

            val ver = input.read()
            if (ver != 5) {
                client.close()
                return@withContext
            }
            val nMethods = input.read()
            if (nMethods > 0) input.readNBytesCompat(nMethods)
            output.write(byteArrayOf(0x05, 0x00))
            output.flush()

            val reqHeader = input.readNBytesCompat(4)
            if (reqHeader.size < 4 || reqHeader[1].toInt() != 0x01) {
                client.close()
                return@withContext
            }

            val host: String
            when (reqHeader[3].toInt()) {
                0x01 -> {
                    val addr = input.readNBytesCompat(4)
                    host = addr.joinToString(".") { (it.toInt() and 0xFF).toString() }
                }
                0x03 -> {
                    val len = input.read()
                    host = String(input.readNBytesCompat(len), Charsets.UTF_8)
                }
                0x04 -> {
                    val addr = input.readNBytesCompat(16)
                    host = addr.toList().chunked(2).joinToString(":") {
                        "%02x%02x".format(it[0], it[1])
                    }
                }
                else -> {
                    client.close()
                    return@withContext
                }
            }

            val portBytes = input.readNBytesCompat(2)
            val destPort = ((portBytes[0].toInt() and 0xFF) shl 8) or (portBytes[1].toInt() and 0xFF)

            remote = Socket().apply {
                tcpNoDelay = true
                vpnService?.protect(this)
                connect(InetSocketAddress(host, destPort), 8000)
            }

            output.write(byteArrayOf(0x05, 0x00, 0x00, 0x01, 0, 0, 0, 0, 0, 0))
            output.flush()

            val remoteIn = remote.getInputStream()
            val remoteOut = remote.getOutputStream()

            val c2r = launch {
                relayClientToRemote(input, remoteOut, host, destPort)
            }
            val r2c = launch {
                relayStream(remoteIn, output)
            }
            joinAll(c2r, r2c)
        } catch (_: Exception) {
        } finally {
            try { client.close() } catch (_: Exception) {}
            try { remote?.close() } catch (_: Exception) {}
        }
    }

    private fun relayClientToRemote(
        input: InputStream,
        output: OutputStream,
        host: String,
        port: Int
    ) {
        val buffer = ByteArray(16384)
        var isFirstPacket = true
        while (true) {
            val read = input.read(buffer)
            if (read <= 0) break

            if (isFirstPacket && port == 443 && read > 10 && buffer[0] == 0x16.toByte()) {
                isFirstPacket = false
                val shouldApplyDpi = targetDomains.isEmpty() ||
                        targetDomains.any { host.endsWith(it, ignoreCase = true) } ||
                        extractSni(buffer, read)?.let { sni ->
                            targetDomains.any { sni.endsWith(it, ignoreCase = true) }
                        } == true

                if (shouldApplyDpi && strategy.args.isNotEmpty()) {
                    sendFragmentedTlsClientHello(output, buffer, read)
                    continue
                }
            }
            isFirstPacket = false
            output.write(buffer, 0, read)
            output.flush()
        }
    }

    private fun sendFragmentedTlsClientHello(output: OutputStream, data: ByteArray, length: Int) {
        val splitPoint1 = 2
        val splitPoint2 = minOf(length / 2, 48)

        if (length > splitPoint2 && splitPoint2 > splitPoint1) {
            output.write(data, 0, splitPoint1)
            output.flush()
            Thread.sleep(1)

            output.write(data, splitPoint1, splitPoint2 - splitPoint1)
            output.flush()
            Thread.sleep(1)

            output.write(data, splitPoint2, length - splitPoint2)
            output.flush()
        } else {
            output.write(data, 0, 1)
            output.flush()
            output.write(data, 1, length - 1)
            output.flush()
        }
    }

    private fun relayStream(input: InputStream, output: OutputStream) {
        val buffer = ByteArray(16384)
        while (true) {
            val read = input.read(buffer)
            if (read <= 0) break
            output.write(buffer, 0, read)
            output.flush()
        }
    }

    private fun extractSni(data: ByteArray, len: Int): String? {
        return try {
            val text = String(data, 0, len, Charsets.ISO_8859_1)
            DOMAIN_REGEX.findAll(text).map { it.value }.firstOrNull { it.contains(".") }
        } catch (_: Exception) {
            null
        }
    }

    private fun InputStream.readNBytesCompat(n: Int): ByteArray {
        val buf = ByteArray(n)
        var offset = 0
        while (offset < n) {
            val read = read(buf, offset, n - offset)
            if (read <= 0) break
            offset += read
        }
        return if (offset == n) buf else buf.copyOf(offset)
    }
}
