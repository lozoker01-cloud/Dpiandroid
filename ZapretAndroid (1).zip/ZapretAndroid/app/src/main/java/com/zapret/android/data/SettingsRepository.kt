package com.zapret.android.data

import android.content.Context
import androidx.datastore.preferences.core.*
import androidx.datastore.preferences.preferencesDataStore
import com.zapret.android.model.StrategyRepository
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map

private val Context.dataStore by preferencesDataStore(name = "zapret_settings")

data class AppSettings(
    val selectedStrategyId: String = StrategyRepository.strategies.first().id,
    val onlyTargetDomains: Boolean = true,
    val blockQuic: Boolean = true,
    val autoReconnectOnNetworkChange: Boolean = true,
    val customDomainsRaw: String = ""
)

class SettingsRepository(private val context: Context) {

    private object Keys {
        val SELECTED_STRATEGY = stringPreferencesKey("selected_strategy")
        val ONLY_TARGET_DOMAINS = booleanPreferencesKey("only_target_domains")
        val BLOCK_QUIC = booleanPreferencesKey("block_quic")
        val AUTO_RECONNECT = booleanPreferencesKey("auto_reconnect")
        val CUSTOM_DOMAINS = stringPreferencesKey("custom_domains")
    }

    val settingsFlow: Flow<AppSettings> = context.dataStore.data.map { prefs ->
        AppSettings(
            selectedStrategyId = prefs[Keys.SELECTED_STRATEGY]
                ?: StrategyRepository.strategies.first().id,
            onlyTargetDomains = prefs[Keys.ONLY_TARGET_DOMAINS] ?: true,
            blockQuic = prefs[Keys.BLOCK_QUIC] ?: true,
            autoReconnectOnNetworkChange = prefs[Keys.AUTO_RECONNECT] ?: true,
            customDomainsRaw = prefs[Keys.CUSTOM_DOMAINS] ?: ""
        )
    }

    suspend fun setSelectedStrategy(id: String) {
        context.dataStore.edit { it[Keys.SELECTED_STRATEGY] = id }
    }

    suspend fun setOnlyTargetDomains(enabled: Boolean) {
        context.dataStore.edit { it[Keys.ONLY_TARGET_DOMAINS] = enabled }
    }

    suspend fun setBlockQuic(enabled: Boolean) {
        context.dataStore.edit { it[Keys.BLOCK_QUIC] = enabled }
    }

    suspend fun setAutoReconnect(enabled: Boolean) {
        context.dataStore.edit { it[Keys.AUTO_RECONNECT] = enabled }
    }

    suspend fun setCustomDomains(domains: String) {
        context.dataStore.edit { it[Keys.CUSTOM_DOMAINS] = domains }
    }
}
