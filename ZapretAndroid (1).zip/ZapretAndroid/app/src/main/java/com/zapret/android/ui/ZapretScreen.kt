package com.zapret.android.ui

import androidx.compose.animation.animateColorAsState
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.zapret.android.model.StrategyRepository
import com.zapret.android.model.ZapretStrategy
import com.zapret.android.ui.theme.*
import com.zapret.android.vpn.VpnState

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ZapretMainScreen(
    viewModel: MainViewModel,
    onRequestVpnPermission: () -> Unit
) {
    val vpnState by viewModel.vpnState.collectAsState()
    val settings by viewModel.settings.collectAsState()
    val networkType by viewModel.networkType.collectAsState()
    val autoTest by viewModel.autoTestState.collectAsState()

    var selectedTab by remember { mutableIntStateOf(0) }

    val selectedStrategy = remember(settings.selectedStrategyId) {
        StrategyRepository.strategies.find { it.id == settings.selectedStrategyId }
            ?: StrategyRepository.strategies.first()
    }

    Scaffold(
        containerColor = BgDark,
        topBar = {
            TopAppBar(
                title = {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text(
                            text = "ZAPRET",
                            fontWeight = FontWeight.Bold,
                            letterSpacing = 1.5.sp,
                            color = TextPrimary
                        )
                        Spacer(Modifier.width(8.dp))
                        Surface(
                            color = SurfaceElevated,
                            shape = RoundedCornerShape(6.dp),
                            border = BorderStroke(1.dp, BorderDark)
                        ) {
                            Text(
                                text = "NO-ROOT",
                                fontSize = 10.sp,
                                fontWeight = FontWeight.SemiBold,
                                color = AccentGreen,
                                modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                            )
                        }
                    }
                },
                actions = {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        modifier = Modifier.padding(end = 16.dp)
                    ) {
                        Icon(
                            imageVector = Icons.Rounded.CellTower,
                            contentDescription = null,
                            tint = TextSecondary,
                            modifier = Modifier.size(16.dp)
                        )
                        Spacer(Modifier.width(4.dp))
                        Text(
                            text = networkType,
                            fontSize = 12.sp,
                            color = TextSecondary
                        )
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(containerColor = BgDark)
            )
        },
        bottomBar = {
            NavigationBar(
                containerColor = SurfaceDark,
                tonalElevation = 0.dp
            ) {
                NavigationBarItem(
                    selected = selectedTab == 0,
                    onClick = { selectedTab = 0 },
                    icon = { Icon(Icons.Rounded.PowerSettingsNew, contentDescription = null) },
                    label = { Text("Главная") }
                )
                NavigationBarItem(
                    selected = selectedTab == 1,
                    onClick = { selectedTab = 1 },
                    icon = { Icon(Icons.Rounded.Tune, contentDescription = null) },
                    label = { Text("Стратегии") }
                )
                NavigationBarItem(
                    selected = selectedTab == 2,
                    onClick = { selectedTab = 2 },
                    icon = { Icon(Icons.Rounded.Speed, contentDescription = null) },
                    label = { Text("Автоподбор") }
                )
                NavigationBarItem(
                    selected = selectedTab == 3,
                    onClick = { selectedTab = 3 },
                    icon = { Icon(Icons.Rounded.Language, contentDescription = null) },
                    label = { Text("Домены") }
                )
            }
        }
    ) { padding ->
        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
        ) {
            when (selectedTab) {
                0 -> HomeTab(
                    vpnState = vpnState,
                    selectedStrategy = selectedStrategy,
                    onToggleConnection = {
                        if (vpnState == VpnState.CONNECTED || vpnState == VpnState.CONNECTING) {
                            viewModel.stopVpnService()
                        } else {
                            onRequestVpnPermission()
                        }
                    },
                    onOpenStrategies = { selectedTab = 1 },
                    onRunAutoPick = {
                        selectedTab = 2
                        viewModel.startAutoPick()
                    }
                )
                1 -> StrategiesTab(
                    selectedId = settings.selectedStrategyId,
                    onSelect = { viewModel.selectStrategy(it) }
                )
                2 -> AutoPickTab(
                    autoTest = autoTest,
                    onStartTest = { viewModel.startAutoPick() },
                    onCancelTest = { viewModel.cancelAutoPick() },
                    onApplyStrategy = {
                        viewModel.selectStrategy(it)
                        selectedTab = 0
                    }
                )
                3 -> DomainsAndSettingsTab(
                    onlyTargetDomains = settings.onlyTargetDomains,
                    blockQuic = settings.blockQuic,
                    customDomains = settings.customDomainsRaw,
                    onToggleOnlyTarget = viewModel::toggleOnlyTargetDomains,
                    onToggleBlockQuic = viewModel::toggleBlockQuic,
                    onCustomDomainsChange = viewModel::updateCustomDomains
                )
            }
        }
    }
}

@Composable
private fun HomeTab(
    vpnState: VpnState,
    selectedStrategy: ZapretStrategy,
    onToggleConnection: () -> Unit,
    onOpenStrategies: () -> Unit,
    onRunAutoPick: () -> Unit
) {
    val isConnected = vpnState == VpnState.CONNECTED

    val buttonColor by animateColorAsState(
        targetValue = when (vpnState) {
            VpnState.CONNECTED -> AccentGreen
            VpnState.CONNECTING -> AccentAmber
            VpnState.ERROR -> AccentRed
            VpnState.DISCONNECTED -> SurfaceElevated
        },
        label = "btnColor"
    )

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(20.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.SpaceBetween
    ) {
        Spacer(Modifier.height(8.dp))

        Column(horizontalAlignment = Alignment.CenterHorizontally) {
            Box(
                contentAlignment = Alignment.Center,
                modifier = Modifier
                    .size(176.dp)
                    .clip(CircleShape)
                    .background(buttonColor.copy(alpha = 0.14f))
                    .clickable { onToggleConnection() }
            ) {
                Surface(
                    shape = CircleShape,
                    color = buttonColor,
                    border = BorderStroke(
                        2.dp,
                        if (isConnected) AccentGreen else BorderDark
                    ),
                    modifier = Modifier.size(136.dp)
                ) {
                    Box(contentAlignment = Alignment.Center) {
                        Icon(
                            imageVector = Icons.Rounded.PowerSettingsNew,
                            contentDescription = "Включить",
                            tint = if (isConnected) Color.Black else TextPrimary,
                            modifier = Modifier.size(56.dp)
                        )
                    }
                }
            }

            Spacer(Modifier.height(20.dp))

            Text(
                text = when (vpnState) {
                    VpnState.CONNECTED -> "Защита от DPI активна"
                    VpnState.CONNECTING -> "Подключение..."
                    VpnState.ERROR -> "Ошибка запуска"
                    VpnState.DISCONNECTED -> "Отключено"
                },
                fontSize = 20.sp,
                fontWeight = FontWeight.Bold,
                color = when (vpnState) {
                    VpnState.CONNECTED -> AccentGreen
                    VpnState.ERROR -> AccentRed
                    else -> TextPrimary
                }
            )

            Spacer(Modifier.height(6.dp))

            Text(
                text = if (isConnected)
                    "YouTube и заблокированные ресурсы работают напрямую без снижения скорости"
                else
                    "Нажмите кнопку выше, чтобы включить локальный обход блокировок",
                fontSize = 13.sp,
                color = TextSecondary,
                modifier = Modifier.padding(horizontal = 24.dp),
                lineHeight = 18.sp
            )
        }

        Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
            Surface(
                color = SurfaceDark,
                shape = RoundedCornerShape(14.dp),
                border = BorderStroke(1.dp, BorderDark),
                modifier = Modifier
                    .fillMaxWidth()
                    .clickable { onOpenStrategies() }
            ) {
                Row(
                    modifier = Modifier.padding(16.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Column(modifier = Modifier.weight(1f)) {
                        Text(
                            text = "ТЕКУЩАЯ СТРАТЕГИЯ",
                            fontSize = 11.sp,
                            fontWeight = FontWeight.SemiBold,
                            color = TextSecondary
                        )
                        Spacer(Modifier.height(4.dp))
                        Text(
                            text = selectedStrategy.name,
                            fontSize = 16.sp,
                            fontWeight = FontWeight.SemiBold,
                            color = TextPrimary
                        )
                        Spacer(Modifier.height(2.dp))
                        Text(
                            text = selectedStrategy.recommendedFor,
                            fontSize = 12.sp,
                            color = TextSecondary
                        )
                    }
                    Icon(
                        imageVector = Icons.Rounded.ChevronRight,
                        contentDescription = null,
                        tint = TextSecondary
                    )
                }
            }

            OutlinedButton(
                onClick = onRunAutoPick,
                shape = RoundedCornerShape(12.dp),
                border = BorderStroke(1.dp, AccentBlue),
                modifier = Modifier
                    .fillMaxWidth()
                    .height(50.dp)
            ) {
                Icon(Icons.Rounded.AutoFixHigh, contentDescription = null, tint = AccentBlue)
                Spacer(Modifier.width(8.dp))
                Text(
                    text = "Автоподбор лучшей стратегии для моей сети",
                    color = TextPrimary,
                    fontWeight = FontWeight.Medium
                )
            }
        }
    }
}

@Composable
private fun StrategiesTab(
    selectedId: String,
    onSelect: (ZapretStrategy) -> Unit
) {
    LazyColumn(
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        item {
            Text(
                text = "Стратегии обхода (аналог ПК-сборок Zapret)",
                fontSize = 18.sp,
                fontWeight = FontWeight.Bold,
                color = TextPrimary,
                modifier = Modifier.padding(bottom = 4.dp)
            )
            Text(
                text = "Если видео грузится медленно или не открывается — переключите стратегию на ALT 1–7.",
                fontSize = 13.sp,
                color = TextSecondary,
                modifier = Modifier.padding(bottom = 8.dp)
            )
        }

        items(StrategyRepository.strategies) { strategy ->
            val isSelected = strategy.id == selectedId
            Surface(
                color = if (isSelected) SurfaceElevated else SurfaceDark,
                shape = RoundedCornerShape(14.dp),
                border = BorderStroke(
                    width = if (isSelected) 1.5.dp else 1.dp,
                    color = if (isSelected) AccentBlue else BorderDark
                ),
                modifier = Modifier
                    .fillMaxWidth()
                    .clickable { onSelect(strategy) }
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween,
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Text(
                            text = strategy.name,
                            fontSize = 16.sp,
                            fontWeight = FontWeight.Bold,
                            color = TextPrimary
                        )
                        Surface(
                            color = BgDark,
                            shape = RoundedCornerShape(6.dp),
                            border = BorderStroke(1.dp, BorderDark)
                        ) {
                            Text(
                                text = strategy.badge,
                                fontSize = 11.sp,
                                color = if (isSelected) AccentGreen else AccentBlue,
                                modifier = Modifier.padding(horizontal = 8.dp, vertical = 3.dp)
                            )
                        }
                    }

                    Spacer(Modifier.height(6.dp))

                    Text(
                        text = strategy.description,
                        fontSize = 13.sp,
                        color = TextSecondary,
                        lineHeight = 18.sp
                    )

                    if (strategy.args.isNotEmpty()) {
                        Spacer(Modifier.height(8.dp))
                        Text(
                            text = "Параметры: ${strategy.args.joinToString(" ")}",
                            fontSize = 11.sp,
                            color = TextSecondary.copy(alpha = 0.75f)
                        )
                    }
                }
            }
        }
    }
}

@Composable
private fun AutoPickTab(
    autoTest: AutoTestUiState,
    onStartTest: () -> Unit,
    onCancelTest: () -> Unit,
    onApplyStrategy: (ZapretStrategy) -> Unit
) {
    LazyColumn(
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        item {
            Text(
                text = "Автоподбор и тест стратегий",
                fontSize = 18.sp,
                fontWeight = FontWeight.Bold,
                color = TextPrimary
            )
            Spacer(Modifier.height(4.dp))
            Text(
                text = "Приложение проверит каждую стратегию на доступность YouTube и серверов видео (googlevideo.com) и выберет самую быструю.",
                fontSize = 13.sp,
                color = TextSecondary
            )
            Spacer(Modifier.height(12.dp))

            if (autoTest.isRunning) {
                Surface(
                    color = SurfaceDark,
                    shape = RoundedCornerShape(14.dp),
                    border = BorderStroke(1.dp, BorderDark),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(modifier = Modifier.padding(16.dp)) {
                        Row(
                            horizontalArrangement = Arrangement.SpaceBetween,
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Text(
                                text = "Проверка: ${autoTest.currentStrategyName}",
                                fontSize = 14.sp,
                                fontWeight = FontWeight.SemiBold,
                                color = TextPrimary
                            )
                            Text(
                                text = "${autoTest.progressIndex}/${autoTest.totalCount}",
                                fontSize = 14.sp,
                                color = AccentBlue
                            )
                        }
                        Spacer(Modifier.height(10.dp))
                        LinearProgressIndicator(
                            progress = {
                                if (autoTest.totalCount > 0)
                                    autoTest.progressIndex.toFloat() / autoTest.totalCount
                                else 0f
                            },
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(6.dp)
                                .clip(RoundedCornerShape(3.dp)),
                            color = AccentBlue,
                            trackColor = BgDark
                        )
                        Spacer(Modifier.height(12.dp))
                        TextButton(onClick = onCancelTest) {
                            Text("Остановить проверку", color = AccentRed)
                        }
                    }
                }
            } else {
                Button(
                    onClick = onStartTest,
                    shape = RoundedCornerShape(12.dp),
                    colors = ButtonDefaults.buttonColors(containerColor = AccentBlue),
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(48.dp)
                ) {
                    Icon(Icons.Rounded.PlayArrow, contentDescription = null)
                    Spacer(Modifier.width(8.dp))
                    Text("Запустить полное тестирование", fontWeight = FontWeight.SemiBold)
                }
            }
        }

        autoTest.bestStrategy?.let { winner ->
            item {
                Surface(
                    color = AccentGreen.copy(alpha = 0.12f),
                    shape = RoundedCornerShape(14.dp),
                    border = BorderStroke(1.dp, AccentGreen),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(modifier = Modifier.padding(16.dp)) {
                        Text(
                            text = "ЛУЧШАЯ СТРАТЕГИЯ НАЙДЕНА",
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Bold,
                            color = AccentGreen
                        )
                        Spacer(Modifier.height(4.dp))
                        Text(
                            text = "${winner.strategy.name} (${winner.latencyMs} мс)",
                            fontSize = 16.sp,
                            fontWeight = FontWeight.Bold,
                            color = TextPrimary
                        )
                        Spacer(Modifier.height(10.dp))
                        Button(
                            onClick = { onApplyStrategy(winner.strategy) },
                            colors = ButtonDefaults.buttonColors(containerColor = AccentGreen),
                            shape = RoundedCornerShape(10.dp)
                        ) {
                            Text("Применить и вернуться", color = Color.Black, fontWeight = FontWeight.Bold)
                        }
                    }
                }
            }
        }

        items(autoTest.results) { res ->
            Surface(
                color = SurfaceDark,
                shape = RoundedCornerShape(12.dp),
                border = BorderStroke(1.dp, BorderDark),
                modifier = Modifier
                    .fillMaxWidth()
                    .clickable(enabled = res.isSuccess) { onApplyStrategy(res.strategy) }
            ) {
                Row(
                    modifier = Modifier.padding(14.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Column(modifier = Modifier.weight(1f)) {
                        Text(
                            text = res.strategy.name,
                            fontSize = 14.sp,
                            fontWeight = FontWeight.SemiBold,
                            color = TextPrimary
                        )
                        Text(
                            text = res.details,
                            fontSize = 12.sp,
                            color = if (res.isSuccess) AccentGreen else TextSecondary
                        )
                    }
                    Icon(
                        imageVector = if (res.isSuccess) Icons.Rounded.CheckCircle else Icons.Rounded.Cancel,
                        contentDescription = null,
                        tint = if (res.isSuccess) AccentGreen else AccentRed
                    )
                }
            }
        }
    }
}

@Composable
private fun DomainsAndSettingsTab(
    onlyTargetDomains: Boolean,
    blockQuic: Boolean,
    customDomains: String,
    onToggleOnlyTarget: (Boolean) -> Unit,
    onToggleBlockQuic: (Boolean) -> Unit,
    onCustomDomainsChange: (String) -> Unit
) {
    LazyColumn(
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        item {
            Text(
                text = "Настройки фильтрации и доменов",
                fontSize = 18.sp,
                fontWeight = FontWeight.Bold,
                color = TextPrimary
            )
        }

        item {
            Surface(
                color = SurfaceDark,
                shape = RoundedCornerShape(14.dp),
                border = BorderStroke(1.dp, BorderDark)
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween,
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Column(modifier = Modifier.weight(1f)) {
                            Text(
                                text = "Только список доменов (Split Tunneling)",
                                fontSize = 15.sp,
                                fontWeight = FontWeight.SemiBold,
                                color = TextPrimary
                            )
                            Text(
                                text = "Российские банки, Госуслуги и игры работают напрямую без обработки DPI",
                                fontSize = 12.sp,
                                color = TextSecondary
                            )
                        }
                        Switch(
                            checked = onlyTargetDomains,
                            onCheckedChange = onToggleOnlyTarget
                        )
                    }

                    HorizontalDivider(
                        color = BorderDark,
                        modifier = Modifier.padding(vertical = 12.dp)
                    )

                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween,
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Column(modifier = Modifier.weight(1f)) {
                            Text(
                                text = "Блокировать QUIC (UDP 443)",
                                fontSize = 15.sp,
                                fontWeight = FontWeight.SemiBold,
                                color = TextPrimary
                            )
                            Text(
                                text = "Обязательно для корректной работы YouTube в Chrome и приложении",
                                fontSize = 12.sp,
                                color = TextSecondary
                            )
                        }
                        Switch(
                            checked = blockQuic,
                            onCheckedChange = onToggleBlockQuic
                        )
                    }
                }
            }
        }

        item {
            Text(
                text = "Свои домены (по одному на строку)",
                fontSize = 14.sp,
                fontWeight = FontWeight.SemiBold,
                color = TextPrimary
            )
            Spacer(Modifier.height(6.dp))
            OutlinedTextField(
                value = customDomains,
                onValueChange = onCustomDomainsChange,
                placeholder = { Text("example.com\nmy-site.org") },
                modifier = Modifier
                    .fillMaxWidth()
                    .height(130.dp),
                shape = RoundedCornerShape(12.dp)
            )
        }

        item {
            Text(
                text = "Встроенный список (${StrategyRepository.targetDomains.size} доменов):",
                fontSize = 13.sp,
                fontWeight = FontWeight.SemiBold,
                color = TextSecondary
            )
            Spacer(Modifier.height(6.dp))
            Surface(
                color = SurfaceDark,
                shape = RoundedCornerShape(12.dp),
                border = BorderStroke(1.dp, BorderDark),
                modifier = Modifier.fillMaxWidth()
            ) {
                Text(
                    text = StrategyRepository.targetDomains.joinToString(", "),
                    fontSize = 12.sp,
                    color = TextSecondary,
                    modifier = Modifier.padding(12.dp)
                )
            }
        }
    }
}
