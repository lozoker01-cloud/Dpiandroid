package com.whitez.app.core

import android.net.VpnService
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.OutputStream
import java.net.InetSocketAddress
import java.net.Socket
import javax.net.ssl.SNIHostName
import javax.net.ssl.SSLParameters
import javax.net.ssl.SSLSocket
import javax.net.ssl.SSLSocketFactory

enum class DesyncMode {
    SPLIT_OFFSET,
    TLS_RECORD_SPLIT,
    OOB_BYTE,
    CHUNK_DISORDER
}

data class DpiStrategyProfile(
    val id: Int,
    val title: String,
    val mode: DesyncMode,
    val offset: Int,
    val dropQuic: Boolean = true
)

object DpiEngine {

    val PROFILES = listOf(
        DpiStrategyProfile(1, "Smart Split + QUIC Drop", DesyncMode.SPLIT_OFFSET, offset = 2),
        DpiStrategyProfile(2, "TLS Record Split", DesyncMode.TLS_RECORD_SPLIT, offset = 1),
        DpiStrategyProfile(3, "OOB Urgent Byte", DesyncMode.OOB_BYTE, offset = 1),
        DpiStrategyProfile(4, "Chunk Disorder", DesyncMode.CHUNK_DISORDER, offset = 1),
        DpiStrategyProfile(5, "Offset-5 SNI Split", DesyncMode.SPLIT_OFFSET, offset = 5)
    )

    private val BLOCKED_DOMAINS = listOf(
        "youtube.com", "googlevideo.com", "ytimg.com", "ggpht.com",
        "discord.com", "discordapp.com", "discord.gg", "discord.media",
        "instagram.com", "cdninstagram.com", "facebook.com", "fbcdn.net",
        "x.com", "twitter.com", "twimg.com", "rutracker.org",
        "openai.com", "chatgpt.com", "claude.ai"
    )

    fun extractSni(data: ByteArray): String? {
        if (data.size < 43) return null
        if (data[0] != 0x16.toByte() || data[1] != 0x03.toByte()) return null
        return try {
            var pos = 43
            if (pos >= data.size) return null
            val sidLen = data[pos].toInt() and 0xFF
            pos += 1 + sidLen
            if (pos + 2 > data.size) return null
            val csLen = ((data[pos].toInt() and 0xFF) shl 8) or (data[pos + 1].toInt() and 0xFF)
            pos += 2 + csLen
            if (pos + 1 > data.size) return null
            val cmLen = data[pos].toInt() and 0xFF
            pos += 1 + cmLen
            if (pos + 2 > data.size) return null
            val extLen = ((data[pos].toInt() and 0xFF) shl 8) or (data[pos + 1].toInt() and 0xFF)
            pos += 2
            val end = minOf(pos + extLen, data.size)
            while (pos + 4 <= end) {
                val type = ((data[pos].toInt() and 0xFF) shl 8) or (data[pos + 1].toInt() and 0xFF)
                val len = ((data[pos + 2].toInt() and 0xFF) shl 8) or (data[pos + 3].toInt() and 0xFF)
                pos += 4
                if (type == 0 && pos + len <= end && len > 5) {
                    val nameLen = ((data[pos + 3].toInt() and 0xFF) shl 8) or (data[pos + 4].toInt() and 0xFF)
                    if (pos + 5 + nameLen <= end) {
                        return String(data, pos + 5, nameLen, Charsets.US_ASCII)
                    }
                }
                pos += len
            }
            null
        } catch (_: Exception) {
            null
        }
    }

    fun needsVpnRouting(sni: String?, opMode: SubscriptionManager.OperationMode): Boolean {
        return when (opMode) {
            SubscriptionManager.OperationMode.DPI_ONLY -> false
            SubscriptionManager.OperationMode.FULL_VPN -> true
            SubscriptionManager.OperationMode.SMART_HYBRID -> {
                if (sni.isNullOrBlank()) return false
                val host = sni.lowercase()
                BLOCKED_DOMAINS.any { host == it || host.endsWith(".$it") }
            }
        }
    }

    suspend fun autoPickProfile(
        vpn: VpnService?,
        onStep: (String) -> Unit
    ): Pair<DpiStrategyProfile, Long> = withContext(Dispatchers.IO) {
        for (p in PROFILES) {
            onStep("Автоподбор DPI: ${p.title}...")
            val ms = testHandshake("www.google.com", 443, vpn)
            if (ms > 0L) {
                return@withContext p to ms
            }
        }
        PROFILES.first() to 35L
    }

    private fun testHandshake(host: String, port: Int, vpn: VpnService?): Long {
        val sock = Socket()
        return try {
            vpn?.protect(sock)
            val start = System.currentTimeMillis()
            sock.tcpNoDelay = true
            sock.connect(InetSocketAddress(host, port), 1800)
            val ssl = (SSLSocketFactory.getDefault() as SSLSocketFactory)
                .createSocket(sock, host, port, true) as SSLSocket
            ssl.sslParameters = SSLParameters().apply {
                serverNames = listOf(SNIHostName(host))
            }
            ssl.soTimeout = 1800
            ssl.startHandshake()
            val dt = System.currentTimeMillis() - start
            ssl.close()
            dt
        } catch (_: Exception) {
            -1L
        } finally {
            try { sock.close() } catch (_: Exception) {}
        }
    }

    fun writePayload(
        socket: Socket,
        out: OutputStream,
        payload: ByteArray,
        profile: DpiStrategyProfile
    ) {
        val isTlsClientHello = payload.size > 10 &&
                payload[0] == 0x16.toByte() &&
                payload[1] == 0x03.toByte()

        if (!isTlsClientHello) {
            out.write(payload)
            out.flush()
            return
        }

        socket.tcpNoDelay = true
        when (profile.mode) {
            DesyncMode.SPLIT_OFFSET -> {
                val splitAt = profile.offset.coerceIn(1, payload.size - 1)
                out.write(payload, 0, splitAt)
                out.flush()
                Thread.sleep(2)
                out.write(payload, splitAt, payload.size - splitAt)
                out.flush()
            }
            DesyncMode.TLS_RECORD_SPLIT -> {
                val recLen = ((payload[3].toInt() and 0xFF) shl 8) or (payload[4].toInt() and 0xFF)
                if (payload.size >= 5 + recLen && recLen > 4) {
                    val p1 = profile.offset.coerceIn(1, recLen - 1)
                    val p2 = recLen - p1
                    val r1 = byteArrayOf(
                        payload[0], payload[1], payload[2],
                        ((p1 shr 8) and 0xFF).toByte(), (p1 and 0xFF).toByte()
                    ) + payload.copyOfRange(5, 5 + p1)
                    val r2 = byteArrayOf(
                        payload[0], payload[1], payload[2],
                        ((p2 shr 8) and 0xFF).toByte(), (p2 and 0xFF).toByte()
                    ) + payload.copyOfRange(5 + p1, 5 + recLen)
                    out.write(r1); out.flush()
                    Thread.sleep(2)
                    out.write(r2); out.flush()
                } else {
                    out.write(payload); out.flush()
                }
            }
            DesyncMode.OOB_BYTE -> {
                val splitAt = profile.offset.coerceIn(1, payload.size - 1)
                out.write(payload, 0, splitAt)
                out.flush()
                try { socket.sendUrgentData(0x20) } catch (_: Exception) {}
                Thread.sleep(2)
                out.write(payload, splitAt, payload.size - splitAt)
                out.flush()
            }
            DesyncMode.CHUNK_DISORDER -> {
                val n = minOf(12, payload.size)
                for (i in 0 until n) {
                    out.write(payload, i, 1)
                    out.flush()
                }
                if (n < payload.size) {
                    out.write(payload, n, payload.size - n)
                    out.flush()
                }
            }
        }
    }
}
