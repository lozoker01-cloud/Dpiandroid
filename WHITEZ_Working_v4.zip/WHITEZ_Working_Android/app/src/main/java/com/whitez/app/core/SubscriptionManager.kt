package com.whitez.app.core

import android.content.Context
import android.net.Uri
import android.util.Base64
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.net.HttpURLConnection
import java.net.InetSocketAddress
import java.net.Socket
import java.net.URL
import java.net.URLDecoder

data class VpnNode(
    val id: String,
    val name: String,
    val protocol: String,
    val host: String,
    val port: Int,
    val rawUri: String,
    var pingMs: Long = -1L
)

object SubscriptionManager {
    private const val PREFS_NAME = "whitez_v4_prefs"
    private const val KEY_SUB_URL = "sub_url"
    private const val KEY_CACHED_RAW = "cached_raw"
    private const val KEY_MODE = "op_mode"

    const val DEFAULT_SUBSCRIPTION_URL =
        "http://31.59.207.13:2096/511gttxhtbu86vr5/8ojmix9ue0g2zd6y"

    enum class OperationMode(val title: String, val subtitle: String) {
        SMART_HYBRID(
            "Гибрид: DPI + Свой VPN",
            "Прямой DPI для РФ + авто-переход на твой VPN для заблокированных сайтов"
        ),
        DPI_ONLY(
            "Только Auto-DPI (Без VPN)",
            "Обход DPI напрямую без VPN-сервера"
        ),
        FULL_VPN(
            "Весь трафик через Свой VPN",
            "Весь трафик через сервер подписки с авто-DPI защитой"
        )
    }

    fun getSubscriptionUrl(context: Context): String {
        val prefs = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
        return prefs.getString(KEY_SUB_URL, DEFAULT_SUBSCRIPTION_URL) ?: DEFAULT_SUBSCRIPTION_URL
    }

    fun saveSubscriptionUrl(context: Context, url: String) {
        context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
            .edit().putString(KEY_SUB_URL, url.trim()).apply()
    }

    fun getOperationMode(context: Context): OperationMode {
        val prefs = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
        val raw = prefs.getString(KEY_MODE, OperationMode.SMART_HYBRID.name)
        return try {
            OperationMode.valueOf(raw ?: OperationMode.SMART_HYBRID.name)
        } catch (_: Exception) {
            OperationMode.SMART_HYBRID
        }
    }

    fun saveOperationMode(context: Context, mode: OperationMode) {
        context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
            .edit().putString(KEY_MODE, mode.name).apply()
    }

    suspend fun syncAndMeasureNodes(
        context: Context,
        protectSocket: ((Socket) -> Unit)? = null
    ): List<VpnNode> = withContext(Dispatchers.IO) {
        val urlStr = getSubscriptionUrl(context)
        val prefs = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)

        val rawText = try {
            val conn = (URL(urlStr).openConnection() as HttpURLConnection).apply {
                connectTimeout = 4500
                readTimeout = 4500
                setRequestProperty("User-Agent", "v2rayTun/3.2.0")
            }
            val body = conn.inputStream.bufferedReader().use { it.readText() }.trim()
            if (body.isNotEmpty()) {
                prefs.edit().putString(KEY_CACHED_RAW, body).apply()
            }
            body
        } catch (_: Exception) {
            prefs.getString(KEY_CACHED_RAW, "") ?: ""
        }

        val nodes = parseSubscription(rawText)
        nodes.forEach { n ->
            n.pingMs = measureTcp(n.host, n.port, protectSocket)
        }
        nodes.sortedBy { if (it.pingMs < 0) Long.MAX_VALUE else it.pingMs }
    }

    fun parseSubscription(raw: String): List<VpnNode> {
        if (raw.isBlank()) return emptyList()
        val text = if (
            raw.startsWith("vless://") ||
            raw.startsWith("vmess://") ||
            raw.startsWith("trojan://") ||
            raw.startsWith("ss://")
        ) {
            raw
        } else {
            try {
                val clean = raw.replace("\s".toRegex(), "")
                String(Base64.decode(clean, Base64.DEFAULT), Charsets.UTF_8)
            } catch (_: Exception) {
                raw
            }
        }

        return text.lines()
            .map { it.trim() }
            .filter { it.contains("://") }
            .mapIndexedNotNull { idx, line -> parseUriLine(idx, line) }
    }

    private fun parseUriLine(index: Int, rawUri: String): VpnNode? {
        return try {
            val schemeIdx = rawUri.indexOf("://")
            if (schemeIdx <= 0) return null
            val proto = rawUri.substring(0, schemeIdx).lowercase()
            val uri = Uri.parse(rawUri)
            val host = uri.host ?: return null
            val port = if (uri.port > 0) uri.port else 443
            val frag = uri.fragment?.let {
                try { URLDecoder.decode(it, "UTF-8") } catch (_: Exception) { it }
            }
            val title = frag?.takeIf { it.isNotBlank() } ?: "Node #${index + 1}"
            VpnNode(
                id = "srv_$index",
                name = title,
                protocol = proto.uppercase(),
                host = host,
                port = port,
                rawUri = rawUri
            )
        } catch (_: Exception) {
            null
        }
    }

    private fun measureTcp(host: String, port: Int, protectSocket: ((Socket) -> Unit)?): Long {
        val socket = Socket()
        return try {
            protectSocket?.invoke(socket)
            val t0 = System.currentTimeMillis()
            socket.connect(InetSocketAddress(host, port), 2000)
            System.currentTimeMillis() - t0
        } catch (_: Exception) {
            -1L
        } finally {
            try { socket.close() } catch (_: Exception) {}
        }
    }
}
