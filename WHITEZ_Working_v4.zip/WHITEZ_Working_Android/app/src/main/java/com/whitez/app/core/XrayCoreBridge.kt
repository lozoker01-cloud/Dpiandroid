package com.whitez.app.core

import android.net.Uri
import org.json.JSONArray
import org.json.JSONObject
import java.net.InetSocketAddress
import java.net.Socket

object XrayCoreBridge {
    const val SOCKS_HOST = "127.0.0.1"
    const val SOCKS_PORT = 10808

    @Volatile
    var coreActive: Boolean = false
        private set

    fun buildConfig(node: VpnNode): String {
        val uri = Uri.parse(node.rawUri)
        val uuid = uri.userInfo ?: ""
        val sni = uri.getQueryParameter("sni") ?: node.host
        val pbk = uri.getQueryParameter("pbk") ?: ""
        val sid = uri.getQueryParameter("sid") ?: ""
        val fp = uri.getQueryParameter("fp") ?: "chrome"
        val security = uri.getQueryParameter("security") ?: "none"
        val flow = uri.getQueryParameter("flow") ?: ""
        val network = uri.getQueryParameter("type") ?: "tcp"

        val inbound = JSONObject().apply {
            put("port", SOCKS_PORT)
            put("listen", SOCKS_HOST)
            put("protocol", "socks")
            put("settings", JSONObject().put("udp", true))
        }

        val userObj = JSONObject().apply {
            put("id", uuid)
            put("encryption", "none")
            if (flow.isNotBlank()) put("flow", flow)
        }

        val vnextObj = JSONObject().apply {
            put("address", node.host)
            put("port", node.port)
            put("users", JSONArray().put(userObj))
        }

        val streamObj = JSONObject().apply {
            put("network", network)
            put("security", security)
            if (security == "reality") {
                put("realitySettings", JSONObject().apply {
                    put("serverName", sni)
                    put("fingerprint", fp)
                    put("publicKey", pbk)
                    put("shortId", sid)
                })
            } else if (security == "tls") {
                put("tlsSettings", JSONObject().apply {
                    put("serverName", sni)
                })
            }
        }

        val outbound = JSONObject().apply {
            put("protocol", node.protocol.lowercase())
            put("settings", JSONObject().put("vnext", JSONArray().put(vnextObj)))
            put("streamSettings", streamObj)
        }

        return JSONObject().apply {
            put("inbounds", JSONArray().put(inbound))
            put("outbounds", JSONArray().put(outbound))
        }.toString(2)
    }

    fun start(node: VpnNode): Boolean {
        val cfg = buildConfig(node)
        coreActive = try {
            val libCls = Class.forName("libv2ray.Libv2ray")
            val ctrl = libCls.getMethod("newCoreController", Any::class.java).invoke(null, null)
            ctrl.javaClass.getMethod("startLoop", String::class.java).invoke(ctrl, cfg)
            true
        } catch (_: Exception) {
            isSocksReady()
        }
        return coreActive
    }

    fun stop() {
        coreActive = false
    }

    fun isSocksReady(): Boolean {
        return try {
            Socket().use { s ->
                s.connect(InetSocketAddress(SOCKS_HOST, SOCKS_PORT), 250)
                true
            }
        } catch (_: Exception) {
            false
        }
    }
}
