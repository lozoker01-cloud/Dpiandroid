package com.whitez.app.vpn

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Intent
import android.net.VpnService
import android.os.Build
import android.os.ParcelFileDescriptor
import androidx.core.app.NotificationCompat
import com.whitez.app.core.*
import com.whitez.app.ui.MainActivity
import kotlinx.coroutines.*
import java.io.FileInputStream
import java.io.FileOutputStream
import java.net.DatagramPacket
import java.net.DatagramSocket
import java.net.InetAddress
import java.net.InetSocketAddress
import java.net.Socket
import java.nio.ByteBuffer
import java.util.concurrent.ConcurrentHashMap

class WhitezCoreVpnService : VpnService() {

    companion object {
        const val ACTION_START = "com.whitez.app.ACTION_START"
        const val ACTION_STOP = "com.whitez.app.ACTION_STOP"
        const val BROADCAST_STATE = "com.whitez.app.BROADCAST_STATE"

        const val EXTRA_STATE = "state"
        const val EXTRA_STATUS = "status"
        const val EXTRA_NODE = "node"
        const val EXTRA_DPI = "dpi"
        const val EXTRA_PING = "ping"

        const val STATE_IDLE = "IDLE"
        const val STATE_STARTING = "STARTING"
        const val STATE_ACTIVE = "ACTIVE"

        @Volatile var currentState: String = STATE_IDLE
        @Volatile var currentNode: String = "Сервер 31.59.207.13"
        @Volatile var currentDpi: String = "Smart Split + QUIC Drop"
        @Volatile var currentPing: Long = 0L
    }

    private var tunPfd: ParcelFileDescriptor? = null
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.IO)
    private val activeSessions = ConcurrentHashMap<String, ClientTcpBridge>()
    private var dpiProfile: DpiStrategyProfile = DpiEngine.PROFILES.first()
    private var opMode: SubscriptionManager.OperationMode = SubscriptionManager.OperationMode.SMART_HYBRID

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        when (intent?.action) {
            ACTION_STOP -> {
                stopAll()
                return START_NOT_STICKY
            }
            ACTION_START, null -> {
                startForeground(303, makeNotification("Запуск WHITEZ..."))
                scope.launch { runStartupFlow() }
            }
        }
        return START_STICKY
    }

    private suspend fun runStartupFlow() {
        opMode = SubscriptionManager.getOperationMode(this)
        notifyState(STATE_STARTING, "Проверка серверов и автоподбор DPI...")

        val nodes = SubscriptionManager.syncAndMeasureNodes(this) { sock -> protect(sock) }
        val topNode = nodes.firstOrNull()
        if (topNode != null) {
            currentNode = "${topNode.name} (${topNode.protocol})"
            if (topNode.pingMs > 0) currentPing = topNode.pingMs
            if (opMode != SubscriptionManager.OperationMode.DPI_ONLY) {
                XrayCoreBridge.start(topNode)
            }
        } else {
            currentNode = "31.59.207.13 (Подписка)"
        }

        val (picked, dpiPing) = DpiEngine.autoPickProfile(this) { msg ->
            notifyState(STATE_STARTING, msg)
        }
        dpiProfile = picked
        currentDpi = picked.title
        if (currentPing <= 0L) currentPing = dpiPing

        setupTun()

        val label = if (opMode != SubscriptionManager.OperationMode.DPI_ONLY && !XrayCoreBridge.isSocksReady()) {
            "${opMode.title} • Режим прямого DPI-обхода"
        } else {
            opMode.title
        }
        notifyState(STATE_ACTIVE, label)
        updateNotification("WHITEZ активен • $label")

        loopPackets()
    }

    private fun setupTun() {
        tunPfd?.close()
        val builder = Builder()
            .setSession("WHITEZ")
            .setMtu(1400)
            .addAddress("10.88.0.1", 30)
            .addRoute("0.0.0.0", 0)
            .addDnsServer("1.1.1.1")
            .addDnsServer("8.8.8.8")

        try {
            builder.addDisallowedApplication(packageName)
        } catch (_: Exception) {
        }
        tunPfd = builder.establish()
    }

    private suspend fun loopPackets() = withContext(Dispatchers.IO) {
        val fd = tunPfd?.fileDescriptor ?: return@withContext
        val input = FileInputStream(fd)
        val output = FileOutputStream(fd)
        val buf = ByteArray(16384)

        while (isActive && tunPfd != null) {
            val len = try {
                input.read(buf)
            } catch (_: Exception) {
                break
            }
            if (len <= 0) continue
            handleRawPacket(buf.copyOf(len), output)
        }
    }

    private fun handleRawPacket(pkt: ByteArray, tunOut: FileOutputStream) {
        if (pkt.size < 20) return
        val version = (pkt[0].toInt() shr 4) and 0x0F
        if (version != 4) return

        val ihl = (pkt[0].toInt() and 0x0F) * 4
        val proto = pkt[9].toInt() and 0xFF
        val srcIp = InetAddress.getByAddress(pkt.copyOfRange(12, 16))
        val dstIp = InetAddress.getByAddress(pkt.copyOfRange(16, 20))

        if (proto == 17 && pkt.size >= ihl + 8) {
            val dstPort = ((pkt[ihl + 2].toInt() and 0xFF) shl 8) or (pkt[ihl + 3].toInt() and 0xFF)
            if (dstPort == 443 && dpiProfile.dropQuic) return
            handleUdp(pkt, ihl, srcIp, dstIp, tunOut)
        } else if (proto == 6 && pkt.size >= ihl + 20) {
            handleTcp(pkt, ihl, srcIp, dstIp, tunOut)
        }
    }

    private fun handleUdp(
        pkt: ByteArray,
        ihl: Int,
        srcIp: InetAddress,
        dstIp: InetAddress,
        tunOut: FileOutputStream
    ) {
        val srcPort = ((pkt[ihl].toInt() and 0xFF) shl 8) or (pkt[ihl + 1].toInt() and 0xFF)
        val dstPort = ((pkt[ihl + 2].toInt() and 0xFF) shl 8) or (pkt[ihl + 3].toInt() and 0xFF)
        val offset = ihl + 8
        if (offset >= pkt.size) return
        val payload = pkt.copyOfRange(offset, pkt.size)

        scope.launch {
            val ds = DatagramSocket()
            try {
                protect(ds)
                ds.soTimeout = 2500
                ds.send(DatagramPacket(payload, payload.size, dstIp, dstPort))
                val respBuf = ByteArray(4096)
                val respPkt = DatagramPacket(respBuf, respBuf.size)
                ds.receive(respPkt)
                val ipOut = PacketBuilder.buildUdp(dstIp, dstPort, srcIp, srcPort, respBuf.copyOf(respPkt.length))
                synchronized(tunOut) { tunOut.write(ipOut) }
            } catch (_: Exception) {
            } finally {
                ds.close()
            }
        }
    }

    private fun handleTcp(
        pkt: ByteArray,
        ihl: Int,
        srcIp: InetAddress,
        dstIp: InetAddress,
        tunOut: FileOutputStream
    ) {
        val srcPort = ((pkt[ihl].toInt() and 0xFF) shl 8) or (pkt[ihl + 1].toInt() and 0xFF)
        val dstPort = ((pkt[ihl + 2].toInt() and 0xFF) shl 8) or (pkt[ihl + 3].toInt() and 0xFF)
        val seq = ByteBuffer.wrap(pkt, ihl + 4, 4).int.toLong() and 0xFFFFFFFFL
        val tcpHdrLen = ((pkt[ihl + 12].toInt() shr 4) and 0x0F) * 4
        val flags = pkt[ihl + 13].toInt() and 0xFF

        val syn = (flags and 0x02) != 0
        val fin = (flags and 0x01) != 0
        val rst = (flags and 0x04) != 0
        val key = "${srcIp.hostAddress}:$srcPort->${dstIp.hostAddress}:$dstPort"

        if (fin || rst) {
            activeSessions.remove(key)?.close()
            return
        }

        if (syn) {
            activeSessions.remove(key)?.close()
            val bridge = ClientTcpBridge(
                service = this,
                srcIp = srcIp,
                srcPort = srcPort,
                dstIp = dstIp,
                dstPort = dstPort,
                initSeq = seq,
                profile = dpiProfile,
                mode = opMode,
                tunOut = tunOut,
                onClosed = { activeSessions.remove(key) }
            )
            activeSessions[key] = bridge
            bridge.sendSynAck()
            return
        }

        val dataOffset = ihl + tcpHdrLen
        if (dataOffset < pkt.size) {
            val payload = pkt.copyOfRange(dataOffset, pkt.size)
            activeSessions[key]?.onClientPayload(payload, seq)
        }
    }

    private fun stopAll() {
        activeSessions.values.forEach { it.close() }
        activeSessions.clear()
        XrayCoreBridge.stop()
        try { tunPfd?.close() } catch (_: Exception) {}
        tunPfd = null
        notifyState(STATE_IDLE, "Нажмите для подключения")
        stopForeground(STOP_FOREGROUND_REMOVE)
        stopSelf()
    }

    private fun notifyState(state: String, status: String) {
        currentState = state
        val intent = Intent(BROADCAST_STATE).apply {
            setPackage(packageName)
            putExtra(EXTRA_STATE, state)
            putExtra(EXTRA_STATUS, status)
            putExtra(EXTRA_NODE, currentNode)
            putExtra(EXTRA_DPI, currentDpi)
            putExtra(EXTRA_PING, currentPing)
        }
        sendBroadcast(intent)
    }

    private fun makeNotification(text: String): Notification {
        val chId = "whitez_core_channel"
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val ch = NotificationChannel(chId, "WHITEZ Tunnel", NotificationManager.IMPORTANCE_LOW)
            getSystemService(NotificationManager::class.java)?.createNotificationChannel(ch)
        }
        val pi = PendingIntent.getActivity(
            this, 0, Intent(this, MainActivity::class.java), PendingIntent.FLAG_IMMUTABLE
        )
        return NotificationCompat.Builder(this, chId)
            .setContentTitle("WHITEZ")
            .setContentText(text)
            .setSmallIcon(android.R.drawable.ic_lock_lock)
            .setContentIntent(pi)
            .setOngoing(true)
            .build()
    }

    private fun updateNotification(text: String) {
        getSystemService(NotificationManager::class.java)?.notify(303, makeNotification(text))
    }

    override fun onDestroy() {
        stopAll()
        scope.cancel()
        super.onDestroy()
    }
}

class ClientTcpBridge(
    private val service: VpnService,
    private val srcIp: InetAddress,
    private val srcPort: Int,
    private val dstIp: InetAddress,
    private val dstPort: Int,
    initSeq: Long,
    private val profile: DpiStrategyProfile,
    private val mode: SubscriptionManager.OperationMode,
    private val tunOut: FileOutputStream,
    private val onClosed: () -> Unit
) {
    private var remoteSocket: Socket? = null
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.IO)
    private var localSeq = 10000L
    private var ackSeq = (initSeq + 1) and 0xFFFFFFFFL
    private var connected = false

    fun sendSynAck() {
        val synAck = PacketBuilder.buildTcp(
            dstIp, dstPort, srcIp, srcPort,
            seq = localSeq,
            ack = ackSeq,
            flags = 0x12,
            payload = ByteArray(0)
        )
        localSeq = (localSeq + 1) and 0xFFFFFFFFL
        synchronized(tunOut) { tunOut.write(synAck) }
    }

    fun onClientPayload(payload: ByteArray, seq: Long) {
        scope.launch {
            try {
                ackSeq = (seq + payload.size) and 0xFFFFFFFFL
                val ackPkt = PacketBuilder.buildTcp(
                    dstIp, dstPort, srcIp, srcPort,
                    seq = localSeq,
                    ack = ackSeq,
                    flags = 0x10,
                    payload = ByteArray(0)
                )
                synchronized(tunOut) { tunOut.write(ackPkt) }

                if (!connected) {
                    connected = true
                    val sni = DpiEngine.extractSni(payload)
                    val wantSocks = DpiEngine.needsVpnRouting(sni, mode) && XrayCoreBridge.isSocksReady()

                    val sock = Socket()
                    service.protect(sock)
                    sock.tcpNoDelay = true

                    if (wantSocks) {
                        openSocks5(sock, dstIp.hostAddress ?: "", dstPort)
                        sock.getOutputStream().write(payload)
                        sock.getOutputStream().flush()
                    } else {
                        // Надёжный прямой коннект с DPI-фрагментацией (всегда работает без зависания!)
                        sock.connect(InetSocketAddress(dstIp, dstPort), 4000)
                        DpiEngine.writePayload(sock, sock.getOutputStream(), payload, profile)
                    }

                    remoteSocket = sock
                    pumpServerToClient(sock)
                } else {
                    remoteSocket?.getOutputStream()?.apply {
                        write(payload)
                        flush()
                    }
                }
            } catch (_: Exception) {
                close()
            }
        }
    }

    private fun openSocks5(sock: Socket, host: String, port: Int) {
        sock.connect(InetSocketAddress(XrayCoreBridge.SOCKS_HOST, XrayCoreBridge.SOCKS_PORT), 2500)
        val out = sock.getOutputStream()
        val inp = sock.getInputStream()
        out.write(byteArrayOf(0x05, 0x01, 0x00))
        out.flush()
        val hello = ByteArray(2)
        if (inp.read(hello) < 2) throw IllegalStateException("SOCKS5 handshake failed")

        val hostBytes = host.toByteArray(Charsets.UTF_8)
        val req = ByteArray(7 + hostBytes.size)
        req[0] = 0x05
        req[1] = 0x01
        req[2] = 0x00
        req[3] = 0x03
        req[4] = hostBytes.size.toByte()
        System.arraycopy(hostBytes, 0, req, 5, hostBytes.size)
        req[5 + hostBytes.size] = ((port shr 8) and 0xFF).toByte()
        req[6 + hostBytes.size] = (port and 0xFF).toByte()
        out.write(req)
        out.flush()

        val resp = ByteArray(10)
        if (inp.read(resp) < 2 || resp[1] != 0x00.toByte()) {
            throw IllegalStateException("SOCKS5 connect rejected")
        }
    }

    private fun pumpServerToClient(sock: Socket) {
        scope.launch {
            try {
                val inp = sock.getInputStream()
                val buf = ByteArray(1360)
                while (isActive) {
                    val n = inp.read(buf)
                    if (n <= 0) break
                    val data = buf.copyOf(n)
                    val pkt = PacketBuilder.buildTcp(
                        dstIp, dstPort, srcIp, srcPort,
                        seq = localSeq,
                        ack = ackSeq,
                        flags = 0x18,
                        payload = data
                    )
                    localSeq = (localSeq + n) and 0xFFFFFFFFL
                    synchronized(tunOut) { tunOut.write(pkt) }
                }
            } catch (_: Exception) {
            } finally {
                close()
            }
        }
    }

    fun close() {
        scope.cancel()
        try { remoteSocket?.close() } catch (_: Exception) {}
        onClosed()
    }
}
