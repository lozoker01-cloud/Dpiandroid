package com.whitez.app.ui

import android.app.Activity
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.net.VpnService
import android.os.Build
import android.os.Bundle
import android.view.View
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ProgressBar
import android.widget.TextView
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import androidx.lifecycle.lifecycleScope
import com.whitez.app.R
import com.whitez.app.core.SubscriptionManager
import com.whitez.app.vpn.WhitezCoreVpnService
import kotlinx.coroutines.launch

class MainActivity : AppCompatActivity() {

    private lateinit var powerButton: LinearLayout
    private lateinit var tvPowerTitle: TextView
    private lateinit var tvPowerSub: TextView
    private lateinit var progressBar: ProgressBar
    private lateinit var tvStatusChip: TextView
    private lateinit var tvServerTitle: TextView
    private lateinit var tvPingChip: TextView
    private lateinit var tvDpiLabel: TextView
    private lateinit var tvModeName: TextView
    private lateinit var tvModeHint: TextView
    private lateinit var cardMode: LinearLayout
    private lateinit var cardSub: LinearLayout

    private val vpnPermLauncher = registerForActivityResult(
        ActivityResultContracts.StartActivityForResult()
    ) { res ->
        if (res.resultCode == Activity.RESULT_OK) {
            startServiceNow()
        } else {
            Toast.makeText(this, "Разрешите подключение VPN для запуска WHITEZ", Toast.LENGTH_SHORT).show()
        }
    }

    private val stateReceiver = object : BroadcastReceiver() {
        override fun onReceive(context: Context?, intent: Intent?) {
            val state = intent?.getStringExtra(WhitezCoreVpnService.EXTRA_STATE) ?: return
            val status = intent.getStringExtra(WhitezCoreVpnService.EXTRA_STATUS) ?: ""
            val node = intent.getStringExtra(WhitezCoreVpnService.EXTRA_NODE) ?: ""
            val dpi = intent.getStringExtra(WhitezCoreVpnService.EXTRA_DPI) ?: ""
            val ping = intent.getLongExtra(WhitezCoreVpnService.EXTRA_PING, 0L)
            applyState(state, status, node, dpi, ping)
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        powerButton = findViewById(R.id.powerButton)
        tvPowerTitle = findViewById(R.id.tvPowerTitle)
        tvPowerSub = findViewById(R.id.tvPowerSub)
        progressBar = findViewById(R.id.progressBar)
        tvStatusChip = findViewById(R.id.tvStatusChip)
        tvServerTitle = findViewById(R.id.tvServerTitle)
        tvPingChip = findViewById(R.id.tvPingChip)
        tvDpiLabel = findViewById(R.id.tvDpiLabel)
        tvModeName = findViewById(R.id.tvModeName)
        tvModeHint = findViewById(R.id.tvModeHint)
        cardMode = findViewById(R.id.cardMode)
        cardSub = findViewById(R.id.cardSub)

        powerButton.setOnClickListener {
            if (WhitezCoreVpnService.currentState == WhitezCoreVpnService.STATE_IDLE) {
                prepareAndStart()
            } else {
                stopServiceNow()
            }
        }

        cardMode.setOnClickListener {
            switchMode()
        }

        cardSub.setOnClickListener {
            openSubscriptionEditor()
        }

        refreshModeText()
        loadInitialServerInfo()

        applyState(
            WhitezCoreVpnService.currentState,
            if (WhitezCoreVpnService.currentState == WhitezCoreVpnService.STATE_ACTIVE)
                SubscriptionManager.getOperationMode(this).title
            else
                "Нажмите для подключения",
            WhitezCoreVpnService.currentNode,
            WhitezCoreVpnService.currentDpi,
            WhitezCoreVpnService.currentPing
        )
    }

    override fun onStart() {
        super.onStart()
        val filter = IntentFilter(WhitezCoreVpnService.BROADCAST_STATE)
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            registerReceiver(stateReceiver, filter, RECEIVER_NOT_EXPORTED)
        } else {
            registerReceiver(stateReceiver, filter)
        }
    }

    override fun onStop() {
        super.onStop()
        unregisterReceiver(stateReceiver)
    }

    private fun loadInitialServerInfo() {
        lifecycleScope.launch {
            val list = SubscriptionManager.syncAndMeasureNodes(this@MainActivity)
            val first = list.firstOrNull()
            if (first != null) {
                tvServerTitle.text = "${first.name} (${first.protocol})"
                tvPingChip.text = if (first.pingMs > 0) "${first.pingMs} мс" else "ONLINE"
            } else {
                tvServerTitle.text = "31.59.207.13 (Подписка активна)"
                tvPingChip.text = "AUTO"
            }
        }
    }

    private fun switchMode() {
        val values = SubscriptionManager.OperationMode.values()
        val curr = SubscriptionManager.getOperationMode(this)
        val next = values[(curr.ordinal + 1) % values.size]
        SubscriptionManager.saveOperationMode(this, next)
        refreshModeText()

        if (WhitezCoreVpnService.currentState == WhitezCoreVpnService.STATE_ACTIVE) {
            Toast.makeText(this, "Режим: ${next.title}. Перезапуск...", Toast.LENGTH_SHORT).show()
            stopServiceNow()
            powerButton.postDelayed({ startServiceNow() }, 350)
        }
    }

    private fun refreshModeText() {
        val m = SubscriptionManager.getOperationMode(this)
        tvModeName.text = m.title
        tvModeHint.text = m.subtitle
    }

    private fun openSubscriptionEditor() {
        val edit = EditText(this).apply {
            setText(SubscriptionManager.getSubscriptionUrl(this@MainActivity))
            setTextColor(0xFFFFFFFF.toInt())
            setPadding(40, 32, 40, 32)
        }
        AlertDialog.Builder(this)
            .setTitle("Подписка WHITEZ")
            .setMessage("Ссылка подписки вашего сервера:")
            .setView(edit)
            .setPositiveButton("Сохранить") { _, _ ->
                SubscriptionManager.saveSubscriptionUrl(this, edit.text.toString())
                loadInitialServerInfo()
                Toast.makeText(this, "Ссылка сохранена", Toast.LENGTH_SHORT).show()
            }
            .setNegativeButton("Закрыть", null)
            .show()
    }

    private fun prepareAndStart() {
        val req = VpnService.prepare(this)
        if (req != null) {
            vpnPermLauncher.launch(req)
        } else {
            startServiceNow()
        }
    }

    private fun startServiceNow() {
        val intent = Intent(this, WhitezCoreVpnService::class.java).apply {
            action = WhitezCoreVpnService.ACTION_START
        }
        ContextCompat.startForegroundService(this, intent)
    }

    private fun stopServiceNow() {
        val intent = Intent(this, WhitezCoreVpnService::class.java).apply {
            action = WhitezCoreVpnService.ACTION_STOP
        }
        startService(intent)
    }

    private fun applyState(
        state: String,
        status: String,
        node: String,
        dpi: String,
        ping: Long
    ) {
        if (node.isNotBlank()) tvServerTitle.text = node
        if (dpi.isNotBlank()) tvDpiLabel.text = "DPI: $dpi"
        if (ping > 0L) tvPingChip.text = "$ping мс"

        when (state) {
            WhitezCoreVpnService.STATE_IDLE -> {
                progressBar.visibility = View.GONE
                powerButton.setBackgroundResource(R.drawable.bg_power_ring_idle)
                tvPowerTitle.text = "ВКЛЮЧИТЬ"
                tvPowerSub.text = "1 нажатие"
                tvStatusChip.text = "● ОТКЛЮЧЕНО"
                tvStatusChip.setTextColor(0xFF8A94A6.toInt())
            }
            WhitezCoreVpnService.STATE_STARTING -> {
                progressBar.visibility = View.VISIBLE
                powerButton.setBackgroundResource(R.drawable.bg_power_ring_idle)
                tvPowerTitle.text = "ПОДБОР..."
                tvPowerSub.text = "Автонастройка"
                tvStatusChip.text = "● $status"
                tvStatusChip.setTextColor(0xFFF59E0B.toInt())
            }
            WhitezCoreVpnService.STATE_ACTIVE -> {
                progressBar.visibility = View.GONE
                powerButton.setBackgroundResource(R.drawable.bg_power_ring_active)
                tvPowerTitle.text = "РАБОТАЕТ"
                tvPowerSub.text = "Нажмите для стопа"
                tvStatusChip.text = "● $status"
                tvStatusChip.setTextColor(0xFF10B981.toInt())
            }
        }
    }
}
