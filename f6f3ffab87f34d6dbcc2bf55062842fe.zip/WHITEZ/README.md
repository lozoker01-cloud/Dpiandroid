# WHITEZ 3.2
Режимы: Обход (ciadpi/ByeDPI + 21 стратегия, тест, автоподбор) и VPN (VLESS через Xray, запасной).
Сборка: scripts/build_ciadpi.sh собирает движок, затем gradle assembleDebug.
Для репозитория с ZapretAndroid.zip используйте docs/workflow-for-zip-repo.yml.
Ссылку подписки вводите в приложении.
