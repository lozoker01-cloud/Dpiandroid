package app.whitez
import org.json.JSONArray
import org.json.JSONObject

object XrayConfig {
    const val SOCKS_PORT = 10808

    fun build(s: Server): String {
        val p = s.params
        val stream = JSONObject().put("network", p["type"] ?: "tcp").put("security", p["security"] ?: "none")
        when (p["security"]) {
            "reality" -> stream.put("realitySettings", JSONObject()
                .put("serverName", p["sni"] ?: "").put("fingerprint", p["fp"] ?: "chrome")
                .put("publicKey", p["pbk"] ?: "").put("shortId", p["sid"] ?: "")
                .put("spiderX", p["spx"] ?: ""))
            "tls" -> stream.put("tlsSettings", JSONObject()
                .put("serverName", p["sni"] ?: s.host).put("fingerprint", p["fp"] ?: "chrome"))
        }
        when (p["type"]) {
            "ws" -> stream.put("wsSettings", JSONObject().put("path", p["path"] ?: "/")
                .put("headers", JSONObject().put("Host", p["host"] ?: "")))
            "grpc" -> stream.put("grpcSettings", JSONObject().put("serviceName", p["serviceName"] ?: ""))
            "xhttp" -> stream.put("xhttpSettings", JSONObject().put("path", p["path"] ?: "/")
                .put("host", p["host"] ?: "").put("mode", p["mode"] ?: "auto"))
        }
        if (s.fragment) stream.put("sockopt", JSONObject().put("dialerProxy", "fragment"))

        val user = JSONObject().put("id", s.uuid).put("encryption", p["encryption"] ?: "none")
        p["flow"]?.let { if (it.isNotEmpty()) user.put("flow", it) }
        val proxy = JSONObject().put("tag", "proxy").put("protocol", "vless").put("settings",
            JSONObject().put("vnext", JSONArray().put(JSONObject().put("address", s.host)
                .put("port", s.port).put("users", JSONArray().put(user)))))
            .put("streamSettings", stream)
        val direct = JSONObject().put("tag", "direct").put("protocol", "freedom")
        val outs = JSONArray().put(proxy).put(direct)
        if (s.fragment) outs.put(JSONObject().put("tag", "fragment").put("protocol", "freedom")
            .put("settings", JSONObject().put("fragment", JSONObject()
                .put("packets", "tlshello").put("length", "100-200").put("interval", "10-20"))))
        return JSONObject()
            .put("log", JSONObject().put("loglevel", "warning"))
            .put("dns", JSONObject().put("servers", JSONArray().put("1.1.1.1").put("8.8.8.8")))
            .put("inbounds", JSONArray().put(JSONObject().put("tag", "socks").put("port", SOCKS_PORT)
                .put("listen", "127.0.0.1").put("protocol", "socks")
                .put("settings", JSONObject().put("udp", true).put("auth", "noauth"))
                .put("sniffing", JSONObject().put("enabled", true)
                    .put("destOverride", JSONArray().put("http").put("tls").put("quic")))))
            .put("outbounds", outs)
            .toString()
    }
}
