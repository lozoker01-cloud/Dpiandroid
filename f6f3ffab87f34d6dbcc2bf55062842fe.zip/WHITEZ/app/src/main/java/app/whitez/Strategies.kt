package app.whitez

data class Strategy(val id: Int, val name: String, val args: List<String>) {
    val cmd get() = if (args.isEmpty()) "без параметров (контроль)" else args.joinToString(" ")
}

data class Svc(val id: String, val short: String, val name: String, val urls: List<String>)

object Services {
    val all = listOf(
        Svc("yt", "YT", "YouTube", listOf("www.youtube.com", "redirector.googlevideo.com", "i.ytimg.com")),
        Svc("ds", "DS", "Discord", listOf("discord.com", "cdn.discordapp.com", "gateway.discord.gg")),
        Svc("tg", "TG", "Telegram", listOf("web.telegram.org", "telegram.org")),
        Svc("ig", "IG", "Instagram", listOf("www.instagram.com")),
        Svc("x", "X", "X / Twitter", listOf("x.com"))
    )
}

object Strategies {
    private fun s(id: Int, name: String, cmd: String) = Strategy(id, name, cmd.trim().split(Regex("\\s+")))

    val baseline = Strategy(0, "Без обхода", emptyList())

    val all = listOf(
        s(1,  "Split SNI",               "--split 1+s"),
        s(2,  "Disorder",                "--disorder 1"),
        s(3,  "Split + TLS-rec",         "--split 1+s --tlsrec 1+s"),
        s(4,  "Disorder + TLS-rec",      "--disorder 1 --tlsrec 1+s --udp-fake 1"),
        s(5,  "Split + Disorder",        "--split 1+s --disorder 3+s"),
        s(6,  "OOB",                     "--oob 3+s"),
        s(7,  "Split + Disorder + OOB",  "--split 1+s --disorder 3+s --oob 1+s --udp-fake 1"),
        s(8,  "Disoob",                  "--disoob 1+s"),
        s(9,  "Fake TTL 8 + UDP",        "--fake -1 --ttl 8 --udp-fake 1"),
        s(10, "Fake TTL 5",              "--fake -1 --ttl 5"),
        s(11, "Fake TTL 10",             "--fake -1 --ttl 10"),
        s(12, "Fake случайный TLS",      "--fake -1 --ttl 8 --fake-tls-mod rand"),
        s(13, "Disorder + Fake",         "--disorder 1 --fake -1"),
        s(14, "Адаптивная SSL",          "--fake -1 --ttl 8 --auto=ssl_err --fake -1 --ttl 5 --udp-fake 1"),
        s(15, "Auto torst + TLS-rec",    "--auto=torst --timeout 3 --tlsrec 3+s"),
        s(16, "Auto torst + Disorder",   "--disorder 1 --auto=torst --tlsrec 1+s"),
        s(17, "Fake TTL 10 / 5 адапт.",  "--fake -1 --ttl 10 --auto=ssl_err --fake -1 --ttl 5"),
        s(18, "TLS-rec глубокий",        "--tlsrec 3+s"),
        s(19, "Split + OOB",             "--split 1+s --oob 1+s"),
        s(20, "Fake + свой SNI",         "--fake -1 --ttl 8 --fake-sni www.google.com"),
        s(21, "Disorder + TLS-rec + Fake", "--disorder 1 --tlsrec 1+s --fake -1 --ttl 8")
    )
    fun byId(id: Int) = if (id == 0) baseline else all.firstOrNull { it.id == id } ?: all[3]
}

data class StrategyResult(
    val strategy: Strategy,
    val passed: Set<String> = emptySet(),
    val avgMs: Long = -1,
    val error: String? = null,
    val tested: Boolean = false
) { val score get() = passed.size }
